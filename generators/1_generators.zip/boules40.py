# -*- coding: utf-8 -*-
"""MANAPRINT — 40 BOULES (refait le 18/11/2026 sur la maquette de Maeva).
12 cartons par feuille A4 PORTRAIT. La maquette est reprise TELLE QUELLE comme
fond, en 2 tons francs (rendu propre sur la Konica) ; on n'ajoute que les
chiffres, le n° de série et le n° de page.
Règle : 5 colonnes : 1-8 (x2), 9-16 (x1), 17-24 (x2), 25-32 (x1), 33-40 (x2) = 8 numéros, triés du plus petit en haut. Crieur 1-40.
Chiffres en Latin Modern (écriture maison), NOIRS, le plus gros possible avec de l'air dans la case.
Feuille ramenée à 6 mm des bords (la Konica n'imprime pas les 4,2 mm du bord)."""
import io, os as _os, random
from reportlab.pdfgen import canvas
from reportlab.lib.pagesizes import A4, landscape
from reportlab.lib import colors

PAGE_W, PAGE_H = A4
CARTES_PAGE = 12
PLAGES = [(1, 8), (9, 16), (17, 24), (25, 32), (33, 40)]
PAR_COLONNE = [2, 1, 2, 1, 2]
NOIR = colors.Color(0.08, 0.08, 0.08)
GRIS_TRAIT = colors.Color(0.40, 0.40, 0.40)
RAINBOW = ["#E53935", "#FB8C00", "#F9A825", "#43A047", "#00ACC1",
           "#1E88E5", "#3949AB", "#8E24AA", "#D81B60", "#6D4C41"]
POLICE, _CAP, _LARG88 = "Helvetica-Bold", 0.717, 1.112
# ⭐ 18/11 (Maeva : « ces jeux avaient déjà leurs propres écritures ») :
#    l'écriture maison des planches ÉCO = LATIN MODERN ROMAN (comme RAI, KEA, P6).
try:
    from reportlab.pdfbase import pdfmetrics as _pm
    from reportlab.pdfbase.ttfonts import TTFont as _TF
    import os as _o
    _pm.registerFont(_TF("LMROMAN", _o.path.join(_o.path.dirname(_o.path.abspath(__file__)), "LatinModern.ttf")))
    POLICE, _CAP, _LARG88 = "LMROMAN", 0.644, 1.0
except Exception:
    pass
_ICI = _os.path.dirname(_os.path.abspath(__file__))
_IMG_W, _IMG_H = 1055.0, 1491.0
_IMG_FOND = _os.path.join(_ICI, "boules40_fond.png")
MARGE_SURE = 6 * 72 / 25.4
ECHELLE = min((PAGE_W - 2 * MARGE_SURE) / PAGE_W, (PAGE_H - 2 * MARGE_SURE) / PAGE_H)
DECAL_X = (PAGE_W - PAGE_W * ECHELLE) / 2.0
DECAL_Y = (PAGE_H - PAGE_H * ECHELLE) / 2.0

# pour chaque carton : les cases (x0, y0, x1, y1) px, colonne par colonne,
# de haut en bas ; serie = (x0, y0, x1, y1) px de la place du n° de série.
CARTONS = [
    {'cols': [[(36, 77, 126, 144), (36, 146, 126, 215)], [(129, 77, 219, 215)], [(222, 77, 317, 144), (222, 146, 317, 215)], [(320, 77, 411, 215)], [(414, 77, 511, 144), (414, 146, 511, 215)]], 'serie': (114, 225, 186, 238)},
    {'cols': [[(546, 77, 639, 144), (546, 146, 639, 215)], [(642, 77, 731, 215)], [(734, 77, 830, 144), (734, 146, 830, 215)], [(833, 77, 924, 215)], [(927, 77, 1019, 144), (927, 146, 1019, 215)]], 'serie': (623, 227, 695, 238)},
    {'cols': [[(36, 316, 126, 383), (36, 385, 126, 454)], [(129, 316, 219, 454)], [(222, 316, 317, 383), (222, 385, 317, 454)], [(320, 316, 411, 454)], [(414, 316, 511, 383), (414, 385, 511, 454)]], 'serie': (114, 468, 186, 479)},
    {'cols': [[(545, 316, 639, 383), (546, 385, 639, 454)], [(641, 316, 731, 454)], [(734, 316, 830, 383), (734, 385, 830, 454)], [(833, 316, 924, 454)], [(927, 316, 1019, 383), (927, 385, 1019, 454)]], 'serie': (623, 469, 695, 479)},
    {'cols': [[(36, 554, 126, 622), (36, 624, 126, 693)], [(129, 554, 219, 693)], [(222, 554, 317, 622), (222, 624, 317, 693)], [(320, 554, 411, 693)], [(414, 554, 511, 622), (414, 624, 511, 693)]], 'serie': (114, 706, 186, 718)},
    {'cols': [[(546, 554, 639, 622), (546, 624, 639, 693)], [(642, 554, 731, 693)], [(734, 554, 830, 622), (734, 624, 830, 693)], [(833, 554, 924, 693)], [(927, 554, 1019, 622), (927, 624, 1019, 693)]], 'serie': (623, 707, 695, 718)},
    {'cols': [[(36, 793, 126, 860), (36, 863, 126, 932)], [(129, 793, 219, 932)], [(222, 793, 317, 860), (222, 863, 317, 932)], [(320, 793, 411, 932)], [(414, 793, 511, 860), (414, 863, 511, 932)]], 'serie': (114, 946, 186, 957)},
    {'cols': [[(546, 793, 639, 860), (546, 863, 639, 932)], [(641, 793, 731, 932)], [(734, 793, 830, 860), (734, 863, 830, 932)], [(833, 793, 924, 932)], [(927, 793, 1019, 860), (927, 863, 1019, 932)]], 'serie': (623, 946, 695, 957)},
    {'cols': [[(36, 1034, 126, 1100), (36, 1103, 126, 1171)], [(129, 1034, 219, 1171)], [(222, 1034, 317, 1100), (222, 1103, 317, 1171)], [(320, 1034, 411, 1171)], [(414, 1034, 511, 1100), (414, 1103, 511, 1171)]], 'serie': (114, 1185, 186, 1196)},
    {'cols': [[(546, 1034, 638, 1100), (546, 1103, 639, 1171)], [(641, 1034, 731, 1171)], [(734, 1034, 830, 1100), (734, 1103, 830, 1171)], [(833, 1034, 924, 1171)], [(927, 1034, 1019, 1100), (927, 1103, 1019, 1171)]], 'serie': (623, 1185, 695, 1196)},
    {'cols': [[(36, 1271, 126, 1340), (36, 1343, 126, 1412)], [(129, 1271, 219, 1412)], [(222, 1271, 317, 1340), (222, 1343, 317, 1412)], [(320, 1271, 411, 1412)], [(414, 1271, 511, 1340), (414, 1343, 511, 1412)]], 'serie': (114, 1425, 186, 1436)},
    {'cols': [[(545, 1271, 638, 1340), (545, 1343, 638, 1412)], [(641, 1271, 731, 1412)], [(734, 1271, 830, 1340), (734, 1343, 830, 1412)], [(833, 1271, 924, 1412)], [(927, 1271, 1019, 1340), (927, 1343, 1019, 1412)]], 'serie': (623, 1426, 695, 1436)},
]
ALIGN_SERIE = "L"
AIR_H, AIR_W = 0.60, 0.70   # part de la case que « 88 » peut occuper


def _px(x):
    return x / _IMG_W * PAGE_W


def _py(y):
    return PAGE_H * (1 - y / _IMG_H)


def _taille_case(x0, y0, x1, y1):
    h = _px(y1) - _px(y0)
    w = _px(x1) - _px(x0)
    t = min(AIR_H * h / _CAP, AIR_W * w / _LARG88)
    return int(t * 2) / 2.0


# une taille par « famille » de cases (même hauteur), la plus petite de la famille
_TAILLES = {}
for _ct in CARTONS:
    for _col in _ct["cols"]:
        for _c in _col:
            _k = round((_c[3] - _c[1]) / 20.0)
            _TAILLES[_k] = min(_TAILLES.get(_k, 999), _taille_case(*_c))


def _taille(c):
    return _TAILLES[round((c[3] - c[1]) / 20.0)]


def _numeros(rng, deja=None):
    while True:
        d = [sorted(rng.sample(range(a, b + 1), n)) for (a, b), n in zip(PLAGES, PAR_COLONNE)]
        cle = tuple(v for p in d for v in p)
        if deja is None or cle not in deja:
            if deja is not None:
                deja.add(cle)
            return d


def _num(c, txt, x, y, t):
    o = c.beginText()
    o.setTextRenderMode(2)
    o.setFont(POLICE, t)
    o.setTextOrigin(x - c.stringWidth(txt, POLICE, t) / 2.0, y)
    o.textOut(txt)
    c.drawText(o)


def generer_pdf(nb_cartes=None, nb_tickets=None, serie_start=1, theme="", couleur=True,
                nom_evenement="", titre_jeu="", couleur_perso="", date_lieu="",
                telephone="", page_start=1, evenement_id="", style="", motif="",
                _deja=None, **_ig):
    n_ = nb_cartes if nb_cartes is not None else nb_tickets
    n_ = max(1, int(n_ if n_ else CARTES_PAGE))
    buf = io.BytesIO()
    c = canvas.Canvas(buf, pagesize=(PAGE_W, PAGE_H), pageCompression=1)
    c.setTitle("40 BOULES")
    rng = random.Random(int(serie_start) * 100003 + 4040)
    deja = _deja if _deja is not None else set()
    serie = int(serie_start)
    faits = 0
    try:
        no_page = max(1, int(page_start))
    except Exception:
        no_page = 1
    col_imposee = None
    if couleur and couleur_perso:
        try:
            col_imposee = colors.HexColor(couleur_perso)
        except Exception:
            col_imposee = None
    while faits < n_:
        c.saveState()
        c.translate(DECAL_X, DECAL_Y)
        c.scale(ECHELLE, ECHELLE)
        try:
            c.drawImage(_IMG_FOND, 0, 0, PAGE_W, PAGE_H, preserveAspectRatio=False, mask="auto")
        except Exception:
            pass
        entete = "  ·  ".join(t for t in ((nom_evenement or "").strip(),
                                          (date_lieu or "").strip(),
                                          (telephone or "").strip()) if t)
        for idx in range(CARTES_PAGE):
            if faits >= n_:
                break
            ct = CARTONS[idx]
            col = (col_imposee or colors.HexColor(RAINBOW[serie % len(RAINBOW)])) if couleur else NOIR
            nums = _numeros(rng, deja)
            c.saveState()
            c.setFillColor(col)
            c.setStrokeColor(col)
            c.setLineWidth(0.25)
            c.setLineJoin(1)
            for cases, vals in zip(ct["cols"], nums):
                for (x0, y0, x1, y1), v in zip(cases, vals):
                    t = _taille((x0, y0, x1, y1))
                    _num(c, str(v), _px((x0 + x1) / 2.0), _py((y0 + y1) / 2.0) - t * _CAP / 2.0, t)
            c.restoreState()
            sx0, sy0, sx1, sy1 = ct["serie"]
            ts = min(9.0, (_px(sy1) - _px(sy0)) / 0.72)
            c.setFillColor(GRIS_TRAIT)
            c.setFont("Helvetica-Bold", ts)
            if ALIGN_SERIE == "R":
                c.drawRightString(_px(sx1), _py(sy1), "%06d" % serie)
            else:
                c.drawString(_px(sx0), _py(sy1), "%06d" % serie)
            serie += 1
            faits += 1
        c.restoreState()
        # n° de page (et personnalisation) dans la marge que la Konica imprime
        c.setFillColor(GRIS_TRAIT)
        c.setFont("Helvetica", 6)
        c.drawRightString(PAGE_W - 17, PAGE_H - 19, "%d" % no_page)
        if entete:
            c.setFont("Helvetica-Bold", 6.5)
            c.drawCentredString(PAGE_W / 2.0, PAGE_H - 13.5, entete)
        no_page += 1
        c.showPage()
    c.save()
    buf.seek(0)
    return buf


if __name__ == "__main__":
    open("test.pdf", "wb").write(generer_pdf(nb_cartes=CARTES_PAGE, couleur=False).read())
