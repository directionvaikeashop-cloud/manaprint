# -*- coding: utf-8 -*-
"""MANAPRINT — SUN 8 boules (NOUVELLE maquette de Maeva du 19/11/2026).
16 cartons par feuille A4 PAYSAGE. La maquette est reprise TELLE QUELLE comme
fond, en 2 tons francs (rendu propre sur la Konica) ; on n'ajoute que les
chiffres, le n° de série et le n° de page.
Règle : col 1 = 1-8 (3 numéros), col 2 = 9-16 (2 numéros, la case du bas = le soleil), col 3 = 17-24 (3 numéros), triés du plus petit en haut. Crieur 1-24.
Chiffres en Latin Modern (écriture maison), NOIRS, le plus gros possible avec de l'air dans la case.
Feuille ramenée à 6 mm des bords (la Konica n'imprime pas les 4,2 mm du bord)."""
import io, os as _os, random
from reportlab.pdfgen import canvas
from reportlab.lib.pagesizes import A4, landscape
from reportlab.lib import colors

PAGE_W, PAGE_H = landscape(A4)
CARTES_PAGE = 16
PLAGES = [(1, 8), (9, 16), (17, 24)]
PAR_COLONNE = [3, 2, 3]
NOIR = colors.Color(0.08, 0.08, 0.08)
GRIS_TRAIT = colors.Color(0.40, 0.40, 0.40)
RAINBOW = ["#E53935", "#FB8C00", "#F9A825", "#43A047", "#00ACC1",
           "#1E88E5", "#3949AB", "#8E24AA", "#D81B60", "#6D4C41"]
POLICE, _CAP, _LARG88 = "Helvetica-Bold", 0.717, 1.112
# ⭐ 18/11 (Maeva : « ces jeux avaient déjà leurs propres écritures ») :
#    l'écriture maison des planches ÉCO = LATIN MODERN ROMAN (comme RAI, KEA, P6).
try:
    from reportlab.pdfbase import pdfmetrics as _pm
    from reportlab.pdfbase.ttfonts import TTFont as _TF
    import os as _o
    _pm.registerFont(_TF("LMROMAN", _o.path.join(_o.path.dirname(_o.path.abspath(__file__)), "LatinModern.ttf")))
    POLICE, _CAP, _LARG88 = "LMROMAN", 0.644, 1.0
    # ⭐ 19/11 (Maeva : « mets du gras ») : la même écriture en GRAS, comme KEA
    _pm.registerFont(_TF("LMROMANB", _o.path.join(_o.path.dirname(_o.path.abspath(__file__)), "LatinModern-Bold.ttf")))
    POLICE, _CAP, _LARG88 = "LMROMANB", 0.644, 1.15
except Exception:
    pass
_ICI = _os.path.dirname(_os.path.abspath(__file__))
_IMG_W, _IMG_H = 1501.0, 1061.0
_IMG_FOND = _os.path.join(_ICI, "sun_fond.png")
MARGE_SURE = 6 * 72 / 25.4
ECHELLE = min((PAGE_W - 2 * MARGE_SURE) / PAGE_W, (PAGE_H - 2 * MARGE_SURE) / PAGE_H)
DECAL_X = (PAGE_W - PAGE_W * ECHELLE) / 2.0
DECAL_Y = (PAGE_H - PAGE_H * ECHELLE) / 2.0

# pour chaque carton : les cases (x0, y0, x1, y1) px, colonne par colonne,
# de haut en bas ; serie = (x0, y0, x1, y1) px de la place du n° de série.
CARTONS = [
    {'cols': [[(25, 96, 134, 149), (25, 154, 134, 207), (25, 213, 134, 261)], [(140, 97, 252, 149), (140, 154, 252, 207)], [(258, 97, 366, 148), (258, 154, 366, 207), (258, 213, 366, 262)]], 'serie': (284, 270, 354, 287)},
    {'cols': [[(398, 97, 506, 149), (398, 154, 506, 207), (399, 213, 506, 261)], [(512, 97, 624, 149), (512, 154, 624, 207)], [(630, 97, 736, 149), (630, 154, 737, 207), (630, 213, 737, 262)]], 'serie': (655, 270, 728, 286)},
    {'cols': [[(769, 97, 877, 149), (769, 154, 876, 207), (769, 213, 876, 261)], [(883, 96, 994, 149), (883, 153, 994, 207)], [(1000, 97, 1107, 148), (1000, 154, 1107, 207), (1000, 213, 1107, 262)]], 'serie': (1025, 270, 1099, 287)},
    {'cols': [[(1139, 97, 1247, 149), (1139, 154, 1247, 207), (1139, 213, 1247, 261)], [(1253, 97, 1365, 148), (1253, 154, 1365, 207)], [(1371, 97, 1479, 148), (1371, 154, 1479, 207), (1371, 213, 1479, 262)]], 'serie': (1395, 270, 1469, 286)},
    {'cols': [[(25, 353, 134, 406), (25, 412, 134, 466), (25, 471, 134, 520)], [(140, 353, 252, 406), (140, 412, 252, 466)], [(258, 354, 365, 406), (258, 412, 366, 466), (258, 471, 366, 521)]], 'serie': (284, 528, 358, 544)},
    {'cols': [[(398, 353, 506, 406), (398, 412, 506, 466), (398, 471, 506, 520)], [(512, 353, 624, 406), (512, 412, 624, 466)], [(630, 354, 736, 406), (630, 412, 736, 466), (630, 471, 737, 521)]], 'serie': (655, 528, 729, 544)},
    {'cols': [[(769, 354, 877, 406), (769, 412, 877, 466), (769, 471, 877, 520)], [(883, 353, 994, 406), (883, 412, 994, 466)], [(1000, 354, 1107, 406), (1000, 412, 1107, 466), (1000, 471, 1107, 521)]], 'serie': (1026, 528, 1099, 544)},
    {'cols': [[(1139, 353, 1247, 406), (1139, 412, 1247, 466), (1139, 471, 1247, 520)], [(1253, 353, 1365, 406), (1253, 412, 1365, 466)], [(1371, 354, 1479, 406), (1371, 412, 1479, 466), (1371, 471, 1479, 521)]], 'serie': (1395, 528, 1469, 544)},
    {'cols': [[(25, 611, 134, 662), (25, 667, 134, 718), (25, 723, 134, 768)], [(140, 611, 252, 662), (140, 668, 252, 718)], [(258, 611, 366, 662), (258, 668, 366, 718), (258, 723, 366, 769)]], 'serie': (284, 776, 357, 792)},
    {'cols': [[(399, 611, 506, 662), (399, 668, 506, 718), (399, 723, 506, 768)], [(512, 611, 623, 662), (512, 668, 624, 718)], [(630, 611, 737, 662), (630, 668, 737, 718), (630, 723, 737, 769)]], 'serie': (655, 776, 729, 792)},
    {'cols': [[(769, 611, 877, 662), (769, 667, 877, 718), (769, 723, 877, 768)], [(883, 611, 994, 662), (883, 667, 994, 718)], [(1000, 611, 1107, 662), (1000, 668, 1107, 718), (1000, 723, 1108, 769)]], 'serie': (1026, 776, 1096, 792)},
    {'cols': [[(1140, 611, 1247, 662), (1140, 668, 1247, 718), (1140, 723, 1247, 768)], [(1253, 611, 1365, 662), (1253, 668, 1365, 718)], [(1371, 611, 1479, 662), (1371, 668, 1479, 718), (1371, 723, 1479, 769)]], 'serie': (1395, 776, 1469, 793)},
    {'cols': [[(25, 856, 134, 901), (25, 906, 134, 952), (25, 957, 134, 1001)], [(140, 856, 252, 901), (140, 906, 252, 952)], [(258, 856, 365, 901), (258, 906, 365, 952), (259, 957, 366, 1001)]], 'serie': (284, 1009, 357, 1025)},
    {'cols': [[(398, 856, 506, 901), (398, 906, 506, 952), (399, 957, 506, 1001)], [(512, 856, 623, 901), (512, 906, 623, 951)], [(630, 856, 737, 901), (630, 906, 737, 952), (630, 957, 737, 1001)]], 'serie': (655, 1009, 729, 1025)},
    {'cols': [[(769, 856, 877, 901), (769, 906, 877, 952), (769, 957, 877, 1001)], [(883, 856, 994, 901), (883, 906, 994, 952)], [(1001, 857, 1107, 901), (1001, 906, 1107, 952), (1001, 957, 1108, 1001)]], 'serie': (1025, 1009, 1099, 1025)},
    {'cols': [[(1140, 856, 1247, 901), (1139, 906, 1247, 952), (1140, 957, 1247, 1001)], [(1253, 856, 1365, 901), (1253, 906, 1365, 952)], [(1371, 857, 1479, 901), (1371, 906, 1479, 952), (1371, 957, 1480, 1001)]], 'serie': (1395, 1009, 1469, 1025)},
]
ALIGN_SERIE = "R"
AIR_H, AIR_W = 0.70, 0.80   # part de la case que « 88 » peut occuper


def _px(x):
    return x / _IMG_W * PAGE_W


def _py(y):
    return PAGE_H * (1 - y / _IMG_H)


def _taille_case(x0, y0, x1, y1):
    h = _px(y1) - _px(y0)
    w = _px(x1) - _px(x0)
    t = min(AIR_H * h / _CAP, AIR_W * w / _LARG88)
    return int(t * 2) / 2.0


# une taille par « famille » de cases (même hauteur), la plus petite de la famille
_TAILLES = {}
for _ct in CARTONS:
    for _col in _ct["cols"]:
        for _c in _col:
            _k = round((_c[3] - _c[1]) / 20.0)
            _TAILLES[_k] = min(_TAILLES.get(_k, 999), _taille_case(*_c))


def _taille(c):
    return _TAILLES[round((c[3] - c[1]) / 20.0)]


def _numeros(rng, deja=None):
    while True:
        d = [sorted(rng.sample(range(a, b + 1), n)) for (a, b), n in zip(PLAGES, PAR_COLONNE)]
        cle = tuple(v for p in d for v in p)
        if deja is None or cle not in deja:
            if deja is not None:
                deja.add(cle)
            return d


def _num(c, txt, x, y, t):
    o = c.beginText()
    o.setTextRenderMode(2)
    o.setFont(POLICE, t)
    o.setTextOrigin(x - c.stringWidth(txt, POLICE, t) / 2.0, y)
    o.textOut(txt)
    c.drawText(o)


def generer_pdf(nb_cartes=None, nb_tickets=None, serie_start=1, theme="", couleur=True,
                nom_evenement="", titre_jeu="", couleur_perso="", date_lieu="",
                telephone="", page_start=1, evenement_id="", style="", motif="",
                _deja=None, **_ig):
    n_ = nb_cartes if nb_cartes is not None else nb_tickets
    n_ = max(1, int(n_ if n_ else CARTES_PAGE))
    buf = io.BytesIO()
    c = canvas.Canvas(buf, pagesize=(PAGE_W, PAGE_H), pageCompression=1)
    c.setTitle("SUN 8 boules")
    rng = random.Random(int(serie_start) * 100003 + 2424)
    deja = _deja if _deja is not None else set()
    serie = int(serie_start)
    faits = 0
    try:
        no_page = max(1, int(page_start))
    except Exception:
        no_page = 1
    col_imposee = None
    if couleur and couleur_perso:
        try:
            col_imposee = colors.HexColor(couleur_perso)
        except Exception:
            col_imposee = None
    while faits < n_:
        c.saveState()
        c.translate(DECAL_X, DECAL_Y)
        c.scale(ECHELLE, ECHELLE)
        try:
            c.drawImage(_IMG_FOND, 0, 0, PAGE_W, PAGE_H, preserveAspectRatio=False, mask="auto")
        except Exception:
            pass
        entete = "  ·  ".join(t for t in ((nom_evenement or "").strip(),
                                          (date_lieu or "").strip(),
                                          (telephone or "").strip()) if t)
        for idx in range(CARTES_PAGE):
            if faits >= n_:
                break
            ct = CARTONS[idx]
            col = (col_imposee or colors.HexColor(RAINBOW[serie % len(RAINBOW)])) if couleur else NOIR
            nums = _numeros(rng, deja)
            c.saveState()
            c.setFillColor(col)
            c.setStrokeColor(col)
            c.setLineWidth(0.5)
            c.setLineJoin(1)
            for cases, vals in zip(ct["cols"], nums):
                for (x0, y0, x1, y1), v in zip(cases, vals):
                    t = _taille((x0, y0, x1, y1))
                    _num(c, str(v), _px((x0 + x1) / 2.0), _py((y0 + y1) / 2.0) - t * _CAP / 2.0, t)
            c.restoreState()
            sx0, sy0, sx1, sy1 = ct["serie"]
            ts = min(9.0, (_px(sy1) - _px(sy0)) / 0.72)
            c.setFillColor(GRIS_TRAIT)
            c.setFont("Helvetica-Bold", ts)
            if ALIGN_SERIE == "R":
                c.drawRightString(_px(sx1), _py(sy1), "%06d" % serie)
            else:
                c.drawString(_px(sx0), _py(sy1), "%06d" % serie)
            serie += 1
            faits += 1
        c.restoreState()
        # n° de page (et personnalisation) dans la marge que la Konica imprime
        c.setFillColor(GRIS_TRAIT)
        c.setFont("Helvetica", 6)
        c.drawRightString(PAGE_W - 17, PAGE_H - 19, "%03d" % no_page)
        if entete:
            c.setFont("Helvetica-Bold", 6.5)
            c.drawCentredString(PAGE_W / 2.0, PAGE_H - 13.5, entete)
        no_page += 1
        c.showPage()
    c.save()
    buf.seek(0)
    return buf


if __name__ == "__main__":
    open("test.pdf", "wb").write(generer_pdf(nb_cartes=CARTES_PAGE, couleur=False).read())


# ⭐ 21/11 : les variantes spéciales restent celles d'avant (fichier sun_v1.py, inchangé)
def generer_pdf_casino(**kw):
    try:
        from generators import sun_v1 as _v1
    except Exception:
        import sun_v1 as _v1
    return _v1.generer_pdf_casino(**kw)

