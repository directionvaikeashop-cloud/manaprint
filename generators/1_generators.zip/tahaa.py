# -*- coding: utf-8 -*-
"""MANAPRINT — TAHAA (maquette au trait du 06/10 : fleur de vanille + bungalow,
5 cercles). Refait le 19/11/2026. 15 cartons / feuille A4 PAYSAGE.
La maquette est reprise TELLE QUELLE comme fond (2 tons francs, Konica).
Règle : un numéro par cercle, de gauche à droite (en zigzag haut/bas) :
   B 1-15 · I 16-30 · N 31-45 · G 46-60 · O 61-75 -> crieur 1 à 75.
Chiffres en Latin Modern (écriture maison), noirs, le plus gros que le cercle permet."""
import io, os as _os, random
from reportlab.pdfgen import canvas
from reportlab.lib.pagesizes import A4, landscape
from reportlab.lib import colors
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont

PAGE_W, PAGE_H = landscape(A4)
CARTES_PAGE = 15
PLAGES = [(1, 15), (16, 30), (31, 45), (46, 60), (61, 75)]
NOIR = colors.Color(0.08, 0.08, 0.08)
GRIS_TRAIT = colors.Color(0.40, 0.40, 0.40)
RAINBOW = ["#E53935", "#FB8C00", "#F9A825", "#43A047", "#00ACC1",
           "#1E88E5", "#3949AB", "#8E24AA", "#D81B60", "#6D4C41"]
_ICI = _os.path.dirname(_os.path.abspath(__file__))
POLICE, _CAP, _L88 = "Helvetica-Bold", 0.717, 1.112
try:
    pdfmetrics.registerFont(TTFont("LMROMAN", _os.path.join(_ICI, "LatinModern.ttf")))
    POLICE, _CAP, _L88 = "LMROMAN", 0.644, 1.0
except Exception:
    pass
_IMG_W, _IMG_H = 1482.0, 1048.0
_IMG_FOND = _os.path.join(_ICI, "tahaa_fond.png")
MARGE_SURE = 6 * 72 / 25.4
ECHELLE = min((PAGE_W - 2 * MARGE_SURE) / PAGE_W, (PAGE_H - 2 * MARGE_SURE) / PAGE_H)
DECAL_X = (PAGE_W - PAGE_W * ECHELLE) / 2.0
DECAL_Y = (PAGE_H - PAGE_H * ECHELLE) / 2.0

CARTONS = [
    {'ronds': [(113.4, 61.900000000000006, 38.9), (179.1, 144.2, 39.6), (256.8, 61.7, 39.0), (328.4, 143.9, 39.5), (400.8, 61.5, 39.0)], 'serie': (253.8, 179.8)},
    {'ronds': [(601.9, 61.900000000000006, 39.0), (665.4, 144.0, 39.3), (740.8, 61.7, 39.1), (812.7, 143.6, 39.5), (882.4, 61.8, 39.0)], 'serie': (739.0, 179.3)},
    {'ronds': [(1087.3, 61.599999999999994, 39.0), (1151.0, 143.9, 39.9), (1228.4, 61.400000000000006, 38.7), (1299.9, 143.5, 39.5), (1371.5, 61.5, 38.9)], 'serie': (1225.5, 179.8)},
    {'ronds': [(113.5, 265.9, 38.7), (178.7, 348.7, 39.2), (256.1, 265.7, 39.3), (328.0, 348.4, 39.7), (399.3, 265.8, 39.3)], 'serie': (253.3, 384.1)},
    {'ronds': [(602.0, 265.9, 39.0), (665.2, 348.7, 39.2), (741.2, 265.7, 39.2), (812.8, 348.3, 39.7), (883.5, 265.9, 38.3)], 'serie': (739.0, 384.0)},
    {'ronds': [(1086.4, 265.9, 39.0), (1150.4, 348.6, 39.0), (1227.8, 265.8, 39.1), (1299.8, 348.4, 39.5), (1370.9, 265.9, 39.3)], 'serie': (1225.1, 383.9)},
    {'ronds': [(113.4, 475.1, 38.8), (179.3, 556.7, 39.5), (256.0, 474.8, 39.3), (328.2, 556.4, 39.5), (399.5, 475.1, 39.0)], 'serie': (253.8, 592.2)},
    {'ronds': [(601.8, 475.0, 38.9), (665.7, 556.4, 39.3), (741.1, 474.8, 39.1), (812.9, 556.3, 39.7), (882.6, 475.0, 39.0)], 'serie': (739.3, 592.0)},
    {'ronds': [(1085.9, 475.0, 39.3), (1150.9, 556.6, 39.5), (1227.2, 474.8, 39.0), (1299.8, 556.4, 39.3), (1370.7, 475.0, 39.0)], 'serie': (1225.3, 592.1)},
    {'ronds': [(113.7, 683.2, 38.9), (178.7, 764.8, 39.3), (256.3, 683.2, 39.1), (328.1, 764.6, 39.7), (399.7, 683.3, 39.0)], 'serie': (253.4, 800.3)},
    {'ronds': [(601.4, 683.6, 38.7), (665.2, 764.7, 39.3), (741.4, 683.5, 38.9), (812.8, 764.5, 39.6), (884.0, 683.4, 39.1)], 'serie': (739.0, 800.1)},
    {'ronds': [(1086.5, 683.2, 39.0), (1150.5, 764.7, 39.1), (1227.8, 683.2, 39.2), (1299.7, 764.5, 39.3), (1371.1, 683.4, 39.2)], 'serie': (1225.1, 799.8)},
    {'ronds': [(113.3, 886.7, 38.7), (179.4, 967.2, 39.3), (255.0, 887.3, 39.2), (327.8, 966.9, 39.6), (398.1, 886.5, 38.7)], 'serie': (253.6, 1002.5)},
    {'ronds': [(600.7, 886.7, 38.5), (665.6, 966.9, 39.2), (740.4, 886.3, 38.2), (811.8, 966.6, 39.3), (881.6, 886.6, 38.4)], 'serie': (738.7, 1002.1)},
    {'ronds': [(1085.8, 886.7, 38.7), (1150.6, 967.0, 39.1), (1226.8, 887.3, 39.0), (1299.4, 966.9, 39.0), (1370.3, 886.7, 38.7)], 'serie': (1225.0, 1002.1)},
]


def _px(x):
    return x / _IMG_W * PAGE_W


def _py(y):
    return PAGE_H * (1 - y / _IMG_H)


def _taille_max():
    r = _px(min(rd[2] for ct in CARTONS for rd in ct["ronds"]) - 4) - _px(0)
    t = 10.0
    while True:
        t2 = t + 0.5
        if (_L88 * t2 / 2.0) ** 2 + (_CAP * t2 / 2.0) ** 2 > r ** 2:
            return t
        t = t2


TAILLE = _taille_max()


def _numeros(rng, deja=None):
    while True:
        d = tuple(rng.randint(a, b) for a, b in PLAGES)
        if deja is None or d not in deja:
            if deja is not None:
                deja.add(d)
            return d


def generer_pdf(nb_cartes=None, nb_tickets=None, serie_start=1, theme="", couleur=True,
                nom_evenement="", titre_jeu="", couleur_perso="", date_lieu="",
                telephone="", page_start=1, evenement_id="", style="", motif="",
                _deja=None, **_ig):
    n_ = nb_cartes if nb_cartes is not None else nb_tickets
    n_ = max(1, int(n_ if n_ else CARTES_PAGE))
    buf = io.BytesIO()
    c = canvas.Canvas(buf, pagesize=(PAGE_W, PAGE_H), pageCompression=1)
    c.setTitle("TAHAA")
    rng = random.Random(int(serie_start) * 100003 + 7575)
    deja = _deja if _deja is not None else set()
    serie = int(serie_start)
    faits = 0
    try:
        no_page = max(1, int(page_start))
    except Exception:
        no_page = 1
    col_imposee = None
    if couleur and couleur_perso:
        try:
            col_imposee = colors.HexColor(couleur_perso)
        except Exception:
            col_imposee = None
    while faits < n_:
        c.saveState()
        c.translate(DECAL_X, DECAL_Y)
        c.scale(ECHELLE, ECHELLE)
        try:
            c.drawImage(_IMG_FOND, 0, 0, PAGE_W, PAGE_H, preserveAspectRatio=False, mask="auto")
        except Exception:
            pass
        for idx in range(CARTES_PAGE):
            if faits >= n_:
                break
            ct = CARTONS[idx]
            col = (col_imposee or colors.HexColor(RAINBOW[serie % len(RAINBOW)])) if couleur else NOIR
            nums = _numeros(rng, deja)
            c.saveState()
            c.setFillColor(col)
            c.setStrokeColor(col)
            c.setLineWidth(0.25)
            c.setLineJoin(1)
            for (x, y, r), v in zip(ct["ronds"], nums):
                o = c.beginText()
                o.setTextRenderMode(2)
                o.setFont(POLICE, TAILLE)
                o.setTextOrigin(_px(x) - c.stringWidth(str(v), POLICE, TAILLE) / 2.0,
                                _py(y) - TAILLE * _CAP / 2.0)
                o.textOut(str(v))
                c.drawText(o)
            c.restoreState()
            sx, sy = ct["serie"]
            c.setFillColor(GRIS_TRAIT)
            c.setFont("Helvetica", 5.5)
            c.drawCentredString(_px(sx), _py(sy), "N° %06d" % serie)
            serie += 1
            faits += 1
        c.restoreState()
        c.setFillColor(GRIS_TRAIT)
        c.setFont("Helvetica", 6)
        c.drawRightString(PAGE_W - 13.5, 20, "%d" % no_page)
        no_page += 1
        c.showPage()
    c.save()
    buf.seek(0)
    return buf
