# -*- coding: utf-8 -*-
"""MANAPRINT — DUAL DAB 75 (maquette de Maeva du 20/11/2026, 4 tickets / A4 PAYSAGE — chiffres au maximum).

La maquette (titre DUAL DAB, capsules, éclairs, talon « VOTRE JEU »,
bandeau « N° ★ 89 22 23 05 ») est reprise TELLE QUELLE comme fond, en 2 tons
francs (gris uni, propre sur la Konica) ; le « 00001 » est gommé et réécrit.
Règle (DUAL DAB 75, juillet) — 9 numéros :
   en haut à gauche  : 2 capsules reliées « ↔ »  -> paire 1-15
   en haut à droite  : capsule longue « / »      -> paire 16-30
   en bas à gauche   : capsule longue « / »      -> paire 31-45
   en bas à droite   : 2 capsules reliées « ↔ »  -> paire 46-60
   au centre         : la grande capsule         -> 1 numéro 61-75
Chaque paire est triée (le petit à gauche). Crieur 1 à 75.
Chiffres LATIN MODERN GRAS noirs, grossis au maximum dans chaque capsule.
"""
import io, os as _os, random
from reportlab.pdfgen import canvas
from reportlab.lib.pagesizes import A4, landscape
from reportlab.lib import colors
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont

PAGE_W, PAGE_H = landscape(A4)   # ⭐ 20/11 : 4 tickets / A4 paysage, chiffres 1,45 fois plus gros
CARTES_PAGE = 4
NOIR = colors.Color(0.08, 0.08, 0.08)
GRIS = colors.Color(0.40, 0.40, 0.40)
RAINBOW = ["#E53935", "#FB8C00", "#F9A825", "#43A047", "#00ACC1",
           "#1E88E5", "#3949AB", "#8E24AA", "#D81B60", "#6D4C41"]

_ICI = _os.path.dirname(_os.path.abspath(__file__))
POLICE, _CAP = "Times-Bold", 0.66
try:
    pdfmetrics.registerFont(TTFont("LMROMANB", _os.path.join(_ICI, "LatinModern-Bold.ttf")))
    POLICE, _CAP = "LMROMANB", 0.686
except Exception:
    pass
_FOND = _os.path.join(_ICI, "dual_dab_fond.png")

# ── placement : 2 colonnes x 4 rangées dans la marge sûre de 6 mm ─────────
MARGE = 6 * 72 / 25.4
GOUT_X, GOUT_Y = 8.0, 8.0
IMG_W, IMG_H = 1536.0, 1024.0
TW = (PAGE_W - 2 * MARGE - GOUT_X) / 2.0
TH = TW * IMG_H / IMG_W
_Y_LIBRE = PAGE_H - 2 * MARGE - 2 * TH - 1 * GOUT_Y
Y_HAUT = PAGE_H - MARGE - _Y_LIBRE / 2.0          # le bloc est centré en hauteur

# capsules (x0, y0, x1, y1) px sur la maquette ; (plage, cases)
POSTES = [
    ((1, 15),  [(271, 297, 419, 446), (541, 297, 686, 445)]),
    ((16, 30), [(1000, 301, 1196, 446), (1242, 301, 1446, 446)]),
    ((31, 45), [(283, 741, 466, 884), (510, 741, 693, 884)]),
    ((46, 60), [(1003, 730, 1154, 883), (1275, 730, 1424, 883)]),
    ((61, 75), [(714, 446, 963, 695)]),
]
T_ROND = 30.0      # pt — petites capsules rondes (au bord de la dentelure)
T_LONG = 36.0      # pt — capsules longues
T_CENTRE = 49.0    # pt — la grande capsule du centre
SERIE_X, SERIE_Y = 666.0, 982.0    # px — place du n° dans le bandeau noir


def _tirage(rng):
    return [sorted(rng.sample(range(a, b + 1), len(cases))) for (a, b), cases in POSTES]


def _num(c, txt, x, yc, t):
    c.setLineWidth(0.026 * t)
    o = c.beginText()
    o.setTextRenderMode(2)
    o.setFont(POLICE, t)
    o.setTextOrigin(x - c.stringWidth(txt, POLICE, t) / 2.0, yc - t * _CAP / 2.0)
    o.textOut(txt)
    c.drawText(o)


def _ticket(c, x0, y0, nums, serie, col):
    """x0, y0 = coin BAS-gauche du ticket (points)."""
    k = TW / IMG_W
    px = lambda x: x0 + x * k
    py = lambda y: y0 + TH - y * k
    c.drawImage(_FOND, x0, y0, TW, TH, preserveAspectRatio=False, mask="auto")
    c.saveState()
    c.setFillColor(col)
    c.setStrokeColor(col)
    c.setLineJoin(1)
    for pi, ((a, b), cases) in enumerate(POSTES):
        for (bx0, by0, bx1, by1), v in zip(cases, nums[pi]):
            if pi == 4:
                t = T_CENTRE
            elif pi in (1, 2):
                t = T_LONG
            else:
                t = T_ROND
            _num(c, str(v), px((bx0 + bx1) / 2.0), py((by0 + by1) / 2.0), t)
    c.restoreState()
    c.setFillColor(colors.white)
    c.setFont("Helvetica-Bold", 11)
    c.drawCentredString(px(SERIE_X), py(SERIE_Y), "%05d" % serie)


def generer_pdf(nb_cartes=None, nb_tickets=None, serie_start=1, theme="", couleur=True,
                nom_evenement="", titre_jeu="", couleur_perso="", date_lieu="",
                telephone="", page_start=1, evenement_id="", style="", motif="",
                _deja=None, **_ig):
    n_ = nb_cartes if nb_cartes is not None else nb_tickets
    n_ = max(1, int(n_ if n_ else CARTES_PAGE))
    buf = io.BytesIO()
    c = canvas.Canvas(buf, pagesize=(PAGE_W, PAGE_H), pageCompression=1)
    c.setTitle("DUAL DAB 75")
    rng = random.Random(int(serie_start) * 100003 + 7575)
    deja = _deja if _deja is not None else set()
    col_imposee = None
    if couleur and couleur_perso:
        try:
            col_imposee = colors.HexColor(couleur_perso)
        except Exception:
            col_imposee = None
    try:
        no_page = max(1, int(page_start))
    except Exception:
        no_page = 1
    serie = int(serie_start)
    faits = 0
    while faits < n_:
        for k in range(CARTES_PAGE):
            if faits >= n_:
                break
            ligne, colonne = divmod(k, 2)
            x0 = MARGE + colonne * (TW + GOUT_X)
            y0 = Y_HAUT - (ligne + 1) * TH - ligne * GOUT_Y
            while True:
                nums = _tirage(rng)
                cle = tuple(v for p in nums for v in p)
                if cle not in deja:
                    deja.add(cle)
                    break
            col = (col_imposee or colors.HexColor(RAINBOW[serie % len(RAINBOW)])) if couleur else NOIR
            _ticket(c, x0, y0, nums, serie, col)
            serie += 1
            faits += 1
        c.setFillColor(GRIS)
        c.setFont("Helvetica", 7)
        c.drawRightString(PAGE_W - MARGE, PAGE_H - MARGE + 2, "%d" % no_page)
        no_page += 1
        c.showPage()
    c.save()
    buf.seek(0)
    return buf


if __name__ == "__main__":
    open("test_dual_dab.pdf", "wb").write(generer_pdf(nb_cartes=8, couleur=False).read())
    print("DUAL DAB genere")
