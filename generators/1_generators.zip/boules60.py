# -*- coding: utf-8 -*-
"""MANAPRINT — 60 BOULES (refait le 18/11/2026 sur la maquette de Maeva).
12 cartons par feuille A4 PORTRAIT. La maquette est reprise TELLE QUELLE comme
fond, en 2 tons francs (rendu propre sur la Konica) ; on n'ajoute que les
chiffres, le n° de série et le n° de page.
Règle : 4 colonnes : 1-15 · 16-30 · 31-45 · 46-60, 2 numéros par colonne, le petit en haut = 8 boules. Crieur 1-60.
Chiffres en Latin Modern (écriture maison), NOIRS, le plus gros possible avec de l'air dans la case.
Feuille ramenée à 6 mm des bords (la Konica n'imprime pas les 4,2 mm du bord)."""
import io, os as _os, random
from reportlab.pdfgen import canvas
from reportlab.lib.pagesizes import A4, landscape
from reportlab.lib import colors

PAGE_W, PAGE_H = A4
CARTES_PAGE = 12
PLAGES = [(1, 15), (16, 30), (31, 45), (46, 60)]
PAR_COLONNE = [2, 2, 2, 2]
NOIR = colors.Color(0.08, 0.08, 0.08)
GRIS_TRAIT = colors.Color(0.40, 0.40, 0.40)
RAINBOW = ["#E53935", "#FB8C00", "#F9A825", "#43A047", "#00ACC1",
           "#1E88E5", "#3949AB", "#8E24AA", "#D81B60", "#6D4C41"]
POLICE, _CAP, _LARG88 = "Helvetica-Bold", 0.717, 1.112
# ⭐ 18/11 (Maeva : « ces jeux avaient déjà leurs propres écritures ») :
#    l'écriture maison des planches ÉCO = LATIN MODERN ROMAN (comme RAI, KEA, P6).
try:
    from reportlab.pdfbase import pdfmetrics as _pm
    from reportlab.pdfbase.ttfonts import TTFont as _TF
    import os as _o
    _pm.registerFont(_TF("LMROMAN", _o.path.join(_o.path.dirname(_o.path.abspath(__file__)), "LatinModern.ttf")))
    POLICE, _CAP, _LARG88 = "LMROMAN", 0.644, 1.0
except Exception:
    pass
_ICI = _os.path.dirname(_os.path.abspath(__file__))
_IMG_W, _IMG_H = 1103.0, 1560.0
_IMG_FOND = _os.path.join(_ICI, "boules60_fond_v2.png")
MARGE_SURE = 6 * 72 / 25.4
ECHELLE = min((PAGE_W - 2 * MARGE_SURE) / PAGE_W, (PAGE_H - 2 * MARGE_SURE) / PAGE_H)
DECAL_X = (PAGE_W - PAGE_W * ECHELLE) / 2.0
DECAL_Y = (PAGE_H - PAGE_H * ECHELLE) / 2.0

# pour chaque carton : les cases (x0, y0, x1, y1) px, colonne par colonne,
# de haut en bas ; serie = (x0, y0, x1, y1) px de la place du n° de série.
CARTONS = [
    {'cols': [[(56, 154, 172, 225), (56, 227, 172, 296)], [(175, 154, 290, 225), (175, 227, 290, 296)], [(292, 154, 407, 225), (292, 227, 407, 296)], [(409, 154, 526, 225), (409, 227, 526, 296)]], 'serie': (319, 306, 384, 314)},
    {'cols': [[(577, 154, 694, 225), (577, 227, 694, 296)], [(696, 154, 811, 225), (696, 227, 811, 296)], [(813, 154, 928, 225), (813, 227, 928, 296)], [(931, 154, 1048, 225), (931, 227, 1048, 296)]], 'serie': (841, 305, 906, 314)},
    {'cols': [[(56, 379, 172, 450), (56, 452, 172, 522)], [(175, 379, 290, 450), (175, 452, 290, 522)], [(292, 379, 407, 450), (292, 452, 407, 522)], [(409, 379, 526, 450), (409, 452, 526, 522)]], 'serie': (319, 530, 384, 540)},
    {'cols': [[(577, 379, 694, 450), (577, 452, 694, 522)], [(696, 379, 811, 450), (696, 452, 811, 522)], [(813, 379, 928, 450), (813, 452, 928, 522)], [(931, 379, 1048, 450), (931, 452, 1048, 522)]], 'serie': (840, 531, 905, 540)},
    {'cols': [[(56, 605, 172, 676), (56, 678, 172, 748)], [(175, 605, 290, 676), (175, 678, 290, 748)], [(292, 605, 407, 676), (292, 678, 407, 748)], [(409, 605, 526, 676), (409, 678, 526, 748)]], 'serie': (319, 757, 384, 766)},
    {'cols': [[(577, 605, 694, 676), (577, 678, 694, 748)], [(696, 605, 811, 676), (696, 678, 811, 748)], [(813, 605, 928, 676), (813, 678, 928, 748)], [(931, 605, 1048, 676), (931, 678, 1048, 748)]], 'serie': (841, 757, 906, 766)},
    {'cols': [[(56, 830, 173, 901), (56, 903, 173, 973)], [(175, 830, 290, 901), (175, 903, 290, 973)], [(292, 830, 407, 901), (292, 903, 407, 973)], [(409, 830, 526, 901), (409, 903, 526, 973)]], 'serie': (319, 982, 384, 991)},
    {'cols': [[(577, 830, 694, 901), (577, 903, 694, 973)], [(696, 830, 811, 901), (696, 903, 811, 973)], [(813, 830, 928, 901), (813, 903, 929, 973)], [(931, 830, 1048, 901), (931, 903, 1048, 973)]], 'serie': (841, 982, 906, 991)},
    {'cols': [[(56, 1057, 172, 1128), (56, 1130, 172, 1200)], [(175, 1057, 290, 1128), (175, 1130, 290, 1200)], [(292, 1057, 407, 1128), (292, 1130, 407, 1200)], [(409, 1057, 525, 1128), (409, 1130, 526, 1200)]], 'serie': (319, 1209, 384, 1218)},
    {'cols': [[(577, 1057, 694, 1128), (577, 1130, 694, 1200)], [(696, 1057, 811, 1128), (696, 1130, 811, 1200)], [(813, 1057, 928, 1128), (813, 1130, 928, 1200)], [(931, 1057, 1048, 1128), (931, 1130, 1048, 1200)]], 'serie': (840, 1209, 905, 1218)},
    {'cols': [[(56, 1284, 172, 1354), (56, 1356, 172, 1427)], [(175, 1284, 290, 1354), (175, 1356, 290, 1427)], [(292, 1284, 407, 1354), (292, 1356, 407, 1427)], [(409, 1284, 526, 1354), (409, 1356, 525, 1427)]], 'serie': (319, 1435, 384, 1444)},
    {'cols': [[(577, 1284, 694, 1354), (577, 1356, 694, 1427)], [(696, 1284, 811, 1354), (696, 1356, 811, 1427)], [(813, 1284, 928, 1354), (813, 1356, 928, 1427)], [(931, 1284, 1048, 1354), (931, 1356, 1048, 1427)]], 'serie': (840, 1436, 905, 1444)},
]
ALIGN_SERIE = "L"
AIR_H, AIR_W = 0.70, 0.80   # part de la case que « 88 » peut occuper


def _px(x):
    return x / _IMG_W * PAGE_W


def _py(y):
    return PAGE_H * (1 - y / _IMG_H)


def _taille_case(x0, y0, x1, y1):
    h = _px(y1) - _px(y0)
    w = _px(x1) - _px(x0)
    t = min(AIR_H * h / _CAP, AIR_W * w / _LARG88)
    return int(t * 2) / 2.0


# une taille par « famille » de cases (même hauteur), la plus petite de la famille
_TAILLES = {}
for _ct in CARTONS:
    for _col in _ct["cols"]:
        for _c in _col:
            _k = round((_c[3] - _c[1]) / 20.0)
            _TAILLES[_k] = min(_TAILLES.get(_k, 999), _taille_case(*_c))


def _taille(c):
    return _TAILLES[round((c[3] - c[1]) / 20.0)]


def _numeros(rng, deja=None):
    while True:
        d = [sorted(rng.sample(range(a, b + 1), n)) for (a, b), n in zip(PLAGES, PAR_COLONNE)]
        cle = tuple(v for p in d for v in p)
        if deja is None or cle not in deja:
            if deja is not None:
                deja.add(cle)
            return d


def _num(c, txt, x, y, t):
    o = c.beginText()
    o.setTextRenderMode(2)
    o.setFont(POLICE, t)
    o.setTextOrigin(x - c.stringWidth(txt, POLICE, t) / 2.0, y)
    o.textOut(txt)
    c.drawText(o)


def generer_pdf(nb_cartes=None, nb_tickets=None, serie_start=1, theme="", couleur=True,
                nom_evenement="", titre_jeu="", couleur_perso="", date_lieu="",
                telephone="", page_start=1, evenement_id="", style="", motif="",
                _deja=None, **_ig):
    n_ = nb_cartes if nb_cartes is not None else nb_tickets
    n_ = max(1, int(n_ if n_ else CARTES_PAGE))
    buf = io.BytesIO()
    c = canvas.Canvas(buf, pagesize=(PAGE_W, PAGE_H), pageCompression=1)
    c.setTitle("60 BOULES")
    rng = random.Random(int(serie_start) * 100003 + 6060)
    deja = _deja if _deja is not None else set()
    serie = int(serie_start)
    faits = 0
    try:
        no_page = max(1, int(page_start))
    except Exception:
        no_page = 1
    col_imposee = None
    if couleur and couleur_perso:
        try:
            col_imposee = colors.HexColor(couleur_perso)
        except Exception:
            col_imposee = None
    while faits < n_:
        c.saveState()
        c.translate(DECAL_X, DECAL_Y)
        c.scale(ECHELLE, ECHELLE)
        try:
            c.drawImage(_IMG_FOND, 0, 0, PAGE_W, PAGE_H, preserveAspectRatio=False, mask="auto")
        except Exception:
            pass
        entete = "  ·  ".join(t for t in ((nom_evenement or "").strip(),
                                          (date_lieu or "").strip(),
                                          (telephone or "").strip()) if t)
        for idx in range(CARTES_PAGE):
            if faits >= n_:
                break
            ct = CARTONS[idx]
            col = (col_imposee or colors.HexColor(RAINBOW[serie % len(RAINBOW)])) if couleur else NOIR
            nums = _numeros(rng, deja)
            c.saveState()
            c.setFillColor(col)
            c.setStrokeColor(col)
            c.setLineWidth(0.25)
            c.setLineJoin(1)
            for cases, vals in zip(ct["cols"], nums):
                for (x0, y0, x1, y1), v in zip(cases, vals):
                    t = _taille((x0, y0, x1, y1))
                    _num(c, str(v), _px((x0 + x1) / 2.0), _py((y0 + y1) / 2.0) - t * _CAP / 2.0, t)
            c.restoreState()
            sx0, sy0, sx1, sy1 = ct["serie"]
            ts = min(9.0, (_px(sy1) - _px(sy0)) / 0.72)
            c.setFillColor(GRIS_TRAIT)
            c.setFont("Helvetica-Bold", ts)
            if ALIGN_SERIE == "R":
                c.drawRightString(_px(sx1), _py(sy1), "%06d" % serie)
            else:
                c.drawString(_px(sx0), _py(sy1), "%06d" % serie)
            serie += 1
            faits += 1
        c.restoreState()
        # n° de page (et personnalisation) dans la marge que la Konica imprime
        c.setFillColor(GRIS_TRAIT)
        c.setFont("Helvetica", 6)
        c.drawRightString(PAGE_W - 17, PAGE_H - 19, "%d" % no_page)
        if entete:
            c.setFont("Helvetica-Bold", 6.5)
            c.drawCentredString(PAGE_W / 2.0, PAGE_H - 13.5, entete)
        no_page += 1
        c.showPage()
    c.save()
    buf.seek(0)
    return buf


if __name__ == "__main__":
    open("test.pdf", "wb").write(generer_pdf(nb_cartes=CARTES_PAGE, couleur=False).read())
