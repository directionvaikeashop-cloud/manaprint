# -*- coding: utf-8 -*-
"""MANAPRINT — WIN 9 boules (refait le 18/11/2026 sur la maquette de Maeva).
16 cartons par feuille A4 PAYSAGE. La maquette est reprise TELLE QUELLE comme
fond, en 2 tons francs (rendu propre sur la Konica) ; on n'ajoute que les
chiffres, le n° de série et le n° de page.
Règle : col 1-15 · col 16-30 · col 31-45, 3 numéros par colonne, le petit en haut. Crieur 1-45.
Chiffres en Latin Modern (écriture maison), NOIRS, le plus gros possible avec de l'air dans la case.
Feuille ramenée à 6 mm des bords (la Konica n'imprime pas les 4,2 mm du bord)."""
import io, os as _os, random
from reportlab.pdfgen import canvas
from reportlab.lib.pagesizes import A4, landscape
from reportlab.lib import colors

PAGE_W, PAGE_H = landscape(A4)
CARTES_PAGE = 16
PLAGES = [(1, 15), (16, 30), (31, 45)]
PAR_COLONNE = [3, 3, 3]
NOIR = colors.Color(0.08, 0.08, 0.08)
GRIS_TRAIT = colors.Color(0.40, 0.40, 0.40)
RAINBOW = ["#E53935", "#FB8C00", "#F9A825", "#43A047", "#00ACC1",
           "#1E88E5", "#3949AB", "#8E24AA", "#D81B60", "#6D4C41"]
POLICE, _CAP, _LARG88 = "Helvetica-Bold", 0.717, 1.112
# ⭐ 18/11 (Maeva : « ces jeux avaient déjà leurs propres écritures ») :
#    l'écriture maison des planches ÉCO = LATIN MODERN ROMAN (comme RAI, KEA, P6).
try:
    from reportlab.pdfbase import pdfmetrics as _pm
    from reportlab.pdfbase.ttfonts import TTFont as _TF
    import os as _o
    _pm.registerFont(_TF("LMROMAN", _o.path.join(_o.path.dirname(_o.path.abspath(__file__)), "LatinModern.ttf")))
    POLICE, _CAP, _LARG88 = "LMROMAN", 0.644, 1.0
except Exception:
    pass
_ICI = _os.path.dirname(_os.path.abspath(__file__))
_IMG_W, _IMG_H = 1536.0, 1086.0
_IMG_FOND = _os.path.join(_ICI, "win_fond.png")
MARGE_SURE = 6 * 72 / 25.4
ECHELLE = min((PAGE_W - 2 * MARGE_SURE) / PAGE_W, (PAGE_H - 2 * MARGE_SURE) / PAGE_H)
DECAL_X = (PAGE_W - PAGE_W * ECHELLE) / 2.0
DECAL_Y = (PAGE_H - PAGE_H * ECHELLE) / 2.0

# pour chaque carton : les cases (x0, y0, x1, y1) px, colonne par colonne,
# de haut en bas ; serie = (x0, y0, x1, y1) px de la place du n° de série.
CARTONS = [
    {'cols': [[(39, 89, 150, 147), (39, 150, 149, 209), (39, 211, 150, 271)], [(152, 89, 269, 147), (152, 150, 269, 209), (152, 211, 269, 271)], [(272, 89, 385, 147), (272, 150, 385, 209), (272, 211, 385, 271)]], 'serie': (73, 61, 135, 76)},
    {'cols': [[(414, 89, 525, 147), (414, 150, 525, 209), (414, 211, 525, 271)], [(527, 89, 641, 147), (527, 150, 640, 209), (527, 211, 640, 271)], [(643, 89, 755, 147), (643, 150, 755, 209), (643, 211, 755, 271)]], 'serie': (448, 61, 510, 76)},
    {'cols': [[(781, 89, 891, 147), (781, 150, 891, 209), (781, 211, 891, 271)], [(894, 89, 1007, 147), (894, 150, 1007, 209), (894, 211, 1007, 271)], [(1009, 89, 1122, 147), (1009, 150, 1122, 209), (1009, 211, 1122, 271)]], 'serie': (815, 61, 877, 76)},
    {'cols': [[(1152, 89, 1263, 147), (1152, 150, 1263, 209), (1152, 211, 1263, 271)], [(1266, 89, 1382, 147), (1266, 150, 1382, 209), (1266, 211, 1382, 271)], [(1384, 89, 1496, 147), (1384, 150, 1496, 209), (1384, 211, 1496, 271)]], 'serie': (1186, 61, 1248, 76)},
    {'cols': [[(39, 338, 150, 396), (39, 398, 149, 459), (39, 461, 149, 521)], [(152, 338, 269, 396), (152, 398, 269, 459), (152, 461, 269, 521)], [(272, 338, 385, 396), (272, 398, 385, 459), (272, 461, 385, 521)]], 'serie': (73, 310, 135, 325)},
    {'cols': [[(414, 338, 525, 396), (414, 398, 525, 459), (414, 461, 525, 521)], [(527, 338, 640, 396), (527, 398, 640, 459), (527, 461, 641, 521)], [(643, 338, 755, 396), (643, 398, 755, 459), (643, 461, 755, 521)]], 'serie': (448, 310, 510, 325)},
    {'cols': [[(781, 338, 891, 396), (781, 398, 891, 459), (781, 461, 891, 521)], [(894, 338, 1007, 396), (894, 398, 1007, 459), (894, 461, 1007, 521)], [(1009, 338, 1122, 396), (1009, 398, 1122, 459), (1009, 461, 1122, 521)]], 'serie': (815, 310, 877, 325)},
    {'cols': [[(1152, 338, 1263, 396), (1152, 398, 1263, 459), (1152, 461, 1263, 521)], [(1266, 338, 1382, 396), (1266, 398, 1382, 459), (1266, 461, 1382, 521)], [(1384, 338, 1496, 396), (1384, 398, 1496, 459), (1384, 461, 1496, 521)]], 'serie': (1186, 310, 1248, 325)},
    {'cols': [[(39, 589, 149, 646), (39, 649, 149, 707), (39, 709, 150, 770)], [(152, 589, 269, 646), (152, 649, 269, 707), (152, 709, 269, 770)], [(272, 589, 385, 646), (272, 649, 385, 707), (272, 710, 385, 770)]], 'serie': (73, 561, 135, 576)},
    {'cols': [[(414, 589, 525, 646), (414, 649, 525, 707), (414, 710, 525, 770)], [(527, 589, 640, 646), (527, 649, 640, 707), (527, 709, 640, 770)], [(643, 589, 755, 646), (643, 649, 755, 707), (643, 710, 755, 770)]], 'serie': (448, 561, 510, 576)},
    {'cols': [[(781, 589, 891, 646), (781, 649, 891, 707), (781, 709, 891, 770)], [(894, 589, 1007, 646), (894, 649, 1007, 707), (894, 709, 1007, 770)], [(1009, 589, 1122, 646), (1009, 649, 1122, 707), (1009, 709, 1122, 770)]], 'serie': (815, 561, 877, 576)},
    {'cols': [[(1152, 589, 1263, 646), (1152, 649, 1263, 707), (1152, 710, 1263, 770)], [(1266, 589, 1382, 646), (1266, 649, 1382, 707), (1266, 709, 1382, 770)], [(1384, 589, 1496, 646), (1384, 649, 1496, 707), (1384, 710, 1496, 770)]], 'serie': (1186, 561, 1248, 576)},
    {'cols': [[(39, 836, 150, 895), (39, 897, 150, 959), (39, 961, 149, 1020)], [(152, 836, 269, 895), (152, 897, 269, 959), (152, 961, 269, 1020)], [(272, 836, 384, 895), (272, 897, 385, 959), (272, 961, 385, 1020)]], 'serie': (73, 808, 135, 823)},
    {'cols': [[(414, 836, 525, 895), (414, 897, 525, 959), (414, 961, 525, 1020)], [(527, 836, 640, 895), (527, 897, 640, 959), (527, 961, 640, 1020)], [(643, 836, 755, 895), (643, 897, 755, 959), (643, 961, 755, 1020)]], 'serie': (448, 808, 510, 823)},
    {'cols': [[(781, 836, 891, 895), (781, 897, 891, 959), (781, 961, 891, 1020)], [(894, 836, 1007, 895), (894, 897, 1007, 959), (894, 961, 1007, 1020)], [(1009, 836, 1122, 895), (1009, 897, 1122, 959), (1009, 961, 1122, 1020)]], 'serie': (815, 808, 877, 823)},
    {'cols': [[(1152, 836, 1263, 895), (1152, 897, 1263, 959), (1152, 961, 1263, 1020)], [(1266, 836, 1382, 895), (1266, 897, 1382, 959), (1266, 961, 1382, 1020)], [(1384, 836, 1496, 895), (1384, 897, 1496, 959), (1384, 961, 1496, 1020)]], 'serie': (1186, 808, 1248, 823)},
]
ALIGN_SERIE = "L"
AIR_H, AIR_W = 0.70, 0.80   # part de la case que « 88 » peut occuper


def _px(x):
    return x / _IMG_W * PAGE_W


def _py(y):
    return PAGE_H * (1 - y / _IMG_H)


def _taille_case(x0, y0, x1, y1):
    h = _px(y1) - _px(y0)
    w = _px(x1) - _px(x0)
    t = min(AIR_H * h / _CAP, AIR_W * w / _LARG88)
    return int(t * 2) / 2.0


# une taille par « famille » de cases (même hauteur), la plus petite de la famille
_TAILLES = {}
for _ct in CARTONS:
    for _col in _ct["cols"]:
        for _c in _col:
            _k = round((_c[3] - _c[1]) / 20.0)
            _TAILLES[_k] = min(_TAILLES.get(_k, 999), _taille_case(*_c))


def _taille(c):
    return _TAILLES[round((c[3] - c[1]) / 20.0)]


def _numeros(rng, deja=None):
    while True:
        d = [sorted(rng.sample(range(a, b + 1), n)) for (a, b), n in zip(PLAGES, PAR_COLONNE)]
        cle = tuple(v for p in d for v in p)
        if deja is None or cle not in deja:
            if deja is not None:
                deja.add(cle)
            return d


def _num(c, txt, x, y, t):
    o = c.beginText()
    o.setTextRenderMode(2)
    o.setFont(POLICE, t)
    o.setTextOrigin(x - c.stringWidth(txt, POLICE, t) / 2.0, y)
    o.textOut(txt)
    c.drawText(o)


def generer_pdf(nb_cartes=None, nb_tickets=None, serie_start=1, theme="", couleur=True,
                nom_evenement="", titre_jeu="", couleur_perso="", date_lieu="",
                telephone="", page_start=1, evenement_id="", style="", motif="",
                _deja=None, **_ig):
    n_ = nb_cartes if nb_cartes is not None else nb_tickets
    n_ = max(1, int(n_ if n_ else CARTES_PAGE))
    buf = io.BytesIO()
    c = canvas.Canvas(buf, pagesize=(PAGE_W, PAGE_H), pageCompression=1)
    c.setTitle("WIN 9 boules")
    rng = random.Random(int(serie_start) * 100003 + 4545)
    deja = _deja if _deja is not None else set()
    serie = int(serie_start)
    faits = 0
    try:
        no_page = max(1, int(page_start))
    except Exception:
        no_page = 1
    col_imposee = None
    if couleur and couleur_perso:
        try:
            col_imposee = colors.HexColor(couleur_perso)
        except Exception:
            col_imposee = None
    while faits < n_:
        c.saveState()
        c.translate(DECAL_X, DECAL_Y)
        c.scale(ECHELLE, ECHELLE)
        try:
            c.drawImage(_IMG_FOND, 0, 0, PAGE_W, PAGE_H, preserveAspectRatio=False, mask="auto")
        except Exception:
            pass
        entete = "  ·  ".join(t for t in ((nom_evenement or "").strip(),
                                          (date_lieu or "").strip(),
                                          (telephone or "").strip()) if t)
        for idx in range(CARTES_PAGE):
            if faits >= n_:
                break
            ct = CARTONS[idx]
            col = (col_imposee or colors.HexColor(RAINBOW[serie % len(RAINBOW)])) if couleur else NOIR
            nums = _numeros(rng, deja)
            c.saveState()
            c.setFillColor(col)
            c.setStrokeColor(col)
            c.setLineWidth(0.25)
            c.setLineJoin(1)
            for cases, vals in zip(ct["cols"], nums):
                for (x0, y0, x1, y1), v in zip(cases, vals):
                    t = _taille((x0, y0, x1, y1))
                    _num(c, str(v), _px((x0 + x1) / 2.0), _py((y0 + y1) / 2.0) - t * _CAP / 2.0, t)
            c.restoreState()
            sx0, sy0, sx1, sy1 = ct["serie"]
            ts = min(9.0, (_px(sy1) - _px(sy0)) / 0.72)
            c.setFillColor(GRIS_TRAIT)
            c.setFont("Helvetica-Bold", ts)
            if ALIGN_SERIE == "R":
                c.drawRightString(_px(sx1), _py(sy1), "%06d" % serie)
            else:
                c.drawString(_px(sx0), _py(sy1), "%06d" % serie)
            serie += 1
            faits += 1
        c.restoreState()
        # n° de page (et personnalisation) dans la marge que la Konica imprime
        c.setFillColor(GRIS_TRAIT)
        c.setFont("Helvetica", 6)
        c.drawRightString(PAGE_W - 13.5, 20, "%d" % no_page)
        if entete:
            c.setFont("Helvetica-Bold", 6.5)
            c.drawCentredString(PAGE_W / 2.0, PAGE_H - 13.5, entete)
        no_page += 1
        c.showPage()
    c.save()
    buf.seek(0)
    return buf


if __name__ == "__main__":
    open("test.pdf", "wb").write(generer_pdf(nb_cartes=CARTES_PAGE, couleur=False).read())


# ⭐ 21/11 : les variantes spéciales restent celles d'avant (fichier win_v1.py, inchangé)
def generer_pdf_casino(**kw):
    try:
        from generators import win_v1 as _v1
    except Exception:
        import win_v1 as _v1
    return _v1.generer_pdf_casino(**kw)

