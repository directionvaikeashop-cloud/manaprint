# -*- coding: utf-8 -*-
"""MANAPRINT — ROYAL 6 boules (planche de Maeva, refait le 19/11/2026).
10 cartons par feuille A4 PORTRAIT. La planche est reprise TELLE QUELLE comme
fond (trait gris uni, sans aplat gris taché) ; on n'ajoute que les chiffres, le n° de
série et le n° de page.
Règle : 6 anneaux du collier, un numéro par anneau : en haut de gauche à droite 1-15 · 16-30 · 31-45 · 46-60, en bas de gauche à droite 61-75 · 76-90 (règle supposée, à confirmer par Maeva). Crieur 1-90. Le « 00001 » de la maquette est gommé et réécrit.
Chiffres Latin Modern GRAS, noirs, le plus gros que chaque case permet.
Feuille ramenée à 6 mm des bords (Konica)."""
import io, os as _os, random
from collections import Counter
from reportlab.pdfgen import canvas
from reportlab.lib.pagesizes import A4, landscape
from reportlab.lib import colors
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont

PAGE_W, PAGE_H = A4
CARTES_PAGE = 10
PLAGES = {'A': (1, 15), 'B': (16, 30), 'C': (31, 45), 'D': (46, 60), 'E': (61, 75), 'F': (76, 90)}
NOIR = colors.Color(0.05, 0.05, 0.05)
GRIS_TRAIT = colors.Color(0.40, 0.40, 0.40)
RAINBOW = ["#E53935", "#FB8C00", "#F9A825", "#43A047", "#00ACC1",
           "#1E88E5", "#3949AB", "#8E24AA", "#D81B60", "#6D4C41"]
_ICI = _os.path.dirname(_os.path.abspath(__file__))
POLICE, _CAP = "Helvetica-Bold", 0.717
try:
    pdfmetrics.registerFont(TTFont("LMROMANB", _os.path.join(_ICI, "LatinModern-Bold.ttf")))
    POLICE, _CAP = "LMROMANB", 0.66
except Exception:
    pass
_IMG_W, _IMG_H = 1086.0, 1536.0
_IMG_FOND = _os.path.join(_ICI, "royal_fond_v2.png")
MARGE_SURE = 6 * 72 / 25.4
ECHELLE = min((PAGE_W - 2 * MARGE_SURE) / PAGE_W, (PAGE_H - 2 * MARGE_SURE) / PAGE_H)
DECAL_X = (PAGE_W - PAGE_W * ECHELLE) / 2.0
DECAL_Y = (PAGE_H - PAGE_H * ECHELLE) / 2.0

# cases : (plage, (x0, y0, x1, y1) px), dans l'ordre où les numéros TRIÉS se posent ;
# serie = (alignement, x, ligne de base) px
CARTONS = [
    {'cells': [('A', (106, 81, 169, 143)), ('B', (206, 111, 268, 172)), ('C', (328, 109, 389, 172)), ('D', (425, 80, 488, 143)), ('E', (222, 184, 285, 245)), ('F', (313, 183, 376, 245))], 'serie': ('C', 117.0, 30)},
    {'cells': [('A', (604, 80, 667, 143)), ('B', (703, 110, 764, 172)), ('C', (824, 109, 886, 174)), ('D', (922, 80, 986, 143)), ('E', (719, 184, 780, 245)), ('F', (810, 183, 871, 245))], 'serie': ('C', 614.0, 31)},
    {'cells': [('A', (105, 380, 169, 444)), ('B', (206, 413, 267, 474)), ('C', (327, 413, 389, 474)), ('D', (424, 382, 489, 446)), ('E', (222, 486, 286, 548)), ('F', (312, 486, 376, 547))], 'serie': ('C', 117.0, 331)},
    {'cells': [('A', (604, 381, 667, 444)), ('B', (703, 412, 765, 474)), ('C', (824, 413, 888, 474)), ('D', (920, 382, 986, 445)), ('E', (716, 485, 781, 547)), ('F', (807, 486, 872, 547))], 'serie': ('C', 613.5, 331)},
    {'cells': [('A', (106, 687, 170, 748)), ('B', (206, 717, 267, 778)), ('C', (327, 717, 389, 778)), ('D', (425, 685, 488, 749)), ('E', (221, 790, 286, 851)), ('F', (312, 790, 375, 851))], 'serie': ('C', 117.0, 635)},
    {'cells': [('A', (604, 687, 668, 749)), ('B', (703, 717, 764, 778)), ('C', (824, 717, 888, 778)), ('D', (922, 687, 987, 749)), ('E', (719, 790, 781, 851)), ('F', (809, 790, 872, 851))], 'serie': ('C', 614.0, 635)},
    {'cells': [('A', (105, 989, 169, 1050)), ('B', (206, 1019, 267, 1080)), ('C', (326, 1018, 389, 1080)), ('D', (424, 989, 488, 1051)), ('E', (222, 1093, 285, 1154)), ('F', (313, 1090, 375, 1155))], 'serie': ('C', 117.0, 937)},
    {'cells': [('A', (600, 989, 668, 1053)), ('B', (702, 1021, 764, 1082)), ('C', (825, 1020, 886, 1081)), ('D', (921, 990, 986, 1052)), ('E', (717, 1093, 780, 1155)), ('F', (809, 1093, 873, 1155))], 'serie': ('C', 613.5, 938)},
    {'cells': [('A', (105, 1292, 170, 1353)), ('B', (204, 1323, 268, 1384)), ('C', (327, 1323, 388, 1384)), ('D', (423, 1291, 488, 1355)), ('E', (219, 1397, 283, 1458)), ('F', (311, 1396, 376, 1458))], 'serie': ('C', 117.0, 1240)},
    {'cells': [('A', (603, 1293, 668, 1356)), ('B', (702, 1323, 764, 1385)), ('C', (824, 1323, 886, 1385)), ('D', (922, 1292, 985, 1357)), ('E', (719, 1396, 780, 1459)), ('F', (809, 1396, 873, 1459))], 'serie': ('C', 613.5, 1242)},
]
AIR_H, AIR_W = 0.62, 0.78
COMPTE = Counter(p for p, _c in CARTONS[0]["cells"])


def _px(x):
    return x / _IMG_W * PAGE_W


def _py(y):
    return PAGE_H * (1 - y / _IMG_H)


def _t(c):
    x0, y0, x1, y1 = c
    w, h = _px(x1) - _px(x0), _px(y1) - _px(y0)
    return int(min(AIR_H * h / _CAP, AIR_W * w / (pdfmetrics.stringWidth("88", POLICE, 1.0) + 0.02)) * 2) / 2.0


TAILLE = min(_t(c) for ct in CARTONS for _p, c in ct["cells"])
TAILLE = 23.5   # ⭐ grossi au maximum, sans toucher le pointillé (Konica)


def _tirage(rng, p, n):
    a, b = PLAGES[p]
    pool = list(range(a, b + 1, 2)) if (a % 2 == 0 and "PAIR" in "ROYAL 6 boules") else list(range(a, b + 1))
    return sorted(rng.sample(pool, n))


def _numeros(rng, deja=None):
    while True:
        d = {p: _tirage(rng, p, n) for p, n in COMPTE.items()}
        cle = tuple((p, tuple(d[p])) for p in sorted(d))
        if deja is None or cle not in deja:
            if deja is not None:
                deja.add(cle)
            return d


def generer_pdf(nb_cartes=None, nb_tickets=None, serie_start=1, theme="", couleur=True,
                nom_evenement="", titre_jeu="", couleur_perso="", date_lieu="",
                telephone="", page_start=1, evenement_id="", style="", motif="",
                _deja=None, **_ig):
    n_ = nb_cartes if nb_cartes is not None else nb_tickets
    n_ = max(1, int(n_ if n_ else CARTES_PAGE))
    buf = io.BytesIO()
    c = canvas.Canvas(buf, pagesize=(PAGE_W, PAGE_H), pageCompression=1)
    c.setTitle("ROYAL 6 boules")
    rng = random.Random(int(serie_start) * 100003 + 9006)
    deja = _deja if _deja is not None else set()
    serie = int(serie_start)
    faits = 0
    try:
        no_page = max(1, int(page_start))
    except Exception:
        no_page = 1
    col_imposee = None
    if couleur and couleur_perso:
        try:
            col_imposee = colors.HexColor(couleur_perso)
        except Exception:
            col_imposee = None
    while faits < n_:
        c.saveState()
        c.translate(DECAL_X, DECAL_Y)
        c.scale(ECHELLE, ECHELLE)
        try:
            c.drawImage(_IMG_FOND, 0, 0, PAGE_W, PAGE_H, preserveAspectRatio=False, mask="auto")
        except Exception:
            pass
        for idx in range(CARTES_PAGE):
            if faits >= n_:
                break
            ct = CARTONS[idx]
            col = (col_imposee or colors.HexColor(RAINBOW[serie % len(RAINBOW)])) if couleur else NOIR
            nums = _numeros(rng, deja)
            pos = {p: 0 for p in nums}
            c.saveState()
            c.setFillColor(col); c.setStrokeColor(col)
            c.setLineWidth(0.5); c.setLineJoin(1)
            for p, (x0, y0, x1, y1) in ct["cells"]:
                v = str(nums[p][pos[p]]); pos[p] += 1
                o = c.beginText(); o.setTextRenderMode(2); o.setFont(POLICE, TAILLE)
                o.setTextOrigin(_px((x0 + x1) / 2.0) - c.stringWidth(v, POLICE, TAILLE) / 2.0,
                                _py((y0 + y1) / 2.0) - TAILLE * _CAP / 2.0)
                o.textOut(v); c.drawText(o)
            c.restoreState()
            al, sx, sy = ct["serie"]
            c.setFillColor(GRIS_TRAIT)
            c.setFont("Helvetica-Bold", 8)
            txt = "%05d" % serie
            if al == "R":
                c.drawRightString(_px(sx), _py(sy), txt)
            elif al == "C":
                c.drawCentredString(_px(sx), _py(sy), txt)
            else:
                c.drawString(_px(sx), _py(sy), txt)
            serie += 1
            faits += 1
        c.restoreState()
        c.setFillColor(GRIS_TRAIT)
        c.setFont("Helvetica", 6)
        c.drawRightString(PAGE_W - 17, PAGE_H - 13, "%d" % no_page)
        no_page += 1
        c.showPage()
    c.save()
    buf.seek(0)
    return buf
