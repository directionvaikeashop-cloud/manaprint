# -*- coding: utf-8 -*-
"""MANAPRINT — POW 9 BOULES (planche de Maeva, 16 cartons / A4 PAYSAGE).
La planche est reprise TELLE QUELLE comme fond (traits passés en gris) ;
on n'ajoute que les chiffres et le n° de série.
9 numéros par carton, grille 3 x 3, le plus petit en haut de chaque colonne :
   colonne 1 : 1-9 · colonne 2 : 10-18 · colonne 3 : 19-27 -> crieur 1 à 27.
Version refaite le 18/11/2026 (chiffres Latin Modern, l'écriture d'origine)."""
import io, os as _os, random
from reportlab.pdfgen import canvas
from reportlab.lib.pagesizes import A4, landscape
from reportlab.lib import colors
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont

PAGE_W, PAGE_H = landscape(A4)
CARTES_PAGE = 16
# niveau B choisi par Maeva le 28/09 pour POW 9 : chiffres gris 0,40
_GRIS_ECO = colors.Color(0.40, 0.40, 0.40)
GRIS_TRAIT = colors.Color(105 / 255.0, 105 / 255.0, 105 / 255.0)
RAINBOW = ["#E53935", "#FB8C00", "#F9A825", "#43A047", "#00ACC1",
           "#1E88E5", "#3949AB", "#8E24AA", "#D81B60", "#6D4C41"]
COLONNES = [(1, 9), (10, 18), (19, 27)]

_ICI = _os.path.dirname(_os.path.abspath(__file__))
# ⭐ 18/11 (Maeva : « je veux l'original ») : l'écriture d'origine des jeux
#    ÉCO de la maison (POW, RAI, KEA…) = LATIN MODERN ROMAN, gris 0,40,
#    gras léger 0,012. Helvetica-Bold en secours si le fichier manque.
# ⭐ 18/11 (Maeva : « à l'impression sur les Konica 458C ça déborde un peu
#    les grilles ») : chiffres à ~65 % de la hauteur de case (de l'air tout
#    autour, même quand le toner s'étale) + planche ramenée dans une marge
#    de 6 mm (la Konica ne peut pas imprimer les 4,2 mm du bord).
# ⭐ 18/11 après-midi (Maeva : « bien gros, gras, les chiffres du POW 9 ») :
#    HELVETICA-BOLD épaissi (trait 0,5 pt), le plus gros que la case permet.
POLICE, _CAP, TAILLE = "Helvetica-Bold", 0.717, 33.0
_GRAS_TRAIT = 0.5 / 33.0
MARGE_SURE = 6 * 72 / 25.4      # 6 mm
ECHELLE = min((PAGE_W - 2 * MARGE_SURE) / PAGE_W, (PAGE_H - 2 * MARGE_SURE) / PAGE_H)
DECAL_X = (PAGE_W - PAGE_W * ECHELLE) / 2.0
DECAL_Y = (PAGE_H - PAGE_H * ECHELLE) / 2.0

_IMG_W, _IMG_H = 1536.0, 1024.0
_IMG_FOND = _os.path.join(_ICI, "pow9_fond.png")

# centres (x, y) px des 9 cases (3 rangées de 3) ; serie = (x centre, ligne de base)
CARTONS = [
    {'grille': [[(102.0, 88.5), (213.0, 88.5), (324.5, 88.5)], [(102.0, 148.0), (213.5, 148.0), (324.5, 148.0)], [(102.0, 207.5), (213.0, 207.5), (324.5, 207.5)]], 'serie': (87, 50)},
    {'grille': [[(472.5, 88.5), (583.0, 88.5), (694.0, 88.5)], [(472.5, 148.0), (583.0, 148.0), (694.0, 148.0)], [(472.5, 207.5), (583.0, 207.5), (693.5, 207.5)]], 'serie': (458, 50)},
    {'grille': [[(841.0, 88.5), (952.0, 88.5), (1063.0, 88.5)], [(841.0, 148.0), (952.0, 148.0), (1063.0, 148.0)], [(841.0, 207.5), (952.0, 207.5), (1063.0, 207.5)]], 'serie': (826, 50)},
    {'grille': [[(1211.5, 88.5), (1323.0, 88.5), (1434.0, 88.5)], [(1211.5, 148.0), (1323.0, 148.0), (1434.0, 148.0)], [(1211.5, 207.5), (1323.0, 207.5), (1434.0, 207.5)]], 'serie': (1196, 50)},
    {'grille': [[(102.0, 341.5), (213.0, 341.5), (324.5, 341.5)], [(102.0, 401.0), (213.0, 400.5), (324.5, 401.0)], [(102.0, 460.5), (213.0, 460.5), (324.5, 460.5)]], 'serie': (87, 303)},
    {'grille': [[(472.5, 341.5), (583.0, 341.5), (694.0, 341.5)], [(472.5, 401.0), (583.0, 401.0), (694.0, 401.0)], [(472.5, 460.5), (583.0, 460.5), (694.0, 460.5)]], 'serie': (458, 303)},
    {'grille': [[(841.0, 341.5), (952.0, 341.5), (1063.0, 341.5)], [(841.0, 401.0), (952.0, 400.5), (1063.0, 401.0)], [(841.0, 460.5), (952.0, 460.5), (1063.0, 460.5)]], 'serie': (826, 303)},
    {'grille': [[(1211.5, 341.5), (1323.0, 341.5), (1434.0, 341.5)], [(1211.5, 400.5), (1323.0, 400.5), (1434.0, 400.5)], [(1211.5, 460.5), (1323.0, 460.5), (1434.0, 460.5)]], 'serie': (1196, 303)},
    {'grille': [[(102.0, 594.5), (213.5, 594.5), (324.5, 594.5)], [(102.0, 653.5), (213.5, 653.5), (324.5, 653.5)], [(102.0, 713.5), (213.0, 713.5), (324.5, 713.5)]], 'serie': (87, 557)},
    {'grille': [[(472.5, 594.5), (583.0, 594.5), (694.0, 594.5)], [(472.5, 653.5), (583.0, 653.5), (694.0, 653.5)], [(472.5, 713.5), (583.0, 713.5), (693.5, 713.5)]], 'serie': (458, 557)},
    {'grille': [[(841.0, 594.5), (952.0, 594.5), (1063.0, 594.5)], [(841.0, 653.5), (952.0, 653.5), (1063.0, 653.5)], [(841.0, 713.5), (952.0, 713.5), (1063.0, 713.5)]], 'serie': (826, 557)},
    {'grille': [[(1211.5, 594.5), (1323.0, 594.5), (1434.0, 594.5)], [(1211.5, 653.5), (1323.0, 653.5), (1434.0, 653.5)], [(1211.5, 713.5), (1323.0, 713.5), (1434.0, 713.5)]], 'serie': (1196, 557)},
    {'grille': [[(102.0, 847.0), (213.0, 847.0), (324.5, 847.0)], [(102.0, 906.0), (213.0, 906.0), (324.5, 906.0)], [(102.0, 965.5), (213.0, 965.5), (324.5, 965.5)]], 'serie': (87, 809)},
    {'grille': [[(472.5, 847.5), (583.0, 847.5), (694.0, 847.5)], [(472.5, 906.5), (583.0, 906.5), (693.5, 906.5)], [(472.5, 965.5), (583.0, 965.5), (694.0, 965.5)]], 'serie': (458, 809)},
    {'grille': [[(841.0, 847.0), (952.0, 847.0), (1063.0, 847.0)], [(841.0, 906.0), (952.0, 906.0), (1063.0, 906.0)], [(841.0, 965.5), (952.0, 965.5), (1063.0, 965.5)]], 'serie': (826, 809)},
    {'grille': [[(1211.5, 846.5), (1323.0, 846.5), (1434.0, 846.5)], [(1211.5, 905.5), (1323.0, 905.5), (1434.0, 905.5)], [(1211.5, 965.5), (1323.0, 965.5), (1434.0, 965.5)]], 'serie': (1196, 809)},
]

_EPAIS = 0.6


def _chiffre(c, x, y, txt, taille):
    txt = str(txt)
    w = c.stringWidth(txt, POLICE, taille)
    c.saveState()
    try:
        t = c.beginText()
        if _GRAS_TRAIT > 0:
            c.setStrokeColor(c._fillColorObj)
            c.setLineWidth(_GRAS_TRAIT * taille)
            c.setLineJoin(1)
            t.setTextRenderMode(2)
        else:
            t.setTextRenderMode(0)
        t.setFont(POLICE, taille)
        t.setTextOrigin(x - w / 2.0, y)
        t.textOut(txt)
        c.drawText(t)
    finally:
        c.restoreState()


def _px(x):
    return x / _IMG_W * PAGE_W


def _py(y):
    return PAGE_H * (1 - y / _IMG_H)


def _numeros(rng, deja=None):
    # 3 numéros par colonne, triés : le plus petit en haut
    while True:
        cols = [sorted(rng.sample(range(a, b + 1), 3)) for a, b in COLONNES]
        cle = tuple(v for col in cols for v in col)
        if deja is None or cle not in deja:
            if deja is not None:
                deja.add(cle)
            return cols


def generer_pdf(nb_cartes=None, nb_tickets=None, serie_start=1, theme="", couleur=True,
                nom_evenement="", titre_jeu="", couleur_perso="", date_lieu="",
                telephone="", page_start=1, evenement_id="", style="", motif="",
                _deja=None, **_ig):
    n_ = nb_cartes if nb_cartes is not None else nb_tickets
    n_ = max(1, int(n_ if n_ else CARTES_PAGE))
    buf = io.BytesIO()
    c = canvas.Canvas(buf, pagesize=(PAGE_W, PAGE_H), pageCompression=1)
    c.setTitle("POW 9 boules")
    rng = random.Random(int(serie_start) * 100003 + 9999)
    deja = _deja if _deja is not None else set()
    serie = int(serie_start)
    faits = 0
    col_imposee = None
    if couleur and couleur_perso:
        try:
            col_imposee = colors.HexColor(couleur_perso)
        except Exception:
            col_imposee = None

    while faits < n_:
        c.saveState()
        c.translate(DECAL_X, DECAL_Y)
        c.scale(ECHELLE, ECHELLE)
        try:
            c.drawImage(_IMG_FOND, 0, 0, PAGE_W, PAGE_H, preserveAspectRatio=False, mask="auto")
        except Exception:
            pass
        entete = "  ·  ".join(t for t in ((nom_evenement or "").strip(),
                                          (date_lieu or "").strip(),
                                          (telephone or "").strip()) if t)
        if entete:
            c.setFillColor(_GRIS_ECO)
            c.setFont("Helvetica-Bold", 6)
            c.drawString(_px(40), PAGE_H - 7, entete)
        for idx in range(CARTES_PAGE):
            if faits >= n_:
                break
            ct = CARTONS[idx]
            col = (col_imposee or colors.HexColor(RAINBOW[serie % len(RAINBOW)])) if couleur else _GRIS_ECO
            cols = _numeros(rng, deja)
            c.setFillColor(col)
            dy = TAILLE * _CAP / 2.0
            for j in range(3):          # colonne
                for i in range(3):      # rangée
                    x, y = ct["grille"][i][j]
                    _chiffre(c, _px(x), _py(y) - dy, cols[j][i], TAILLE)
            sx, sy = ct["serie"]
            c.setFillColor(GRIS_TRAIT)
            c.setFont("Helvetica-Bold", 5.5)
            c.drawCentredString(_px(sx), _py(sy), "N° %06d" % serie)
            serie += 1
            faits += 1
        c.restoreState()
        c.showPage()
    c.save()
    buf.seek(0)
    return buf


if __name__ == "__main__":
    open("test_pow9.pdf", "wb").write(generer_pdf(nb_cartes=16, couleur=False).read())
    print("POW 9 genere")
