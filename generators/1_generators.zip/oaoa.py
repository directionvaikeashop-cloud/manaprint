# -*- coding: utf-8 -*-
"""MANAPRINT — OAOA (planche de Maeva, refait le 19/11/2026).
16 cartons par feuille A4 PORTRAIT. La planche est reprise TELLE QUELLE comme
fond (trait gris uni, sans aplat gris taché) ; on n'ajoute que les chiffres, le n° de
série et le n° de page.
Règle : O 1-30 · A 31-75, trois numéros par colonne, triés. Crieur 1-75.
Chiffres Latin Modern GRAS, noirs, le plus gros que chaque case permet.
Feuille ramenée à 6 mm des bords (Konica)."""
import io, os as _os, random
from collections import Counter
from reportlab.pdfgen import canvas
from reportlab.lib.pagesizes import A4, landscape
from reportlab.lib import colors
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont

PAGE_W, PAGE_H = A4
CARTES_PAGE = 16
PLAGES = {'O': (1, 30), 'A': (31, 75)}
NOIR = colors.Color(0.05, 0.05, 0.05)
GRIS_TRAIT = colors.Color(0.40, 0.40, 0.40)
RAINBOW = ["#E53935", "#FB8C00", "#F9A825", "#43A047", "#00ACC1",
           "#1E88E5", "#3949AB", "#8E24AA", "#D81B60", "#6D4C41"]
_ICI = _os.path.dirname(_os.path.abspath(__file__))
POLICE, _CAP = "Helvetica-Bold", 0.717
try:
    pdfmetrics.registerFont(TTFont("LMROMANB", _os.path.join(_ICI, "LatinModern-Bold.ttf")))
    POLICE, _CAP = "LMROMANB", 0.66
except Exception:
    pass
_IMG_W, _IMG_H = 1086.0, 1536.0
_IMG_FOND = _os.path.join(_ICI, "oaoa_fond.png")
MARGE_SURE = 6 * 72 / 25.4
ECHELLE = min((PAGE_W - 2 * MARGE_SURE) / PAGE_W, (PAGE_H - 2 * MARGE_SURE) / PAGE_H)
DECAL_X = (PAGE_W - PAGE_W * ECHELLE) / 2.0
DECAL_Y = (PAGE_H - PAGE_H * ECHELLE) / 2.0

# cases : (plage, (x0, y0, x1, y1) px), dans l'ordre où les numéros TRIÉS se posent ;
# serie = (alignement, x, ligne de base) px
CARTONS = [
    {'cells': [('O', (60, 151, 170, 224)), ('O', (60, 226, 170, 300)), ('O', (60, 302, 170, 376)), ('A', (173, 151, 282, 224)), ('A', (173, 226, 282, 300)), ('A', (173, 302, 282, 376))], 'serie': ('L', 82, 89)},
    {'cells': [('O', (309, 151, 419, 224)), ('O', (309, 226, 419, 300)), ('O', (309, 302, 419, 376)), ('A', (422, 151, 530, 224)), ('A', (422, 226, 530, 300)), ('A', (422, 302, 530, 376))], 'serie': ('L', 331, 89)},
    {'cells': [('O', (558, 151, 668, 224)), ('O', (558, 226, 668, 300)), ('O', (558, 302, 668, 376)), ('A', (671, 151, 779, 224)), ('A', (671, 226, 779, 300)), ('A', (671, 302, 779, 376))], 'serie': ('L', 580, 89)},
    {'cells': [('O', (808, 151, 917, 224)), ('O', (808, 226, 917, 300)), ('O', (808, 302, 917, 376)), ('A', (920, 151, 1028, 224)), ('A', (920, 226, 1028, 300)), ('A', (920, 302, 1028, 376))], 'serie': ('L', 830, 89)},
    {'cells': [('O', (60, 521, 170, 594)), ('O', (60, 596, 170, 669)), ('O', (60, 671, 170, 744)), ('A', (173, 521, 282, 594)), ('A', (173, 596, 282, 669)), ('A', (173, 671, 282, 744))], 'serie': ('L', 82, 459)},
    {'cells': [('O', (309, 521, 419, 594)), ('O', (309, 596, 419, 669)), ('O', (309, 671, 419, 744)), ('A', (422, 521, 530, 594)), ('A', (422, 596, 530, 669)), ('A', (422, 671, 530, 744))], 'serie': ('L', 331, 459)},
    {'cells': [('O', (558, 521, 668, 594)), ('O', (558, 596, 668, 669)), ('O', (558, 672, 668, 744)), ('A', (670, 521, 779, 594)), ('A', (670, 596, 779, 669)), ('A', (670, 672, 779, 744))], 'serie': ('L', 580, 459)},
    {'cells': [('O', (808, 521, 917, 594)), ('O', (808, 596, 917, 670)), ('O', (808, 672, 917, 744)), ('A', (920, 521, 1028, 594)), ('A', (920, 596, 1028, 669)), ('A', (920, 672, 1028, 744))], 'serie': ('L', 830, 459)},
    {'cells': [('O', (60, 890, 170, 962)), ('O', (60, 964, 170, 1035)), ('O', (60, 1037, 170, 1110)), ('A', (173, 890, 282, 962)), ('A', (173, 964, 282, 1035)), ('A', (173, 1037, 282, 1110))], 'serie': ('L', 82, 828)},
    {'cells': [('O', (309, 890, 419, 962)), ('O', (309, 964, 419, 1035)), ('O', (309, 1037, 419, 1110)), ('A', (422, 890, 530, 962)), ('A', (422, 964, 530, 1035)), ('A', (422, 1037, 530, 1110))], 'serie': ('L', 331, 828)},
    {'cells': [('O', (558, 890, 668, 962)), ('O', (558, 964, 668, 1035)), ('O', (558, 1037, 668, 1110)), ('A', (670, 890, 779, 962)), ('A', (670, 964, 779, 1035)), ('A', (670, 1037, 779, 1110))], 'serie': ('L', 580, 828)},
    {'cells': [('O', (808, 890, 917, 962)), ('O', (808, 964, 917, 1035)), ('O', (808, 1037, 917, 1110)), ('A', (919, 890, 1028, 962)), ('A', (919, 964, 1028, 1035)), ('A', (919, 1037, 1028, 1110))], 'serie': ('L', 830, 828)},
    {'cells': [('O', (60, 1251, 170, 1322)), ('O', (60, 1324, 170, 1396)), ('O', (60, 1399, 170, 1471)), ('A', (173, 1251, 282, 1322)), ('A', (173, 1324, 282, 1396)), ('A', (173, 1399, 282, 1471))], 'serie': ('L', 82, 1189)},
    {'cells': [('O', (309, 1251, 419, 1322)), ('O', (309, 1324, 419, 1397)), ('O', (309, 1399, 419, 1471)), ('A', (422, 1251, 530, 1322)), ('A', (422, 1324, 530, 1396)), ('A', (422, 1399, 530, 1471))], 'serie': ('L', 331, 1189)},
    {'cells': [('O', (558, 1251, 667, 1322)), ('O', (558, 1324, 667, 1397)), ('O', (558, 1399, 667, 1471)), ('A', (670, 1251, 779, 1322)), ('A', (669, 1324, 779, 1397)), ('A', (670, 1399, 779, 1471))], 'serie': ('L', 580, 1189)},
    {'cells': [('O', (808, 1251, 916, 1322)), ('O', (808, 1324, 916, 1397)), ('O', (808, 1399, 916, 1471)), ('A', (919, 1251, 1028, 1322)), ('A', (919, 1324, 1028, 1396)), ('A', (919, 1399, 1028, 1471))], 'serie': ('L', 830, 1189)},
]
AIR_H, AIR_W = 0.62, 0.78
COMPTE = Counter(p for p, _c in CARTONS[0]["cells"])


def _px(x):
    return x / _IMG_W * PAGE_W


def _py(y):
    return PAGE_H * (1 - y / _IMG_H)


def _t(c):
    x0, y0, x1, y1 = c
    w, h = _px(x1) - _px(x0), _px(y1) - _px(y0)
    return int(min(AIR_H * h / _CAP, AIR_W * w / (pdfmetrics.stringWidth("88", POLICE, 1.0) + 0.02)) * 2) / 2.0


TAILLE = min(_t(c) for ct in CARTONS for _p, c in ct["cells"])


def _tirage(rng, p, n):
    a, b = PLAGES[p]
    pool = list(range(a, b + 1, 2)) if (a % 2 == 0 and "PAIR" in "OAOA") else list(range(a, b + 1))
    return sorted(rng.sample(pool, n))


def _numeros(rng, deja=None):
    while True:
        d = {p: _tirage(rng, p, n) for p, n in COMPTE.items()}
        cle = tuple((p, tuple(d[p])) for p in sorted(d))
        if deja is None or cle not in deja:
            if deja is not None:
                deja.add(cle)
            return d


def generer_pdf(nb_cartes=None, nb_tickets=None, serie_start=1, theme="", couleur=True,
                nom_evenement="", titre_jeu="", couleur_perso="", date_lieu="",
                telephone="", page_start=1, evenement_id="", style="", motif="",
                _deja=None, **_ig):
    n_ = nb_cartes if nb_cartes is not None else nb_tickets
    n_ = max(1, int(n_ if n_ else CARTES_PAGE))
    buf = io.BytesIO()
    c = canvas.Canvas(buf, pagesize=(PAGE_W, PAGE_H), pageCompression=1)
    c.setTitle("OAOA")
    rng = random.Random(int(serie_start) * 100003 + 3175)
    deja = _deja if _deja is not None else set()
    serie = int(serie_start)
    faits = 0
    try:
        no_page = max(1, int(page_start))
    except Exception:
        no_page = 1
    col_imposee = None
    if couleur and couleur_perso:
        try:
            col_imposee = colors.HexColor(couleur_perso)
        except Exception:
            col_imposee = None
    while faits < n_:
        c.saveState()
        c.translate(DECAL_X, DECAL_Y)
        c.scale(ECHELLE, ECHELLE)
        try:
            c.drawImage(_IMG_FOND, 0, 0, PAGE_W, PAGE_H, preserveAspectRatio=False, mask="auto")
        except Exception:
            pass
        for idx in range(CARTES_PAGE):
            if faits >= n_:
                break
            ct = CARTONS[idx]
            col = (col_imposee or colors.HexColor(RAINBOW[serie % len(RAINBOW)])) if couleur else NOIR
            nums = _numeros(rng, deja)
            pos = {p: 0 for p in nums}
            c.saveState()
            c.setFillColor(col); c.setStrokeColor(col)
            c.setLineWidth(0.5); c.setLineJoin(1)
            for p, (x0, y0, x1, y1) in ct["cells"]:
                v = str(nums[p][pos[p]]); pos[p] += 1
                o = c.beginText(); o.setTextRenderMode(2); o.setFont(POLICE, TAILLE)
                o.setTextOrigin(_px((x0 + x1) / 2.0) - c.stringWidth(v, POLICE, TAILLE) / 2.0,
                                _py((y0 + y1) / 2.0) - TAILLE * _CAP / 2.0)
                o.textOut(v); c.drawText(o)
            c.restoreState()
            al, sx, sy = ct["serie"]
            c.setFillColor(GRIS_TRAIT)
            c.setFont("Helvetica-Bold", 7)
            txt = "%06d" % serie
            if al == "R":
                c.drawRightString(_px(sx), _py(sy), txt)
            elif al == "C":
                c.drawCentredString(_px(sx), _py(sy), txt)
            else:
                c.drawString(_px(sx), _py(sy), txt)
            serie += 1
            faits += 1
        c.restoreState()
        c.setFillColor(GRIS_TRAIT)
        c.setFont("Helvetica", 6)
        c.drawRightString(PAGE_W - 17, PAGE_H - 13, "%d" % no_page)
        no_page += 1
        c.showPage()
    c.save()
    buf.seek(0)
    return buf
