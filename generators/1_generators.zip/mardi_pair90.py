# -*- coding: utf-8 -*-
"""MANAPRINT — MARDI PAIR 90 (création 2KEA du 18/09, maquette de Maeva).
Refait le 19/11/2026. 12 cartons / feuille A4 PORTRAIT (4 x 3). La maquette est
grille RETRACÉE en vectoriel le 19/11 (voir _grille), trait gris uni.
Règle : 10 numéros PAIRS différents de 2 à 90, 5 par colonne, chaque colonne
triée du plus petit en haut (comme le modèle « PAIRS jusqu'à 90 »).
Crieur : les 45 boules paires de 2 à 90.
Chiffres Latin Modern (écriture maison), noirs, le plus gros que le rond permet."""
import io, os as _os, random
from reportlab.pdfgen import canvas
from reportlab.lib.pagesizes import A4
from reportlab.lib import colors
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont

PAGE_W, PAGE_H = A4
CARTES_PAGE = 12
PAIRS = list(range(2, 91, 2))
NOIR = colors.Color(0.05, 0.05, 0.05)
GRIS_TRAIT = colors.Color(0.40, 0.40, 0.40)
RAINBOW = ["#E53935", "#FB8C00", "#F9A825", "#43A047", "#00ACC1",
           "#1E88E5", "#3949AB", "#8E24AA", "#D81B60", "#6D4C41"]
_ICI = _os.path.dirname(_os.path.abspath(__file__))
POLICE, _CAP, _L88 = "Helvetica-Bold", 0.717, 1.112
try:
    pdfmetrics.registerFont(TTFont("LMROMAN", _os.path.join(_ICI, "LatinModern.ttf")))
    POLICE, _CAP, _L88 = "LMROMAN", 0.644, 1.0
except Exception:
    pass
_IMG_W, _IMG_H = 1086.0, 1536.0
_IMG_FOND = _os.path.join(_ICI, "mardi_pair90_fond.png")
MARGE_SURE = 6 * 72 / 25.4
ECHELLE = min((PAGE_W - 2 * MARGE_SURE) / PAGE_W, (PAGE_H - 2 * MARGE_SURE) / PAGE_H)
DECAL_X = (PAGE_W - PAGE_W * ECHELLE) / 2.0
DECAL_Y = (PAGE_H - PAGE_H * ECHELLE) / 2.0

# ronds (cx, cy, rayon intérieur) px, colonne gauche puis droite ; serie = (x, ligne de base)
CARTONS = [
    {'cols': [[(99.5, 149.1, 28.7), (99.5, 213.1, 28.5), (99.5, 278.0, 28.9), (99.6, 344.7, 28.7), (99.7, 411.2, 29.0)], [(217.3, 149.2, 28.7), (217.3, 213.2, 28.5), (217.4, 278.0, 28.9), (217.5, 344.7, 28.9), (217.5, 411.1, 29.0)]], 'serie': (99.5, 453.0)},
    {'cols': [[(356.3, 149.2, 28.7), (356.4, 213.3, 28.3), (356.4, 278.0, 28.9), (356.5, 344.7, 28.7), (356.5, 411.2, 28.7)], [(473.6, 149.3, 28.7), (473.6, 213.3, 28.3), (473.7, 278.0, 28.9), (473.7, 344.8, 28.7), (473.8, 411.1, 29.2)]], 'serie': (356.3, 453.0)},
    {'cols': [[(612.3, 149.3, 28.7), (612.4, 213.3, 28.5), (612.4, 278.1, 29.0), (612.4, 344.8, 28.9), (612.5, 411.2, 29.0)], [(729.9, 149.3, 28.7), (729.9, 213.3, 28.5), (729.8, 278.0, 29.0), (729.9, 344.8, 28.9), (730.0, 411.1, 29.2)]], 'serie': (612.3, 453.0)},
    {'cols': [[(868.2, 149.2, 28.7), (868.2, 213.3, 28.5), (868.2, 278.1, 29.0), (868.2, 344.8, 29.0), (868.2, 411.2, 29.0)], [(985.3, 149.2, 28.7), (985.5, 213.3, 28.5), (985.5, 278.0, 28.9), (985.4, 344.8, 28.9), (985.5, 411.2, 29.0)]], 'serie': (868.2, 453.0)},
    {'cols': [[(99.5, 659.9, 28.7), (99.4, 723.9, 28.7), (99.2, 788.7, 28.5), (99.3, 853.9, 28.9), (99.4, 920.8, 28.7)], [(217.5, 660.0, 28.9), (217.5, 724.0, 28.7), (217.4, 788.9, 28.9), (217.4, 853.9, 28.9), (217.4, 920.8, 28.9)]], 'serie': (99.5, 453.0)},
    {'cols': [[(356.7, 660.0, 28.9), (356.7, 724.0, 28.7), (356.7, 789.0, 28.7), (356.8, 854.0, 28.9), (356.9, 920.9, 28.9)], [(474.3, 660.0, 28.7), (474.2, 724.1, 28.7), (474.2, 789.0, 28.9), (474.1, 854.0, 29.0), (474.3, 920.9, 28.9)]], 'serie': (356.7, 453.0)},
    {'cols': [[(611.8, 660.0, 28.9), (611.8, 724.1, 28.9), (611.8, 789.0, 28.9), (611.9, 854.0, 29.0), (612.0, 921.0, 29.0)], [(729.9, 660.1, 28.9), (729.9, 724.0, 28.9), (729.8, 789.0, 28.9), (729.8, 854.0, 29.0), (730.0, 921.0, 29.0)]], 'serie': (611.8, 453.0)},
    {'cols': [[(868.2, 660.0, 28.9), (868.1, 724.1, 28.9), (868.1, 789.0, 28.9), (868.1, 854.0, 28.9), (868.1, 921.0, 29.0)], [(985.5, 660.1, 28.7), (985.5, 724.1, 28.7), (985.5, 789.0, 28.9), (985.5, 854.0, 28.9), (985.6, 920.9, 28.9)]], 'serie': (868.2, 453.0)},
    {'cols': [[(99.3, 1164.6, 28.2), (99.2, 1229.1, 29.0), (99.1, 1294.1, 28.9), (99.1, 1359.9, 28.7), (99.1, 1427.3, 29.1)], [(217.2, 1164.6, 28.2), (217.1, 1229.0, 29.0), (217.1, 1294.1, 28.9), (217.1, 1359.9, 28.9), (217.1, 1427.3, 29.0)]], 'serie': (99.3, 453.0)},
    {'cols': [[(355.6, 1164.6, 28.2), (355.6, 1229.1, 29.0), (355.4, 1294.3, 28.7), (355.5, 1360.0, 28.7), (355.6, 1427.4, 28.9)], [(473.1, 1164.7, 28.3), (473.1, 1229.2, 29.0), (473.0, 1294.3, 28.9), (473.0, 1360.0, 28.9), (473.0, 1427.4, 29.0)]], 'serie': (355.6, 453.0)},
    {'cols': [[(611.4, 1164.7, 28.3), (611.5, 1229.3, 28.9), (611.5, 1294.4, 28.7), (611.5, 1360.1, 28.7), (611.5, 1427.5, 28.9)], [(729.4, 1164.8, 28.3), (729.4, 1229.3, 28.9), (729.4, 1294.4, 28.5), (729.4, 1360.1, 28.9), (729.5, 1427.5, 28.9)]], 'serie': (611.4, 453.0)},
    {'cols': [[(868.1, 1164.7, 28.3), (868.0, 1229.2, 29.0), (868.0, 1294.4, 28.7), (867.9, 1360.0, 28.9), (868.0, 1427.4, 29.0)], [(985.4, 1164.8, 28.2), (985.4, 1229.2, 28.9), (985.3, 1294.3, 28.7), (985.4, 1360.0, 28.9), (985.3, 1427.5, 28.9)]], 'serie': (868.1, 453.0)},
]


def _px(x):
    return x / _IMG_W * PAGE_W


def _py(y):
    return PAGE_H * (1 - y / _IMG_H)


def _taille_max():
    r = _px(min(rd[2] for ct in CARTONS for col in ct["cols"] for rd in col) - 3) - _px(0)
    t = 8.0
    while True:
        t2 = t + 0.5
        if (_L88 * t2 / 2.0) ** 2 + (_CAP * t2 / 2.0) ** 2 > r ** 2:
            return t
        t = t2


TAILLE = _taille_max()


# ⭐ 19/11 (Maeva : « retrace-moi correctement la grille ») : le cadre, la grille,
#    le pied, le trait du milieu et les 10 ronds sont RETRACÉS en vectoriel,
#    nets et réguliers, aux places mesurées sur la maquette ; seuls le dessin
#    de l'en-tête (soleil, MARDI PAIR 90) et « 2Kea&Associé » viennent de l'image.
_DX = 31                                   # décalage du fond (remise au format A4)
_GT, _GB, _FB, _OT = [110, 618, 1124], [456, 963, 1472], [494, 1000, 1509], [3, 512, 1019]
_TRAIT = colors.Color(0.40, 0.40, 0.40)


def _grille(c, idx):
    r, k = divmod(idx, 4)
    ox0, ox1 = 3 + k * 256 + _DX, 254 + k * 256 + _DX
    gx0, gx1 = 8 + k * 256 + _DX, 248 + k * 256 + _DX
    c.saveState()
    c.setStrokeColor(_TRAIT)
    c.setLineJoin(1)
    # cadre extérieur du carton
    c.setLineWidth(0.9)
    c.roundRect(_px(ox0), _py(_FB[r] + 5), _px(ox1) - _px(ox0), _py(_OT[r]) - _py(_FB[r] + 5), 2.5)
    # boîte de jeu + pied
    c.setLineWidth(1.3)
    c.rect(_px(gx0), _py(_FB[r]), _px(gx1) - _px(gx0), _py(_GT[r]) - _py(_FB[r]))
    c.line(_px(gx0), _py(_GB[r]), _px(gx1), _py(_GB[r]))
    # trait du milieu
    c.setLineWidth(0.9)
    xm = (gx0 + gx1) / 2.0
    c.line(_px(xm), _py(_GT[r] + 14), _px(xm), _py(_GB[r] - 14))
    # les 10 ronds
    c.setLineWidth(1.3)
    for col in CARTONS[idx]["cols"]:
        for (x, y, rr) in col:
            c.circle(_px(x), _py(y), _px(rr + 1.2) - _px(0), stroke=1, fill=0)
    c.restoreState()


def _numeros(rng, deja=None):
    while True:
        tir = rng.sample(PAIRS, 10)
        d = [sorted(tir[:5]), sorted(tir[5:])]
        cle = tuple(sorted(tir))
        if deja is None or cle not in deja:
            if deja is not None:
                deja.add(cle)
            return d


def generer_pdf(nb_cartes=None, nb_tickets=None, serie_start=1, theme="", couleur=True,
                nom_evenement="", titre_jeu="", couleur_perso="", date_lieu="",
                telephone="", page_start=1, evenement_id="", style="", motif="",
                _deja=None, **_ig):
    n_ = nb_cartes if nb_cartes is not None else nb_tickets
    n_ = max(1, int(n_ if n_ else CARTES_PAGE))
    buf = io.BytesIO()
    c = canvas.Canvas(buf, pagesize=(PAGE_W, PAGE_H), pageCompression=1)
    c.setTitle("MARDI PAIR 90")
    rng = random.Random(int(serie_start) * 100003 + 9002)
    deja = _deja if _deja is not None else set()
    serie = int(serie_start)
    faits = 0
    try:
        no_page = max(1, int(page_start))
    except Exception:
        no_page = 1
    col_imposee = None
    if couleur and couleur_perso:
        try:
            col_imposee = colors.HexColor(couleur_perso)
        except Exception:
            col_imposee = None
    while faits < n_:
        c.saveState()
        c.translate(DECAL_X, DECAL_Y)
        c.scale(ECHELLE, ECHELLE)
        try:
            c.drawImage(_IMG_FOND, 0, 0, PAGE_W, PAGE_H, preserveAspectRatio=False, mask="auto")
        except Exception:
            pass
        for idx in range(CARTES_PAGE):
            if faits >= n_:
                break
            ct = CARTONS[idx]
            _grille(c, idx)
            col = (col_imposee or colors.HexColor(RAINBOW[serie % len(RAINBOW)])) if couleur else NOIR
            nums = _numeros(rng, deja)
            c.saveState()
            c.setFillColor(col)
            c.setStrokeColor(col)
            c.setLineWidth(0.25)
            c.setLineJoin(1)
            for ronds, vals in zip(ct["cols"], nums):
                for (x, y, r), v in zip(ronds, vals):
                    o = c.beginText()
                    o.setTextRenderMode(2)
                    o.setFont(POLICE, TAILLE)
                    o.setTextOrigin(_px(x) - c.stringWidth(str(v), POLICE, TAILLE) / 2.0,
                                    _py(y) - TAILLE * _CAP / 2.0)
                    o.textOut(str(v))
                    c.drawText(o)
            c.restoreState()
            sx = ct["cols"][0][-1][0]
            sy = ct["cols"][0][-1][1] + ct["cols"][0][-1][2] + 12
            c.setFillColor(GRIS_TRAIT)
            c.setFont("Helvetica", 5.5)
            c.drawCentredString(_px(sx), _py(sy), "N° %06d" % serie)
            serie += 1
            faits += 1
        c.restoreState()
        c.setFillColor(GRIS_TRAIT)
        c.setFont("Helvetica", 6)
        c.drawRightString(PAGE_W - 17, PAGE_H - 19, "%d" % no_page)
        no_page += 1
        c.showPage()
    c.save()
    buf.seek(0)
    return buf
