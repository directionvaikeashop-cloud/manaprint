# -*- coding: utf-8 -*-
"""MANAPRINT — VAI 7 BOULES (planche de Maeva du 29/09, 16 cartons / A4 PAYSAGE).
La planche est reprise TELLE QUELLE comme fond (traits passés en gris) ;
le n° de carte imprimé sur la maquette (« 000001 ») est gommé et réécrit.
7 numéros par carton (règle du 29/09) :
   colonne de gauche 61-70 : 3 numéros · milieu 71-80 : 1 numéro, EN HAUT
   (la goutte occupe le centre et le bas) · colonne de droite 81-90 : 3 numéros
   -> crieur 61 à 90 ; 144 000 cartons différents possibles.
Le plus petit en haut de chaque colonne.
Version refaite le 18/11/2026 (chiffres Helvetica-Bold, l'écriture du début)."""
import io, os as _os, random
from reportlab.pdfgen import canvas
from reportlab.lib.pagesizes import A4, landscape
from reportlab.lib import colors
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont

PAGE_W, PAGE_H = landscape(A4)
CARTES_PAGE = 16
# niveau B choisi par Maeva pour VAI : chiffres gris 0,40
_GRIS_ECO = colors.Color(0.40, 0.40, 0.40)
GRIS_TRAIT = colors.Color(105 / 255.0, 105 / 255.0, 105 / 255.0)
RAINBOW = ["#E53935", "#FB8C00", "#F9A825", "#43A047", "#00ACC1",
           "#1E88E5", "#3949AB", "#8E24AA", "#D81B60", "#6D4C41"]
COLONNES = [(61, 70), (71, 80), (81, 90)]
PAR_COLONNE = (3, 1, 3)

_ICI = _os.path.dirname(_os.path.abspath(__file__))
# ⭐ 18/11 (Maeva : « je veux l'original ») : l'écriture d'origine des jeux
#    ÉCO de la maison (POW, RAI, KEA…) = LATIN MODERN ROMAN, gris 0,40,
#    gras léger 0,012. Helvetica-Bold en secours si le fichier manque.
# ⭐ 18/11 (Maeva : « à l'impression sur les Konica 458C ça déborde un peu
#    les grilles ») : chiffres à ~65 % de la hauteur de case (de l'air tout
#    autour, même quand le toner s'étale) + planche ramenée dans une marge
#    de 6 mm (la Konica ne peut pas imprimer les 4,2 mm du bord).
# ⭐ 18/11 (Maeva : « je veux l'écriture qu'on a toujours utilisée au début,
#    là ça rapetisse les chiffres ») : HELVETICA-BOLD, chiffres pleins,
#    puis « grossis au maximum » : 27,5 pt, « 88 » tient dans la case la plus basse avec ~1,5 pt d air.
POLICE, _CAP, TAILLE = "Helvetica-Bold", 0.717, 27.5
_GRAS_TRAIT = 0.0
MARGE_SURE = 6 * 72 / 25.4      # 6 mm
ECHELLE = min((PAGE_W - 2 * MARGE_SURE) / PAGE_W, (PAGE_H - 2 * MARGE_SURE) / PAGE_H)
DECAL_X = (PAGE_W - PAGE_W * ECHELLE) / 2.0
DECAL_Y = (PAGE_H - PAGE_H * ECHELLE) / 2.0

_IMG_W, _IMG_H = 1536.0, 1024.0
_IMG_FOND = _os.path.join(_ICI, "vai_fond.png")

# centres (x, y) px des cases, colonne par colonne (gauche 3, milieu 1, droite 3) ;
# serie = (x0, y0, x1, y1) px de la place du n° de carte (aligné à droite)
CARTONS = [
    {'cols': [[(87.0, 90.0), (87.0, 142.0), (87.0, 191.0)], [(200.5, 90.0)], [(313.5, 90.0), (313.5, 142.0), (313.5, 191.0)]], 'serie': (301, 226, 364, 239)},
    {'cols': [[(466.5, 90.0), (466.5, 142.0), (466.5, 191.0)], [(579.0, 89.5)], [(691.0, 90.0), (691.0, 142.0), (691.0, 191.0)]], 'serie': (679, 226, 745, 239)},
    {'cols': [[(845.5, 90.0), (845.5, 142.0), (845.5, 191.0)], [(958.0, 89.5)], [(1070.0, 89.5), (1070.0, 142.0), (1070.0, 191.0)]], 'serie': (1058, 226, 1123, 239)},
    {'cols': [[(1224.5, 90.0), (1224.5, 142.0), (1224.5, 191.0)], [(1337.0, 89.5)], [(1449.0, 90.0), (1449.0, 142.0), (1449.0, 191.0)]], 'serie': (1436, 226, 1501, 239)},
    {'cols': [[(87.0, 344.0), (87.0, 396.5), (87.0, 445.0)], [(200.5, 344.0)], [(313.5, 344.0), (313.5, 396.5), (313.5, 445.0)]], 'serie': (301, 478, 366, 492)},
    {'cols': [[(466.5, 344.0), (466.5, 396.5), (466.5, 445.0)], [(579.0, 344.0)], [(691.0, 344.0), (691.0, 396.5), (691.0, 445.0)]], 'serie': (679, 478, 745, 492)},
    {'cols': [[(845.5, 344.0), (845.5, 396.5), (845.5, 445.0)], [(958.0, 344.0)], [(1070.0, 344.0), (1070.0, 396.5), (1070.0, 445.0)]], 'serie': (1058, 478, 1123, 492)},
    {'cols': [[(1224.5, 344.0), (1224.5, 396.5), (1224.5, 445.0)], [(1337.0, 344.0)], [(1449.0, 344.0), (1449.0, 396.5), (1449.0, 445.0)]], 'serie': (1436, 478, 1501, 492)},
    {'cols': [[(87.0, 595.5), (87.0, 648.0), (87.0, 697.0)], [(200.5, 595.5)], [(313.5, 595.5), (313.5, 648.0), (313.5, 696.5)]], 'serie': (301, 730, 366, 743)},
    {'cols': [[(466.5, 595.5), (466.5, 648.0), (466.5, 696.5)], [(579.0, 595.5)], [(691.0, 595.5), (691.0, 648.0), (691.0, 696.5)]], 'serie': (679, 730, 744, 743)},
    {'cols': [[(845.5, 595.5), (845.5, 648.0), (845.5, 696.5)], [(958.0, 595.5)], [(1070.0, 595.5), (1070.0, 648.0), (1070.0, 697.0)]], 'serie': (1058, 730, 1119, 743)},
    {'cols': [[(1224.5, 595.5), (1224.5, 648.0), (1224.5, 696.5)], [(1337.0, 595.5)], [(1449.0, 595.5), (1449.0, 648.0), (1449.0, 696.5)]], 'serie': (1436, 730, 1500, 743)},
    {'cols': [[(87.0, 846.5), (87.0, 899.5), (87.0, 948.0)], [(200.5, 846.5)], [(313.5, 846.5), (313.5, 899.5), (313.5, 948.0)]], 'serie': (301, 981, 366, 995)},
    {'cols': [[(466.5, 846.5), (466.5, 899.5), (466.5, 948.0)], [(579.0, 846.5)], [(691.0, 846.5), (691.0, 899.5), (691.0, 948.0)]], 'serie': (679, 981, 745, 995)},
    {'cols': [[(845.5, 846.5), (845.5, 899.5), (845.5, 948.0)], [(958.0, 846.5)], [(1070.0, 846.5), (1070.0, 899.5), (1070.0, 948.0)]], 'serie': (1058, 981, 1123, 995)},
    {'cols': [[(1224.5, 846.5), (1224.5, 899.5), (1224.5, 948.0)], [(1337.0, 846.5)], [(1449.0, 846.5), (1449.0, 899.5), (1449.0, 948.0)]], 'serie': (1436, 981, 1500, 995)},
]

_EPAIS = 0.6


def _chiffre(c, x, y, txt, taille):
    txt = str(txt)
    w = c.stringWidth(txt, POLICE, taille)
    c.saveState()
    try:
        t = c.beginText()
        if _GRAS_TRAIT > 0:
            c.setStrokeColor(c._fillColorObj)
            c.setLineWidth(_GRAS_TRAIT * taille)
            c.setLineJoin(1)
            t.setTextRenderMode(2)
        else:
            t.setTextRenderMode(0)
        t.setFont(POLICE, taille)
        t.setTextOrigin(x - w / 2.0, y)
        t.textOut(txt)
        c.drawText(t)
    finally:
        c.restoreState()


def _px(x):
    return x / _IMG_W * PAGE_W


def _py(y):
    return PAGE_H * (1 - y / _IMG_H)


def _numeros(rng, deja=None):
    # 3 · 1 · 3 numéros, triés : le plus petit en haut
    while True:
        cols = [sorted(rng.sample(range(a, b + 1), n)) for (a, b), n in zip(COLONNES, PAR_COLONNE)]
        cle = tuple(v for col in cols for v in col)
        if deja is None or cle not in deja:
            if deja is not None:
                deja.add(cle)
            return cols


def generer_pdf(nb_cartes=None, nb_tickets=None, serie_start=1, theme="", couleur=True,
                nom_evenement="", titre_jeu="", couleur_perso="", date_lieu="",
                telephone="", page_start=1, evenement_id="", style="", motif="",
                _deja=None, **_ig):
    n_ = nb_cartes if nb_cartes is not None else nb_tickets
    n_ = max(1, int(n_ if n_ else CARTES_PAGE))
    buf = io.BytesIO()
    c = canvas.Canvas(buf, pagesize=(PAGE_W, PAGE_H), pageCompression=1)
    c.setTitle("VAI 7 boules")
    rng = random.Random(int(serie_start) * 100003 + 6190)
    deja = _deja if _deja is not None else set()
    serie = int(serie_start)
    faits = 0
    col_imposee = None
    if couleur and couleur_perso:
        try:
            col_imposee = colors.HexColor(couleur_perso)
        except Exception:
            col_imposee = None

    while faits < n_:
        c.saveState()
        c.translate(DECAL_X, DECAL_Y)
        c.scale(ECHELLE, ECHELLE)
        try:
            c.drawImage(_IMG_FOND, 0, 0, PAGE_W, PAGE_H, preserveAspectRatio=False, mask="auto")
        except Exception:
            pass
        entete = "  ·  ".join(t for t in ((nom_evenement or "").strip(),
                                          (date_lieu or "").strip(),
                                          (telephone or "").strip()) if t)
        if entete:
            c.setFillColor(_GRIS_ECO)
            c.setFont("Helvetica-Bold", 6)
            c.drawString(_px(40), PAGE_H - 7, entete)
        for idx in range(CARTES_PAGE):
            if faits >= n_:
                break
            ct = CARTONS[idx]
            col = (col_imposee or colors.HexColor(RAINBOW[serie % len(RAINBOW)])) if couleur else _GRIS_ECO
            cols = _numeros(rng, deja)
            c.setFillColor(col)
            dy = TAILLE * _CAP / 2.0
            for j in range(3):          # colonne
                for (x, y), v in zip(ct["cols"][j], cols[j]):
                    _chiffre(c, _px(x), _py(y) - dy, v, TAILLE)
            x0, y0, x1, y1 = ct["serie"]
            c.setFillColor(GRIS_TRAIT)
            c.setFont("Helvetica-Bold", 10)
            c.drawRightString(_px(x1), _py(y1), "%06d" % serie)
            serie += 1
            faits += 1
        c.restoreState()
        c.showPage()
    c.save()
    buf.seek(0)
    return buf


if __name__ == "__main__":
    open("test_vai.pdf", "wb").write(generer_pdf(nb_cartes=16, couleur=False).read())
    print("VAI genere")
