# -*- coding: utf-8 -*-
"""MANAPRINT — LUNES 75 (planche de Maeva, refait le 19/11/2026).
12 cartons par feuille A4 PORTRAIT. La planche est reprise TELLE QUELLE comme
fond (trait gris uni, sans aplat gris taché) ; on n'ajoute que les chiffres, le n° de
série et le n° de page.
Règle : colonne de gauche 1-30 (×4) · colonne de droite 46-75 (×4), triés. Le 31-45 n'existe pas.
Chiffres Latin Modern GRAS, noirs, le plus gros que chaque case permet.
Feuille ramenée à 6 mm des bords (Konica)."""
import io, os as _os, random
from collections import Counter
from reportlab.pdfgen import canvas
from reportlab.lib.pagesizes import A4, landscape
from reportlab.lib import colors
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont

PAGE_W, PAGE_H = A4
CARTES_PAGE = 12
PLAGES = {'G': (1, 30), 'D': (46, 75)}
NOIR = colors.Color(0.05, 0.05, 0.05)
GRIS_TRAIT = colors.Color(0.40, 0.40, 0.40)
RAINBOW = ["#E53935", "#FB8C00", "#F9A825", "#43A047", "#00ACC1",
           "#1E88E5", "#3949AB", "#8E24AA", "#D81B60", "#6D4C41"]
_ICI = _os.path.dirname(_os.path.abspath(__file__))
POLICE, _CAP = "Helvetica-Bold", 0.717
try:
    pdfmetrics.registerFont(TTFont("LMROMANB", _os.path.join(_ICI, "LatinModern-Bold.ttf")))
    POLICE, _CAP = "LMROMANB", 0.66
except Exception:
    pass
_IMG_W, _IMG_H = 2480.0, 3508.0
_IMG_FOND = _os.path.join(_ICI, "lunes75_fond_v2.png")
MARGE_SURE = 6 * 72 / 25.4
ECHELLE = min((PAGE_W - 2 * MARGE_SURE) / PAGE_W, (PAGE_H - 2 * MARGE_SURE) / PAGE_H)
DECAL_X = (PAGE_W - PAGE_W * ECHELLE) / 2.0
DECAL_Y = (PAGE_H - PAGE_H * ECHELLE) / 2.0

# cases : (plage, (x0, y0, x1, y1) px), dans l'ordre où les numéros TRIÉS se posent ;
# serie = (alignement, x, ligne de base) px
CARTONS = [
    {'cells': [('G', (133, 275, 357, 457)), ('G', (133, 482, 357, 663)), ('G', (133, 688, 357, 869)), ('G', (133, 894, 357, 1076)), ('D', (378, 275, 601, 457)), ('D', (378, 482, 601, 663)), ('D', (378, 688, 601, 869)), ('D', (378, 894, 601, 1076))], 'serie': ('R', 593, 1124)},
    {'cells': [('G', (715, 275, 939, 457)), ('G', (715, 482, 939, 663)), ('G', (715, 688, 939, 869)), ('G', (715, 894, 939, 1076)), ('D', (960, 275, 1183, 457)), ('D', (960, 482, 1183, 663)), ('D', (960, 688, 1183, 869)), ('D', (960, 894, 1183, 1076))], 'serie': ('R', 1175, 1124)},
    {'cells': [('G', (1297, 275, 1521, 457)), ('G', (1297, 482, 1521, 663)), ('G', (1297, 688, 1521, 869)), ('G', (1297, 894, 1521, 1076)), ('D', (1542, 275, 1765, 457)), ('D', (1542, 482, 1765, 663)), ('D', (1542, 688, 1765, 869)), ('D', (1542, 894, 1765, 1076))], 'serie': ('R', 1757, 1124)},
    {'cells': [('G', (1879, 275, 2103, 457)), ('G', (1879, 482, 2103, 663)), ('G', (1879, 688, 2103, 869)), ('G', (1879, 894, 2103, 1076)), ('D', (2124, 275, 2347, 457)), ('D', (2124, 482, 2347, 663)), ('D', (2124, 688, 2347, 869)), ('D', (2124, 894, 2347, 1076))], 'serie': ('R', 2339, 1124)},
    {'cells': [('G', (133, 1383, 357, 1565)), ('G', (133, 1590, 357, 1771)), ('G', (133, 1796, 357, 1977)), ('G', (133, 2002, 357, 2184)), ('D', (378, 1383, 601, 1565)), ('D', (378, 1590, 601, 1771)), ('D', (378, 1796, 601, 1977)), ('D', (378, 2002, 601, 2184))], 'serie': ('R', 593, 2232)},
    {'cells': [('G', (715, 1383, 939, 1565)), ('G', (715, 1590, 939, 1771)), ('G', (715, 1796, 939, 1977)), ('G', (715, 2002, 939, 2184)), ('D', (960, 1383, 1183, 1565)), ('D', (960, 1590, 1183, 1771)), ('D', (960, 1796, 1183, 1977)), ('D', (960, 2002, 1183, 2184))], 'serie': ('R', 1175, 2232)},
    {'cells': [('G', (1297, 1383, 1521, 1565)), ('G', (1297, 1590, 1521, 1771)), ('G', (1297, 1796, 1521, 1977)), ('G', (1297, 2002, 1521, 2184)), ('D', (1542, 1383, 1765, 1565)), ('D', (1542, 1590, 1765, 1771)), ('D', (1542, 1796, 1765, 1977)), ('D', (1542, 2002, 1765, 2184))], 'serie': ('R', 1757, 2232)},
    {'cells': [('G', (1879, 1383, 2103, 1565)), ('G', (1879, 1590, 2103, 1771)), ('G', (1879, 1796, 2103, 1977)), ('G', (1879, 2002, 2103, 2184)), ('D', (2124, 1383, 2347, 1565)), ('D', (2124, 1590, 2347, 1771)), ('D', (2124, 1796, 2347, 1977)), ('D', (2124, 2002, 2347, 2184))], 'serie': ('R', 2339, 2232)},
    {'cells': [('G', (133, 2491, 357, 2673)), ('G', (133, 2698, 357, 2879)), ('G', (133, 2904, 357, 3085)), ('G', (133, 3110, 357, 3292)), ('D', (378, 2491, 601, 2673)), ('D', (378, 2698, 601, 2879)), ('D', (378, 2904, 601, 3085)), ('D', (378, 3110, 601, 3292))], 'serie': ('R', 593, 3340)},
    {'cells': [('G', (715, 2491, 939, 2673)), ('G', (715, 2698, 939, 2879)), ('G', (715, 2904, 939, 3085)), ('G', (715, 3110, 939, 3292)), ('D', (960, 2491, 1183, 2673)), ('D', (960, 2698, 1183, 2879)), ('D', (960, 2904, 1183, 3085)), ('D', (960, 3110, 1183, 3292))], 'serie': ('R', 1175, 3340)},
    {'cells': [('G', (1297, 2491, 1521, 2673)), ('G', (1297, 2698, 1521, 2879)), ('G', (1297, 2904, 1521, 3085)), ('G', (1297, 3110, 1521, 3292)), ('D', (1542, 2491, 1765, 2673)), ('D', (1542, 2698, 1765, 2879)), ('D', (1542, 2904, 1765, 3085)), ('D', (1542, 3110, 1765, 3292))], 'serie': ('R', 1757, 3340)},
    {'cells': [('G', (1879, 2491, 2103, 2673)), ('G', (1879, 2698, 2103, 2879)), ('G', (1879, 2904, 2103, 3085)), ('G', (1879, 3110, 2103, 3292)), ('D', (2124, 2491, 2347, 2673)), ('D', (2124, 2698, 2347, 2879)), ('D', (2124, 2904, 2347, 3085)), ('D', (2124, 3110, 2347, 3292))], 'serie': ('R', 2339, 3340)},
]
AIR_H, AIR_W = 0.62, 0.78
COMPTE = Counter(p for p, _c in CARTONS[0]["cells"])


def _px(x):
    return x / _IMG_W * PAGE_W


def _py(y):
    return PAGE_H * (1 - y / _IMG_H)


def _t(c):
    x0, y0, x1, y1 = c
    w, h = _px(x1) - _px(x0), _px(y1) - _px(y0)
    return int(min(AIR_H * h / _CAP, AIR_W * w / (pdfmetrics.stringWidth("88", POLICE, 1.0) + 0.02)) * 2) / 2.0


TAILLE = min(_t(c) for ct in CARTONS for _p, c in ct["cells"])


def _tirage(rng, p, n):
    a, b = PLAGES[p]
    pool = list(range(a, b + 1, 2)) if (a % 2 == 0 and "PAIR" in "LUNES 75") else list(range(a, b + 1))
    return sorted(rng.sample(pool, n))


def _numeros(rng, deja=None):
    while True:
        d = {p: _tirage(rng, p, n) for p, n in COMPTE.items()}
        cle = tuple((p, tuple(d[p])) for p in sorted(d))
        if deja is None or cle not in deja:
            if deja is not None:
                deja.add(cle)
            return d


def generer_pdf(nb_cartes=None, nb_tickets=None, serie_start=1, theme="", couleur=True,
                nom_evenement="", titre_jeu="", couleur_perso="", date_lieu="",
                telephone="", page_start=1, evenement_id="", style="", motif="",
                _deja=None, **_ig):
    n_ = nb_cartes if nb_cartes is not None else nb_tickets
    n_ = max(1, int(n_ if n_ else CARTES_PAGE))
    buf = io.BytesIO()
    c = canvas.Canvas(buf, pagesize=(PAGE_W, PAGE_H), pageCompression=1)
    c.setTitle("LUNES 75")
    rng = random.Random(int(serie_start) * 100003 + 3046)
    deja = _deja if _deja is not None else set()
    serie = int(serie_start)
    faits = 0
    try:
        no_page = max(1, int(page_start))
    except Exception:
        no_page = 1
    col_imposee = None
    if couleur and couleur_perso:
        try:
            col_imposee = colors.HexColor(couleur_perso)
        except Exception:
            col_imposee = None
    while faits < n_:
        c.saveState()
        c.translate(DECAL_X, DECAL_Y)
        c.scale(ECHELLE, ECHELLE)
        try:
            c.drawImage(_IMG_FOND, 0, 0, PAGE_W, PAGE_H, preserveAspectRatio=False, mask="auto")
        except Exception:
            pass
        for idx in range(CARTES_PAGE):
            if faits >= n_:
                break
            ct = CARTONS[idx]
            col = (col_imposee or colors.HexColor(RAINBOW[serie % len(RAINBOW)])) if couleur else NOIR
            nums = _numeros(rng, deja)
            pos = {p: 0 for p in nums}
            c.saveState()
            c.setFillColor(col); c.setStrokeColor(col)
            c.setLineWidth(0.5); c.setLineJoin(1)
            for p, (x0, y0, x1, y1) in ct["cells"]:
                v = str(nums[p][pos[p]]); pos[p] += 1
                o = c.beginText(); o.setTextRenderMode(2); o.setFont(POLICE, TAILLE)
                o.setTextOrigin(_px((x0 + x1) / 2.0) - c.stringWidth(v, POLICE, TAILLE) / 2.0,
                                _py((y0 + y1) / 2.0) - TAILLE * _CAP / 2.0)
                o.textOut(v); c.drawText(o)
            c.restoreState()
            al, sx, sy = ct["serie"]
            c.setFillColor(GRIS_TRAIT)
            c.setFont("Helvetica-Bold", 6)
            txt = "%06d" % serie
            if al == "R":
                c.drawRightString(_px(sx), _py(sy), txt)
            elif al == "C":
                c.drawCentredString(_px(sx), _py(sy), txt)
            else:
                c.drawString(_px(sx), _py(sy), txt)
            serie += 1
            faits += 1
        c.restoreState()
        c.setFillColor(GRIS_TRAIT)
        c.setFont("Helvetica", 6)
        c.drawRightString(PAGE_W - 17, PAGE_H - 13, "%d" % no_page)
        no_page += 1
        c.showPage()
    c.save()
    buf.seek(0)
    return buf
