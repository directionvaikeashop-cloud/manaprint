# -*- coding: utf-8 -*-
"""MANAPRINT — OHANA 75 · 4 SÉRIES (refait le 20/11/2026 sur la feuille de
référence de Maeva, « OHANA_75_4_série.png », cartons N° 540001-540004).

4 cartons par feuille A4 PAYSAGE (2 x 2). La planche (titre « OHANA 75 »
détouré, B I N G O, grille 5 x 5) est reprise TELLE QUELLE comme fond, en
2 tons francs (gris uni, propre sur la Konica).
Chaque case : un numéro dans un ROND (Latin Modern fin) + un numéro HORS BULLE
bien GRAS (DejaVu Sans gras), comme sur sa feuille.
Règle : colonne B 1-15 · I 16-30 · N 31-45 · G 46-60 · O 61-75 ;
2 numéros par case, tous différents dans la colonne (10 sur 15, 8 en N),
le plus petit dans le rond. Case du centre : « N° xxxxxx ».
Crieur : 1 à 75.
"""
import io, os as _os, random
from reportlab.pdfgen import canvas
from reportlab.lib.pagesizes import A4, landscape
from reportlab.lib import colors
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont

PAGE_W, PAGE_H = landscape(A4)
CARTES_PAGE = 4
PLAGES = [(1, 15), (16, 30), (31, 45), (46, 60), (61, 75)]

GRIS_GRAS = colors.Color(0.36, 0.36, 0.36)    # numéro hors bulle (gris soutenu, gras)
GRIS_ROND = colors.Color(0.40, 0.40, 0.40)    # numéro dans le rond
GRIS_TRAIT = colors.Color(80 / 255.0, 80 / 255.0, 80 / 255.0)
RAINBOW = ["#E53935", "#FB8C00", "#F9A825", "#43A047", "#00ACC1",
           "#1E88E5", "#3949AB", "#8E24AA", "#D81B60", "#6D4C41"]

_ICI = _os.path.dirname(_os.path.abspath(__file__))
POLICE_ROND, CAP_ROND = "Times-Roman", 0.66
try:
    pdfmetrics.registerFont(TTFont("LMROMAN", _os.path.join(_ICI, "LatinModern.ttf")))
    POLICE_ROND, CAP_ROND = "LMROMAN", 0.644
except Exception:
    pass
POLICE_GRAS, CAP_GRAS = "Helvetica-Bold", 0.718
for _f in (_os.path.join(_ICI, "DejaVuSans-Bold.ttf"),
           "/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf"):
    try:
        pdfmetrics.registerFont(TTFont("DJB", _f))
        POLICE_GRAS, CAP_GRAS = "DJB", 0.729
        break
    except Exception:
        pass

_IMG_W, _IMG_H = 1111.0, 781.0
_FOND = _os.path.join(_ICI, "ohana75_4series_fond_v2.png")
MARGE = 6 * 72 / 25.4
ECH = min((PAGE_W - 2 * MARGE) / _IMG_W, (PAGE_H - 2 * MARGE) / _IMG_H)
OX = (PAGE_W - _IMG_W * ECH) / 2.0
OY = (PAGE_H - _IMG_H * ECH) / 2.0

# lignes de la grille (px de la planche) : 2 colonnes de cartons x 2 rangées
XS = [[23.5, 131.5, 232.5, 336.5, 441.5, 548], [562, 668.5, 772.5, 877.5, 981.5, 1087]]
YS = [[105, 161.5, 218.5, 276.5, 332.5, 389], [489.5, 545.5, 601.5, 657.5, 710.5, 763]]

R_ROND = 22.0      # px
DX_ROND = 30.0     # px depuis le bord gauche de la case
FX_GRAS = 0.735    # centre du numéro gras, en fraction de la largeur de case
T_ROND = 22.0      # pt — numéro dans le rond
T_GRAS = 23.0      # pt — numéro hors bulle (gras)
T_SERIE = 7.0


def _px(x):
    return OX + x * ECH


def _py(y):
    return OY + (_IMG_H - y) * ECH


def _carton(rng, deja):
    while True:
        cols = []
        for ci, (a, b) in enumerate(PLAGES):
            n = 4 if ci == 2 else 5
            t = rng.sample(range(a, b + 1), 2 * n)
            cols.append([tuple(sorted(t[2 * i:2 * i + 2])) for i in range(n)])
        cle = tuple(p for col in cols for p in col)
        if cle not in deja:
            deja.add(cle)
            return cols


def _texte(c, txt, x, yc, police, t, cap, gras):
    o = c.beginText()
    if gras:
        c.setLineWidth(gras * t)
        c.setLineJoin(1)
        o.setTextRenderMode(2)
    o.setFont(police, t)
    o.setTextOrigin(x - c.stringWidth(txt, police, t) / 2.0, yc - t * cap / 2.0)
    o.textOut(txt)
    c.drawText(o)


def generer_pdf(nb_cartes=None, nb_tickets=None, serie_start=1, theme="", couleur=True,
                nom_evenement="", titre_jeu="", couleur_perso="", date_lieu="",
                telephone="", page_start=1, evenement_id="", style="", motif="",
                _deja=None, **_ig):
    n_ = nb_cartes if nb_cartes is not None else nb_tickets
    n_ = max(1, int(n_ if n_ else CARTES_PAGE))
    buf = io.BytesIO()
    c = canvas.Canvas(buf, pagesize=(PAGE_W, PAGE_H), pageCompression=1)
    c.setTitle("OHANA 75 - 4 series")
    rng = random.Random(int(serie_start) * 100003 + 7544)
    deja = _deja if _deja is not None else set()
    try:
        no_page = max(1, int(page_start))
    except Exception:
        no_page = 1
    serie = int(serie_start)
    faits = 0
    while faits < n_:
        c.drawImage(_FOND, OX, OY, _IMG_W * ECH, _IMG_H * ECH, preserveAspectRatio=False, mask="auto")
        for k in range(CARTES_PAGE):
            if faits >= n_:
                break
            xs, ys = XS[k % 2], YS[k // 2]
            cols = _carton(rng, deja)
            gras = (colors.HexColor(RAINBOW[serie % len(RAINBOW)]) if couleur else GRIS_GRAS)
            for ci in range(5):
                cases = cols[ci]
                it = iter(cases)
                for li in range(5):
                    x0, x1 = xs[ci], xs[ci + 1]
                    y0, y1 = ys[li], ys[li + 1]
                    yc = _py((y0 + y1) / 2.0)
                    if ci == 2 and li == 2:
                        c.setFillColor(GRIS_ROND)
                        c.setFont(POLICE_ROND, T_SERIE)
                        # ⭐ 21/11 : personnalisation sous le n° (lignes séparées par « | »)
                        _lignes = [l.strip() for l in (nom_evenement or "").split("|") if l.strip()]
                        _n = len(_lignes)
                        _dy = {0: 0.0, 1: 5.0, 2: 9.0}.get(_n, 11.0)
                        c.drawCentredString(_px((x0 + x1) / 2.0), yc - T_SERIE * 0.3 + _dy,
                                            "N° %06d" % serie)
                        if _lignes:
                            _t = 9.0
                            while _t > 4 and max(c.stringWidth(l, "Helvetica-Bold", _t) for l in _lignes) > (x1 - x0) * ECH * 0.88:
                                _t -= 0.25
                            c.setFillColor(colors.black)
                            c.setFont("Helvetica-Bold", _t)
                            for _i, _l in enumerate(_lignes):
                                c.drawCentredString(_px((x0 + x1) / 2.0), yc + _dy - 13.0 - _i * (_t * 1.15), _l)
                        continue
                    petit, grand = next(it)
                    xr = _px(x0 + DX_ROND)
                    c.setStrokeColor(GRIS_TRAIT)
                    c.setLineWidth(1.1)
                    c.circle(xr, yc, R_ROND * ECH, stroke=1, fill=0)
                    c.saveState()
                    c.setFillColor(GRIS_ROND)
                    _texte(c, str(petit), xr, yc, POLICE_ROND, T_ROND, CAP_ROND, 0)
                    c.setFillColor(gras)
                    c.setStrokeColor(gras)
                    _texte(c, str(grand), _px(x0 + FX_GRAS * (x1 - x0)), yc,
                           POLICE_GRAS, T_GRAS, CAP_GRAS, 0.02)
                    c.restoreState()
            serie += 1
            faits += 1
        # ⭐ 21/11 : n° de page et personnalisation dans la bande blanche du haut
        #    de la planche — DANS la zone que la Konica imprime (> 6 mm du bord)
        c.setFillColor(GRIS_ROND)
        c.setFont("Helvetica", 7)
        c.drawRightString(_px(1087), _py(13), "%d" % no_page)
        if (nom_evenement or "").strip():
            c.setFillColor(colors.black)
            c.setFont("Helvetica-Bold", 8)
            c.drawCentredString(PAGE_W / 2.0, _py(13), "  —  ".join(l.strip() for l in nom_evenement.split("|") if l.strip()))
        no_page += 1
        c.showPage()
    c.save()
    buf.seek(0)
    return buf


if __name__ == "__main__":
    open("test_ohana75_4s.pdf", "wb").write(generer_pdf(nb_cartes=4, serie_start=540001, couleur=False).read())
    print("OHANA 75 4 series genere")
