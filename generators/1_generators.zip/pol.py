# -*- coding: utf-8 -*-
"""MANAPRINT — POL 6 boules (planche de Maeva du 29/09, refait le 19/11/2026).
16 cartons par feuille A4 PAYSAGE. La maquette est reprise TELLE QUELLE comme
fond, en 2 tons francs (rendu propre sur la Konica) ; on n'ajoute que les
chiffres, le n° de série et le n° de page.
Règle : col 30-40 · col 41-50 · col 51-60, deux numéros par colonne, le petit en haut. Six numéros. Crieur 30-60.
Chiffres en Latin Modern (écriture maison), NOIRS, le plus gros possible avec de l'air dans la case.
Feuille ramenée à 6 mm des bords (la Konica n'imprime pas les 4,2 mm du bord)."""
import io, os as _os, random
from reportlab.pdfgen import canvas
from reportlab.lib.pagesizes import A4, landscape
from reportlab.lib import colors

PAGE_W, PAGE_H = landscape(A4)
CARTES_PAGE = 16
PLAGES = [(30, 40), (41, 50), (51, 60)]
PAR_COLONNE = [2, 2, 2]
NOIR = colors.Color(0.08, 0.08, 0.08)
GRIS_TRAIT = colors.Color(0.40, 0.40, 0.40)
RAINBOW = ["#E53935", "#FB8C00", "#F9A825", "#43A047", "#00ACC1",
           "#1E88E5", "#3949AB", "#8E24AA", "#D81B60", "#6D4C41"]
POLICE, _CAP, _LARG88 = "Helvetica-Bold", 0.717, 1.112
# ⭐ 18/11 (Maeva : « ces jeux avaient déjà leurs propres écritures ») :
#    l'écriture maison des planches ÉCO = LATIN MODERN ROMAN (comme RAI, KEA, P6).
try:
    from reportlab.pdfbase import pdfmetrics as _pm
    from reportlab.pdfbase.ttfonts import TTFont as _TF
    import os as _o
    _pm.registerFont(_TF("LMROMAN", _o.path.join(_o.path.dirname(_o.path.abspath(__file__)), "LatinModern.ttf")))
    POLICE, _CAP, _LARG88 = "LMROMAN", 0.644, 1.0
    # ⭐ 19/11 (Maeva : « mets du gras ») : la même écriture en GRAS, comme KEA
    _pm.registerFont(_TF("LMROMANB", _o.path.join(_o.path.dirname(_o.path.abspath(__file__)), "LatinModern-Bold.ttf")))
    POLICE, _CAP, _LARG88 = "LMROMANB", 0.644, 1.15
except Exception:
    pass
_ICI = _os.path.dirname(_os.path.abspath(__file__))
_IMG_W, _IMG_H = 1536.0, 1086.0
_IMG_FOND = _os.path.join(_ICI, "pol_fond.png")
MARGE_SURE = 6 * 72 / 25.4
ECHELLE = min((PAGE_W - 2 * MARGE_SURE) / PAGE_W, (PAGE_H - 2 * MARGE_SURE) / PAGE_H)
DECAL_X = (PAGE_W - PAGE_W * ECHELLE) / 2.0
DECAL_Y = (PAGE_H - PAGE_H * ECHELLE) / 2.0

# pour chaque carton : les cases (x0, y0, x1, y1) px, colonne par colonne,
# de haut en bas ; serie = (x0, y0, x1, y1) px de la place du n° de série.
CARTONS = [
    {'cols': [[(36.0, 95.0, 141.0, 168.0), (36.0, 171.0, 140.0, 240.0)], [(143.0, 95.0, 253.0, 168.0), (143.0, 171.0, 252.0, 240.0)], [(255.0, 95.0, 357.0, 168.0), (255.0, 171.0, 357.0, 240.0)]], 'serie': (208, 249, 362, 263)},
    {'cols': [[(412.0, 95.0, 519.0, 168.0), (412.0, 171.0, 519.0, 240.0)], [(521.0, 95.0, 631.0, 168.0), (521.0, 171.0, 631.0, 240.0)], [(633.0, 95.0, 740.0, 168.0), (633.0, 171.0, 740.0, 240.0)]], 'serie': (587, 249, 742, 263)},
    {'cols': [[(796.0, 95.0, 903.0, 168.0), (796.0, 171.0, 902.0, 240.0)], [(905.0, 95.0, 1015.0, 168.0), (905.0, 171.0, 1014.0, 240.0)], [(1017.0, 95.0, 1123.0, 168.0), (1017.0, 171.0, 1123.0, 240.0)]], 'serie': (970, 249, 1125, 263)},
    {'cols': [[(1180.0, 95.0, 1286.0, 168.0), (1180.0, 171.0, 1285.0, 240.0)], [(1288.0, 96.0, 1396.0, 168.0), (1288.0, 171.0, 1396.0, 240.0)], [(1399.0, 95.0, 1504.0, 168.0), (1399.0, 171.0, 1504.0, 240.0)]], 'serie': (1352, 249, 1506, 263)},
    {'cols': [[(36.0, 346.0, 141.0, 421.0), (36.0, 423.0, 140.0, 493.0)], [(143.0, 346.0, 253.0, 421.0), (143.0, 423.0, 252.0, 493.0)], [(255.0, 346.0, 357.0, 421.0), (255.0, 423.0, 357.0, 493.0)]], 'serie': (208, 502, 362, 517)},
    {'cols': [[(412.0, 346.0, 519.0, 421.0), (412.0, 423.0, 519.0, 493.0)], [(521.0, 346.0, 631.0, 421.0), (521.0, 423.0, 631.0, 493.0)], [(633.0, 346.0, 740.0, 421.0), (633.0, 423.0, 740.0, 493.0)]], 'serie': (587, 502, 743, 517)},
    {'cols': [[(796.0, 346.0, 902.0, 421.0), (796.0, 423.0, 902.0, 493.0)], [(905.0, 346.0, 1014.0, 421.0), (905.0, 423.0, 1014.0, 493.0)], [(1017.0, 346.0, 1123.0, 421.0), (1017.0, 423.0, 1123.0, 493.0)]], 'serie': (970, 502, 1125, 517)},
    {'cols': [[(1180.0, 346.0, 1285.0, 421.0), (1180.0, 423.0, 1285.0, 493.0)], [(1288.0, 346.0, 1396.0, 421.0), (1288.0, 423.0, 1396.0, 493.0)], [(1399.0, 346.0, 1504.0, 421.0), (1399.0, 423.0, 1504.0, 493.0)]], 'serie': (1352, 502, 1506, 517)},
    {'cols': [[(36.0, 600.0, 141.0, 674.0), (36.0, 677.0, 140.0, 747.0)], [(143.0, 600.0, 253.0, 674.0), (143.0, 677.0, 252.0, 747.0)], [(255.0, 600.0, 357.0, 674.0), (255.0, 677.0, 357.0, 747.0)]], 'serie': (208, 757, 362, 771)},
    {'cols': [[(412.0, 601.0, 519.0, 675.0), (412.0, 677.0, 519.0, 748.0)], [(521.0, 601.0, 631.0, 675.0), (521.0, 677.0, 631.0, 748.0)], [(633.0, 601.0, 740.0, 675.0), (633.0, 677.0, 740.0, 748.0)]], 'serie': (587, 757, 743, 771)},
    {'cols': [[(796.0, 601.0, 902.0, 675.0), (796.0, 677.0, 902.0, 748.0)], [(905.0, 601.0, 1014.0, 675.0), (905.0, 677.0, 1014.0, 748.0)], [(1017.0, 601.0, 1123.0, 675.0), (1017.0, 677.0, 1123.0, 748.0)]], 'serie': (970, 757, 1124, 771)},
    {'cols': [[(1180.0, 601.0, 1285.0, 675.0), (1180.0, 677.0, 1285.0, 748.0)], [(1288.0, 601.0, 1396.0, 675.0), (1288.0, 677.0, 1396.0, 748.0)], [(1399.0, 601.0, 1504.0, 675.0), (1399.0, 677.0, 1504.0, 748.0)]], 'serie': (1352, 757, 1506, 771)},
    {'cols': [[(36.0, 855.0, 141.0, 929.0), (36.0, 931.0, 140.0, 1000.0)], [(143.0, 855.0, 253.0, 929.0), (143.0, 931.0, 252.0, 1000.0)], [(255.0, 855.0, 357.0, 929.0), (255.0, 931.0, 357.0, 1001.0)]], 'serie': (208, 1010, 362, 1025)},
    {'cols': [[(412.0, 855.0, 519.0, 929.0), (412.0, 931.0, 519.0, 1001.0)], [(521.0, 855.0, 631.0, 929.0), (521.0, 931.0, 631.0, 1001.0)], [(633.0, 855.0, 740.0, 929.0), (633.0, 931.0, 740.0, 1001.0)]], 'serie': (587, 1010, 743, 1025)},
    {'cols': [[(796.0, 855.0, 902.0, 929.0), (796.0, 931.0, 902.0, 1001.0)], [(905.0, 855.0, 1014.0, 929.0), (905.0, 931.0, 1014.0, 1001.0)], [(1017.0, 855.0, 1123.0, 929.0), (1017.0, 931.0, 1123.0, 1001.0)]], 'serie': (970, 1010, 1125, 1025)},
    {'cols': [[(1180.0, 855.0, 1285.0, 929.0), (1180.0, 931.0, 1285.0, 1001.0)], [(1288.0, 855.0, 1396.0, 929.0), (1288.0, 931.0, 1396.0, 1001.0)], [(1399.0, 855.0, 1504.0, 929.0), (1399.0, 931.0, 1504.0, 1001.0)]], 'serie': (1352, 1010, 1506, 1025)},
]
ALIGN_SERIE = "R"
AIR_H, AIR_W = 0.62, 0.74   # part de la case que « 88 » peut occuper


def _px(x):
    return x / _IMG_W * PAGE_W


def _py(y):
    return PAGE_H * (1 - y / _IMG_H)


def _taille_case(x0, y0, x1, y1):
    h = _px(y1) - _px(y0)
    w = _px(x1) - _px(x0)
    t = min(AIR_H * h / _CAP, AIR_W * w / _LARG88)
    return int(t * 2) / 2.0


# une taille par « famille » de cases (même hauteur), la plus petite de la famille
_TAILLES = {}
for _ct in CARTONS:
    for _col in _ct["cols"]:
        for _c in _col:
            _k = round((_c[3] - _c[1]) / 20.0)
            _TAILLES[_k] = min(_TAILLES.get(_k, 999), _taille_case(*_c))


def _taille(c):
    return _TAILLES[round((c[3] - c[1]) / 20.0)]


def _numeros(rng, deja=None):
    while True:
        d = [sorted(rng.sample(range(a, b + 1), n)) for (a, b), n in zip(PLAGES, PAR_COLONNE)]
        cle = tuple(v for p in d for v in p)
        if deja is None or cle not in deja:
            if deja is not None:
                deja.add(cle)
            return d


def _num(c, txt, x, y, t):
    o = c.beginText()
    o.setTextRenderMode(2)
    o.setFont(POLICE, t)
    o.setTextOrigin(x - c.stringWidth(txt, POLICE, t) / 2.0, y)
    o.textOut(txt)
    c.drawText(o)


def generer_pdf(nb_cartes=None, nb_tickets=None, serie_start=1, theme="", couleur=True,
                nom_evenement="", titre_jeu="", couleur_perso="", date_lieu="",
                telephone="", page_start=1, evenement_id="", style="", motif="",
                _deja=None, **_ig):
    n_ = nb_cartes if nb_cartes is not None else nb_tickets
    n_ = max(1, int(n_ if n_ else CARTES_PAGE))
    buf = io.BytesIO()
    c = canvas.Canvas(buf, pagesize=(PAGE_W, PAGE_H), pageCompression=1)
    c.setTitle("POL 6 boules")
    rng = random.Random(int(serie_start) * 100003 + 3060)
    deja = _deja if _deja is not None else set()
    serie = int(serie_start)
    faits = 0
    try:
        no_page = max(1, int(page_start))
    except Exception:
        no_page = 1
    col_imposee = None
    if couleur and couleur_perso:
        try:
            col_imposee = colors.HexColor(couleur_perso)
        except Exception:
            col_imposee = None
    while faits < n_:
        c.saveState()
        c.translate(DECAL_X, DECAL_Y)
        c.scale(ECHELLE, ECHELLE)
        try:
            c.drawImage(_IMG_FOND, 0, 0, PAGE_W, PAGE_H, preserveAspectRatio=False, mask="auto")
        except Exception:
            pass
        entete = "  ·  ".join(t for t in ((nom_evenement or "").strip(),
                                          (date_lieu or "").strip(),
                                          (telephone or "").strip()) if t)
        for idx in range(CARTES_PAGE):
            if faits >= n_:
                break
            ct = CARTONS[idx]
            col = (col_imposee or colors.HexColor(RAINBOW[serie % len(RAINBOW)])) if couleur else NOIR
            nums = _numeros(rng, deja)
            c.saveState()
            c.setFillColor(col)
            c.setStrokeColor(col)
            c.setLineWidth(0.5)
            c.setLineJoin(1)
            for cases, vals in zip(ct["cols"], nums):
                for (x0, y0, x1, y1), v in zip(cases, vals):
                    t = _taille((x0, y0, x1, y1))
                    _num(c, str(v), _px((x0 + x1) / 2.0), _py((y0 + y1) / 2.0) - t * _CAP / 2.0, t)
            c.restoreState()
            sx0, sy0, sx1, sy1 = ct["serie"]
            ts = min(9.0, (_px(sy1) - _px(sy0)) / 0.72)
            c.setFillColor(GRIS_TRAIT)
            c.setFont("Helvetica-Bold", ts)
            if ALIGN_SERIE == "R":
                c.drawRightString(_px(sx1), _py(sy1), "%06d" % serie)
            else:
                c.drawString(_px(sx0), _py(sy1), "%06d" % serie)
            serie += 1
            faits += 1
        c.restoreState()
        # n° de page (et personnalisation) dans la marge que la Konica imprime
        c.setFillColor(GRIS_TRAIT)
        c.setFont("Helvetica", 6)
        c.drawRightString(PAGE_W - 17, PAGE_H - 19, "%03d" % no_page)
        if entete:
            c.setFont("Helvetica-Bold", 6.5)
            c.drawCentredString(PAGE_W / 2.0, PAGE_H - 13.5, entete)
        no_page += 1
        c.showPage()
    c.save()
    buf.seek(0)
    return buf


if __name__ == "__main__":
    open("test.pdf", "wb").write(generer_pdf(nb_cartes=CARTES_PAGE, couleur=False).read())
