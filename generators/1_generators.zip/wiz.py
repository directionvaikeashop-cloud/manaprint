# -*- coding: utf-8 -*-
"""MANAPRINT — WIZ 4 boules (planche de Maeva, refait le 19/11/2026).
16 cartons par feuille A4 PAYSAGE. La planche est reprise TELLE QUELLE comme fond
(trait gris uni, sans aplat gris taché) ; on n'ajoute que les chiffres, le n° de
série et le n° de page.
Règle : haut et bas 16-30 (le petit en haut) · gauche 1-15 · droite 31-45. Crieur 1-45.
Chiffres Latin Modern GRAS, noirs, le plus gros que chaque case permet.
Feuille ramenée à 6 mm des bords (Konica)."""
import io, os as _os, random
from collections import Counter
from reportlab.pdfgen import canvas
from reportlab.lib.pagesizes import A4, landscape
from reportlab.lib import colors
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont

PAGE_W, PAGE_H = landscape(A4)
CARTES_PAGE = 16
PLAGES = {'T': (16, 30), 'W': (1, 15), 'Z': (31, 45)}
NOIR = colors.Color(0.05, 0.05, 0.05)
GRIS_TRAIT = colors.Color(0.40, 0.40, 0.40)
RAINBOW = ["#E53935", "#FB8C00", "#F9A825", "#43A047", "#00ACC1",
           "#1E88E5", "#3949AB", "#8E24AA", "#D81B60", "#6D4C41"]
_ICI = _os.path.dirname(_os.path.abspath(__file__))
POLICE, _CAP = "Helvetica-Bold", 0.717
try:
    pdfmetrics.registerFont(TTFont("LMROMANB", _os.path.join(_ICI, "LatinModern-Bold.ttf")))
    POLICE, _CAP = "LMROMANB", 0.66
except Exception:
    pass
_IMG_W, _IMG_H = 1536.0, 1086.0
_IMG_FOND = _os.path.join(_ICI, "wiz_fond.png")
MARGE_SURE = 6 * 72 / 25.4
ECHELLE = min((PAGE_W - 2 * MARGE_SURE) / PAGE_W, (PAGE_H - 2 * MARGE_SURE) / PAGE_H)
DECAL_X = (PAGE_W - PAGE_W * ECHELLE) / 2.0
DECAL_Y = (PAGE_H - PAGE_H * ECHELLE) / 2.0

# cases : (plage, (x0, y0, x1, y1) px), dans l'ordre où les numéros triés se posent ;
# serie = (alignement, x, ligne de base) px
CARTONS = [
    {'cells': [('T', (47, 90, 381, 150)), ('W', (47, 153, 213, 214)), ('Z', (217, 153, 381, 214)), ('T', (47, 217, 381, 277))], 'serie': ('R', 375, 76)},
    {'cells': [('T', (417, 90, 752, 150)), ('W', (417, 153, 584, 214)), ('Z', (587, 153, 752, 214)), ('T', (417, 217, 752, 277))], 'serie': ('R', 746, 76)},
    {'cells': [('T', (786, 90, 1120, 150)), ('W', (786, 153, 952, 214)), ('Z', (956, 153, 1120, 214)), ('T', (786, 217, 1120, 277))], 'serie': ('R', 1114, 76)},
    {'cells': [('T', (1156, 90, 1491, 150)), ('W', (1156, 153, 1322, 214)), ('Z', (1325, 153, 1491, 214)), ('T', (1156, 217, 1491, 277))], 'serie': ('R', 1485, 76)},
    {'cells': [('T', (47, 343, 381, 401)), ('W', (47, 404, 213, 464)), ('Z', (217, 404, 381, 464)), ('T', (47, 468, 381, 527))], 'serie': ('R', 375, 329)},
    {'cells': [('T', (417, 343, 752, 401)), ('W', (417, 404, 584, 464)), ('Z', (587, 404, 752, 464)), ('T', (417, 468, 752, 527))], 'serie': ('R', 746, 329)},
    {'cells': [('T', (786, 343, 1120, 401)), ('W', (786, 404, 952, 464)), ('Z', (955, 404, 1120, 464)), ('T', (786, 467, 1120, 527))], 'serie': ('R', 1114, 329)},
    {'cells': [('T', (1156, 343, 1490, 401)), ('W', (1156, 404, 1322, 464)), ('Z', (1325, 404, 1491, 464)), ('T', (1156, 467, 1491, 527))], 'serie': ('R', 1485, 329)},
    {'cells': [('T', (47, 594, 381, 652)), ('W', (47, 655, 213, 713)), ('Z', (217, 655, 381, 713)), ('T', (47, 716, 381, 772))], 'serie': ('R', 375, 580)},
    {'cells': [('T', (417, 594, 752, 652)), ('W', (417, 655, 584, 713)), ('Z', (587, 655, 752, 713)), ('T', (417, 716, 752, 772))], 'serie': ('R', 746, 580)},
    {'cells': [('T', (786, 594, 1120, 652)), ('W', (786, 655, 952, 713)), ('Z', (955, 655, 1120, 713)), ('T', (786, 716, 1120, 772))], 'serie': ('R', 1114, 580)},
    {'cells': [('T', (1156, 594, 1491, 652)), ('W', (1156, 655, 1322, 713)), ('Z', (1325, 655, 1491, 713)), ('T', (1156, 716, 1491, 772))], 'serie': ('R', 1485, 580)},
    {'cells': [('T', (47, 838, 381, 896)), ('W', (47, 899, 213, 957)), ('Z', (217, 899, 381, 957)), ('T', (47, 960, 381, 1018))], 'serie': ('R', 375, 824)},
    {'cells': [('T', (417, 838, 752, 896)), ('W', (417, 899, 584, 957)), ('Z', (587, 899, 752, 957)), ('T', (417, 960, 752, 1018))], 'serie': ('R', 746, 824)},
    {'cells': [('T', (786, 838, 1120, 896)), ('W', (786, 899, 952, 957)), ('Z', (955, 899, 1120, 957)), ('T', (786, 960, 1120, 1018))], 'serie': ('R', 1114, 824)},
    {'cells': [('T', (1156, 838, 1491, 896)), ('W', (1156, 899, 1322, 957)), ('Z', (1325, 899, 1491, 957)), ('T', (1156, 960, 1491, 1018))], 'serie': ('R', 1485, 824)},
]
AIR_H, AIR_W = 0.62, 0.78
COMPTE = Counter(pl for pl, _c in CARTONS[0]["cells"])


def _px(x):
    return x / _IMG_W * PAGE_W


def _py(y):
    return PAGE_H * (1 - y / _IMG_H)


def _t(c):
    x0, y0, x1, y1 = c
    w, h = _px(x1) - _px(x0), _px(y1) - _px(y0)
    return int(min(AIR_H * h / _CAP, AIR_W * w / (pdfmetrics.stringWidth("88", POLICE, 1.0) + 0.02)) * 2) / 2.0


TAILLE = min(_t(c) for ct in CARTONS for _p, c in ct["cells"])


def _numeros(rng, deja=None):
    while True:
        d = {pl: sorted(rng.sample(range(PLAGES[pl][0], PLAGES[pl][1] + 1), n)) for pl, n in COMPTE.items()}
        cle = tuple((pl, tuple(d[pl])) for pl in sorted(d))
        if deja is None or cle not in deja:
            if deja is not None:
                deja.add(cle)
            return d


def generer_pdf(nb_cartes=None, nb_tickets=None, serie_start=1, theme="", couleur=True,
                nom_evenement="", titre_jeu="", couleur_perso="", date_lieu="",
                telephone="", page_start=1, evenement_id="", style="", motif="",
                _deja=None, **_ig):
    n_ = nb_cartes if nb_cartes is not None else nb_tickets
    n_ = max(1, int(n_ if n_ else CARTES_PAGE))
    buf = io.BytesIO()
    c = canvas.Canvas(buf, pagesize=(PAGE_W, PAGE_H), pageCompression=1)
    c.setTitle("WIZ 4 boules")
    rng = random.Random(int(serie_start) * 100003 + 4501)
    deja = _deja if _deja is not None else set()
    serie = int(serie_start)
    faits = 0
    try:
        no_page = max(1, int(page_start))
    except Exception:
        no_page = 1
    col_imposee = None
    if couleur and couleur_perso:
        try:
            col_imposee = colors.HexColor(couleur_perso)
        except Exception:
            col_imposee = None
    while faits < n_:
        c.saveState()
        c.translate(DECAL_X, DECAL_Y)
        c.scale(ECHELLE, ECHELLE)
        try:
            c.drawImage(_IMG_FOND, 0, 0, PAGE_W, PAGE_H, preserveAspectRatio=False, mask="auto")
        except Exception:
            pass
        for idx in range(CARTES_PAGE):
            if faits >= n_:
                break
            ct = CARTONS[idx]
            col = (col_imposee or colors.HexColor(RAINBOW[serie % len(RAINBOW)])) if couleur else NOIR
            nums = _numeros(rng, deja)
            pos = {pl: 0 for pl in nums}
            c.saveState()
            c.setFillColor(col); c.setStrokeColor(col)
            c.setLineWidth(0.5); c.setLineJoin(1)
            for pl, (x0, y0, x1, y1) in ct["cells"]:
                v = str(nums[pl][pos[pl]]); pos[pl] += 1
                o = c.beginText(); o.setTextRenderMode(2); o.setFont(POLICE, TAILLE)
                o.setTextOrigin(_px((x0 + x1) / 2.0) - c.stringWidth(v, POLICE, TAILLE) / 2.0,
                                _py((y0 + y1) / 2.0) - TAILLE * _CAP / 2.0)
                o.textOut(v); c.drawText(o)
            c.restoreState()
            al, sx, sy = ct["serie"]
            c.setFillColor(GRIS_TRAIT)
            c.setFont("Helvetica-Bold", 7 if al == "L" and False else 5.5)
            txt = ("%06d" if False else "N° %06d") % serie
            if al == "R":
                c.drawRightString(_px(sx), _py(sy), txt)
            else:
                c.drawString(_px(sx), _py(sy), txt)
            serie += 1
            faits += 1
        c.restoreState()
        c.setFillColor(GRIS_TRAIT)
        c.setFont("Helvetica", 6)
        c.drawRightString(PAGE_W - 17, PAGE_H - 13, "%d" % no_page)
        no_page += 1
        c.showPage()
    c.save()
    buf.seek(0)
    return buf
