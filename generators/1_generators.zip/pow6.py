# -*- coding: utf-8 -*-
"""MANAPRINT — POW 6 BOULES (planche de Maeva du 28/09, 16 cartons / A4 PAYSAGE).
La planche est reprise TELLE QUELLE comme fond (ses traits sont déjà gris) ;
on n'ajoute que les chiffres et le n° de série.
6 numéros par carton, 2 rangées x 3 colonnes, DEUX par famille de neuf,
ordre libre (règle du 28/09) :
   colonne 1 : 1-9 (x2) · colonne 2 : 10-18 (x2) · colonne 3 : 19-27 (x2)
   -> crieur 1 à 27 ; 373 248 cartons différents possibles.
Version refaite le 18/11/2026 (chiffres Latin Modern, l'écriture d'origine)."""
import io, os as _os, random
from reportlab.pdfgen import canvas
from reportlab.lib.pagesizes import A4, landscape
from reportlab.lib import colors
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont

PAGE_W, PAGE_H = landscape(A4)
CARTES_PAGE = 16
# niveau B choisi par Maeva le 28/09 pour POW 6 : chiffres gris 0,40
_GRIS_ECO = colors.Color(0.40, 0.40, 0.40)
GRIS_TRAIT = colors.Color(105 / 255.0, 105 / 255.0, 105 / 255.0)
RAINBOW = ["#E53935", "#FB8C00", "#F9A825", "#43A047", "#00ACC1",
           "#1E88E5", "#3949AB", "#8E24AA", "#D81B60", "#6D4C41"]
COLONNES = [(1, 9), (10, 18), (19, 27)]

_ICI = _os.path.dirname(_os.path.abspath(__file__))
# ⭐ 18/11 (Maeva : « je veux l'original ») : l'écriture d'origine des jeux
#    ÉCO de la maison (POW, RAI, KEA…) = LATIN MODERN ROMAN, gris 0,40,
#    gras léger 0,012. Helvetica-Bold en secours si le fichier manque.
# ⭐ 18/11 (Maeva : « à l'impression sur les Konica 458C ça déborde un peu
#    les grilles ») : chiffres à ~65 % de la hauteur de case (de l'air tout
#    autour, même quand le toner s'étale) + planche ramenée dans une marge
#    de 6 mm (la Konica ne peut pas imprimer les 4,2 mm du bord).
POLICE, _CAP, TAILLE = "Helvetica-Bold", 0.717, 40.0
_GRAS_TRAIT = 0.0
try:
    pdfmetrics.registerFont(TTFont("LMROMAN", _os.path.join(_ICI, "LatinModern.ttf")))
    POLICE, _CAP, _GRAS_TRAIT = "LMROMAN", 0.644, 0.012
except Exception:
    pass
MARGE_SURE = 6 * 72 / 25.4      # 6 mm
ECHELLE = min((PAGE_W - 2 * MARGE_SURE) / PAGE_W, (PAGE_H - 2 * MARGE_SURE) / PAGE_H)
DECAL_X = (PAGE_W - PAGE_W * ECHELLE) / 2.0
DECAL_Y = (PAGE_H - PAGE_H * ECHELLE) / 2.0

_IMG_W, _IMG_H = 1536.0, 1024.0
_IMG_FOND = _os.path.join(_ICI, "pow6_fond.png")

# centres (x, y) px des 6 cases (2 rangées de 3) ; serie = (x centre, ligne de base)
CARTONS = [
    {'grille': [[(101.5, 107.5), (215.0, 107.5), (328.5, 107.5)], [(101.5, 195.5), (215.0, 195.5), (328.5, 195.5)]], 'serie': (68.0, 55)},
    {'grille': [[(471.5, 107.5), (584.5, 107.5), (698.0, 107.5)], [(471.5, 195.5), (584.5, 195.5), (698.0, 195.5)]], 'serie': (438.0, 55)},
    {'grille': [[(838.5, 107.5), (952.0, 107.5), (1065.0, 107.5)], [(838.5, 195.5), (952.0, 195.5), (1065.0, 195.5)]], 'serie': (805.0, 55)},
    {'grille': [[(1207.5, 107.5), (1321.5, 107.5), (1435.0, 107.5)], [(1207.5, 195.5), (1321.5, 195.5), (1435.0, 195.5)]], 'serie': (1174.0, 55)},
    {'grille': [[(101.5, 361.5), (215.0, 361.5), (328.5, 361.5)], [(101.5, 449.5), (215.0, 449.5), (328.5, 449.5)]], 'serie': (68.0, 309)},
    {'grille': [[(471.5, 361.5), (584.5, 361.5), (698.0, 361.5)], [(471.5, 449.5), (584.5, 449.5), (698.0, 449.5)]], 'serie': (438.0, 309)},
    {'grille': [[(838.5, 361.5), (952.0, 361.5), (1065.0, 361.5)], [(838.5, 449.5), (952.0, 449.5), (1065.0, 449.5)]], 'serie': (805.0, 309)},
    {'grille': [[(1207.5, 361.5), (1321.5, 361.5), (1435.0, 361.5)], [(1207.5, 449.5), (1321.0, 449.5), (1435.0, 449.5)]], 'serie': (1174.0, 309)},
    {'grille': [[(101.5, 615.5), (215.0, 615.5), (328.5, 615.5)], [(101.5, 703.0), (215.0, 703.0), (328.5, 703.0)]], 'serie': (68.0, 563)},
    {'grille': [[(471.5, 615.5), (584.5, 615.5), (698.0, 615.5)], [(471.5, 703.0), (584.5, 703.0), (698.0, 703.0)]], 'serie': (438.0, 563)},
    {'grille': [[(838.5, 615.5), (952.0, 615.5), (1065.0, 615.5)], [(838.5, 703.0), (952.0, 703.0), (1065.0, 703.0)]], 'serie': (805.0, 563)},
    {'grille': [[(1207.5, 615.5), (1321.5, 615.5), (1435.0, 615.5)], [(1207.5, 703.0), (1321.5, 703.0), (1434.5, 703.0)]], 'serie': (1174.0, 563)},
    {'grille': [[(101.5, 869.5), (215.0, 869.5), (328.5, 869.5)], [(101.5, 957.0), (215.0, 957.0), (328.5, 957.0)]], 'serie': (68.0, 817)},
    {'grille': [[(471.5, 869.5), (584.5, 869.5), (698.0, 869.5)], [(471.5, 957.0), (584.5, 957.0), (698.0, 957.0)]], 'serie': (438.0, 817)},
    {'grille': [[(838.5, 869.5), (952.0, 869.5), (1065.0, 869.5)], [(838.5, 957.0), (952.0, 957.0), (1065.0, 957.0)]], 'serie': (805.0, 817)},
    {'grille': [[(1207.5, 869.5), (1321.5, 869.5), (1435.0, 869.5)], [(1207.5, 957.0), (1321.5, 957.0), (1434.5, 957.0)]], 'serie': (1174.0, 817)},
]

_EPAIS = 0.6


def _chiffre(c, x, y, txt, taille):
    txt = str(txt)
    w = c.stringWidth(txt, POLICE, taille)
    c.saveState()
    try:
        t = c.beginText()
        if _GRAS_TRAIT > 0:
            c.setStrokeColor(c._fillColorObj)
            c.setLineWidth(_GRAS_TRAIT * taille)
            c.setLineJoin(1)
            t.setTextRenderMode(2)
        else:
            t.setTextRenderMode(0)
        t.setFont(POLICE, taille)
        t.setTextOrigin(x - w / 2.0, y)
        t.textOut(txt)
        c.drawText(t)
    finally:
        c.restoreState()


def _px(x):
    return x / _IMG_W * PAGE_W


def _py(y):
    return PAGE_H * (1 - y / _IMG_H)


def _numeros(rng, deja=None):
    # 2 numéros différents par colonne, ordre libre (règle du 28/09)
    while True:
        cols = [rng.sample(range(a, b + 1), 2) for a, b in COLONNES]
        cle = tuple(v for col in cols for v in col)
        if deja is None or cle not in deja:
            if deja is not None:
                deja.add(cle)
            return cols


def generer_pdf(nb_cartes=None, nb_tickets=None, serie_start=1, theme="", couleur=True,
                nom_evenement="", titre_jeu="", couleur_perso="", date_lieu="",
                telephone="", page_start=1, evenement_id="", style="", motif="",
                _deja=None, **_ig):
    n_ = nb_cartes if nb_cartes is not None else nb_tickets
    n_ = max(1, int(n_ if n_ else CARTES_PAGE))
    buf = io.BytesIO()
    c = canvas.Canvas(buf, pagesize=(PAGE_W, PAGE_H), pageCompression=1)
    c.setTitle("POW 6 boules")
    rng = random.Random(int(serie_start) * 100003 + 6666)
    deja = _deja if _deja is not None else set()
    serie = int(serie_start)
    faits = 0
    try:
        no_page = max(1, int(page_start))
    except Exception:
        no_page = 1
    col_imposee = None
    if couleur and couleur_perso:
        try:
            col_imposee = colors.HexColor(couleur_perso)
        except Exception:
            col_imposee = None

    while faits < n_:
        c.saveState()
        c.translate(DECAL_X, DECAL_Y)
        c.scale(ECHELLE, ECHELLE)
        try:
            c.drawImage(_IMG_FOND, 0, 0, PAGE_W, PAGE_H, preserveAspectRatio=False, mask="auto")
        except Exception:
            pass
        entete = "  ·  ".join(t for t in ((nom_evenement or "").strip(),
                                          (date_lieu or "").strip(),
                                          (telephone or "").strip()) if t)
        if entete:
            c.setFillColor(_GRIS_ECO)
            c.setFont("Helvetica-Bold", 6)
            c.drawString(_px(40), PAGE_H - 7, entete)
        for idx in range(CARTES_PAGE):
            if faits >= n_:
                break
            ct = CARTONS[idx]
            col = (col_imposee or colors.HexColor(RAINBOW[serie % len(RAINBOW)])) if couleur else _GRIS_ECO
            cols = _numeros(rng, deja)
            c.setFillColor(col)
            dy = TAILLE * _CAP / 2.0
            for j in range(3):          # colonne
                for i in range(2):      # rangée
                    x, y = ct["grille"][i][j]
                    _chiffre(c, _px(x), _py(y) - dy, cols[j][i], TAILLE)
            sx, sy = ct["serie"]
            c.setFillColor(GRIS_TRAIT)
            c.setFont("Helvetica-Bold", 5.5)
            c.drawCentredString(_px(sx), _py(sy), "N° %06d" % serie)
            serie += 1
            faits += 1
        c.restoreState()
        # ⭐ 19/11 : n° de page (Maeva : « faut pas oublier nos numéros de page »),
        #    dans la marge de droite, en bas, là où la Konica imprime.
        c.setFillColor(GRIS_TRAIT)
        c.setFont("Helvetica", 6)
        c.drawRightString(PAGE_W - 13.5, 20, "%d" % no_page)
        no_page += 1
        c.showPage()
    c.save()
    buf.seek(0)
    return buf


if __name__ == "__main__":
    open("test_pow6.pdf", "wb").write(generer_pdf(nb_cartes=16, couleur=False).read())
    print("POW 6 genere")
