# -*- coding: utf-8 -*-
"""MANAPRINT — INO 8 boules (planche de Maeva, refait le 19/11/2026).
16 cartons par feuille A4 PAYSAGE. La planche est reprise TELLE QUELLE comme
fond (trait gris uni, sans aplat gris taché) ; on n'ajoute que les chiffres, le n° de
série et le n° de page.
Règle : I 16-30 (×3) · N 31-45 (×2, la case du centre reste vide) · O 61-75 (×3), triés. Crieur 16-45 et 61-75.
Chiffres Latin Modern GRAS, noirs, le plus gros que chaque case permet.
Feuille ramenée à 6 mm des bords (Konica)."""
import io, os as _os, random
from collections import Counter
from reportlab.pdfgen import canvas
from reportlab.lib.pagesizes import A4, landscape
from reportlab.lib import colors
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont

PAGE_W, PAGE_H = landscape(A4)
CARTES_PAGE = 16
PLAGES = {'I': (16, 30), 'N': (31, 45), 'O': (61, 75)}
NOIR = colors.Color(0.05, 0.05, 0.05)
GRIS_TRAIT = colors.Color(0.40, 0.40, 0.40)
RAINBOW = ["#E53935", "#FB8C00", "#F9A825", "#43A047", "#00ACC1",
           "#1E88E5", "#3949AB", "#8E24AA", "#D81B60", "#6D4C41"]
_ICI = _os.path.dirname(_os.path.abspath(__file__))
POLICE, _CAP = "Helvetica-Bold", 0.717
try:
    pdfmetrics.registerFont(TTFont("LMROMANB", _os.path.join(_ICI, "LatinModern-Bold.ttf")))
    POLICE, _CAP = "LMROMANB", 0.66
except Exception:
    pass
_IMG_W, _IMG_H = 1536.0, 1086.0
_IMG_FOND = _os.path.join(_ICI, "ino8_fond_v2.png")
MARGE_SURE = 6 * 72 / 25.4
ECHELLE = min((PAGE_W - 2 * MARGE_SURE) / PAGE_W, (PAGE_H - 2 * MARGE_SURE) / PAGE_H)
DECAL_X = (PAGE_W - PAGE_W * ECHELLE) / 2.0
DECAL_Y = (PAGE_H - PAGE_H * ECHELLE) / 2.0

# cases : (plage, (x0, y0, x1, y1) px), dans l'ordre où les numéros TRIÉS se posent ;
# serie = (alignement, x, ligne de base) px
CARTONS = [
    {'cells': [('I', (47, 88, 154, 147)), ('I', (47, 151, 154, 208)), ('I', (47, 212, 154, 272)), ('N', (159, 88, 265, 147)), ('N', (159, 212, 265, 272)), ('O', (269, 88, 378, 147)), ('O', (269, 151, 378, 208)), ('O', (269, 212, 378, 272))], 'serie': ('R', 374, 80)},
    {'cells': [('I', (419, 88, 526, 147)), ('I', (419, 151, 526, 208)), ('I', (419, 212, 526, 272)), ('N', (530, 88, 636, 147)), ('N', (530, 212, 636, 272)), ('O', (640, 88, 750, 147)), ('O', (640, 151, 750, 208)), ('O', (640, 212, 750, 272))], 'serie': ('R', 746, 80)},
    {'cells': [('I', (786, 88, 894, 147)), ('I', (786, 151, 894, 208)), ('I', (786, 212, 894, 272)), ('N', (898, 88, 1003, 147)), ('N', (898, 212, 1003, 272)), ('O', (1008, 88, 1117, 147)), ('O', (1008, 151, 1117, 208)), ('O', (1008, 212, 1117, 272))], 'serie': ('R', 1113, 80)},
    {'cells': [('I', (1157, 88, 1266, 147)), ('I', (1157, 151, 1266, 208)), ('I', (1157, 212, 1266, 272)), ('N', (1270, 88, 1377, 147)), ('N', (1270, 212, 1377, 272)), ('O', (1381, 88, 1489, 147)), ('O', (1381, 151, 1489, 208)), ('O', (1381, 212, 1489, 272))], 'serie': ('R', 1485, 80)},
    {'cells': [('I', (47, 341, 154, 399)), ('I', (47, 402, 154, 460)), ('I', (47, 464, 154, 525)), ('N', (159, 341, 265, 399)), ('N', (159, 464, 265, 525)), ('O', (269, 341, 378, 399)), ('O', (269, 402, 378, 460)), ('O', (269, 464, 378, 525))], 'serie': ('R', 374, 333)},
    {'cells': [('I', (419, 341, 526, 399)), ('I', (419, 402, 526, 460)), ('I', (419, 464, 526, 525)), ('N', (530, 341, 636, 399)), ('N', (530, 464, 636, 524)), ('O', (640, 341, 750, 399)), ('O', (640, 402, 750, 460)), ('O', (640, 464, 750, 524))], 'serie': ('R', 746, 333)},
    {'cells': [('I', (786, 341, 894, 399)), ('I', (786, 402, 894, 460)), ('I', (786, 464, 894, 524)), ('N', (898, 341, 1003, 399)), ('N', (898, 464, 1003, 524)), ('O', (1008, 341, 1117, 399)), ('O', (1008, 402, 1117, 460)), ('O', (1008, 464, 1117, 525))], 'serie': ('R', 1113, 333)},
    {'cells': [('I', (1157, 341, 1266, 399)), ('I', (1157, 402, 1266, 460)), ('I', (1157, 464, 1266, 525)), ('N', (1270, 341, 1377, 399)), ('N', (1270, 464, 1377, 525)), ('O', (1381, 341, 1489, 399)), ('O', (1381, 402, 1489, 460)), ('O', (1381, 464, 1489, 525))], 'serie': ('R', 1485, 333)},
    {'cells': [('I', (47, 593, 154, 651)), ('I', (47, 654, 154, 713)), ('I', (47, 716, 154, 777)), ('N', (159, 593, 265, 651)), ('N', (159, 716, 265, 777)), ('O', (269, 593, 378, 651)), ('O', (269, 654, 378, 713)), ('O', (269, 716, 378, 777))], 'serie': ('R', 374, 585)},
    {'cells': [('I', (419, 593, 526, 651)), ('I', (419, 654, 526, 713)), ('I', (419, 716, 526, 777)), ('N', (530, 593, 636, 651)), ('N', (530, 716, 636, 777)), ('O', (640, 593, 750, 651)), ('O', (640, 654, 750, 713)), ('O', (640, 716, 750, 777))], 'serie': ('R', 746, 585)},
    {'cells': [('I', (786, 593, 894, 651)), ('I', (786, 654, 894, 713)), ('I', (786, 716, 894, 777)), ('N', (898, 593, 1003, 651)), ('N', (898, 716, 1003, 777)), ('O', (1008, 593, 1117, 651)), ('O', (1008, 654, 1117, 713)), ('O', (1008, 716, 1117, 777))], 'serie': ('R', 1113, 585)},
    {'cells': [('I', (1157, 593, 1266, 651)), ('I', (1157, 654, 1266, 713)), ('I', (1157, 716, 1266, 777)), ('N', (1270, 593, 1377, 651)), ('N', (1270, 716, 1377, 777)), ('O', (1381, 593, 1489, 651)), ('O', (1381, 654, 1489, 713)), ('O', (1381, 716, 1489, 777))], 'serie': ('R', 1485, 585)},
    {'cells': [('I', (47, 844, 154, 901)), ('I', (47, 904, 154, 962)), ('I', (47, 966, 154, 1026)), ('N', (159, 844, 265, 901)), ('N', (159, 966, 265, 1026)), ('O', (269, 844, 378, 901)), ('O', (269, 904, 378, 962)), ('O', (269, 966, 378, 1026))], 'serie': ('R', 374, 836)},
    {'cells': [('I', (419, 844, 526, 901)), ('I', (419, 904, 526, 962)), ('I', (419, 966, 526, 1026)), ('N', (530, 844, 636, 901)), ('N', (530, 966, 636, 1026)), ('O', (640, 844, 750, 901)), ('O', (640, 904, 750, 962)), ('O', (640, 966, 750, 1026))], 'serie': ('R', 746, 836)},
    {'cells': [('I', (786, 844, 894, 901)), ('I', (786, 904, 894, 962)), ('I', (786, 966, 894, 1026)), ('N', (898, 844, 1003, 901)), ('N', (898, 966, 1003, 1026)), ('O', (1008, 844, 1117, 901)), ('O', (1008, 904, 1117, 962)), ('O', (1008, 966, 1117, 1026))], 'serie': ('R', 1113, 836)},
    {'cells': [('I', (1157, 844, 1266, 901)), ('I', (1157, 904, 1266, 962)), ('I', (1157, 966, 1266, 1026)), ('N', (1270, 844, 1377, 901)), ('N', (1270, 966, 1377, 1026)), ('O', (1381, 844, 1489, 901)), ('O', (1381, 904, 1489, 962)), ('O', (1381, 966, 1489, 1026))], 'serie': ('R', 1485, 836)},
]
AIR_H, AIR_W = 0.62, 0.78
COMPTE = Counter(p for p, _c in CARTONS[0]["cells"])


def _px(x):
    return x / _IMG_W * PAGE_W


def _py(y):
    return PAGE_H * (1 - y / _IMG_H)


def _t(c):
    x0, y0, x1, y1 = c
    w, h = _px(x1) - _px(x0), _px(y1) - _px(y0)
    return int(min(AIR_H * h / _CAP, AIR_W * w / (pdfmetrics.stringWidth("88", POLICE, 1.0) + 0.02)) * 2) / 2.0


TAILLE = min(_t(c) for ct in CARTONS for _p, c in ct["cells"])


def _tirage(rng, p, n):
    a, b = PLAGES[p]
    pool = list(range(a, b + 1, 2)) if (a % 2 == 0 and "PAIR" in "INO 8 boules") else list(range(a, b + 1))
    return sorted(rng.sample(pool, n))


def _numeros(rng, deja=None):
    while True:
        d = {p: _tirage(rng, p, n) for p, n in COMPTE.items()}
        cle = tuple((p, tuple(d[p])) for p in sorted(d))
        if deja is None or cle not in deja:
            if deja is not None:
                deja.add(cle)
            return d


def generer_pdf(nb_cartes=None, nb_tickets=None, serie_start=1, theme="", couleur=True,
                nom_evenement="", titre_jeu="", couleur_perso="", date_lieu="",
                telephone="", page_start=1, evenement_id="", style="", motif="",
                _deja=None, **_ig):
    n_ = nb_cartes if nb_cartes is not None else nb_tickets
    n_ = max(1, int(n_ if n_ else CARTES_PAGE))
    buf = io.BytesIO()
    c = canvas.Canvas(buf, pagesize=(PAGE_W, PAGE_H), pageCompression=1)
    c.setTitle("INO 8 boules")
    rng = random.Random(int(serie_start) * 100003 + 1645)
    deja = _deja if _deja is not None else set()
    serie = int(serie_start)
    faits = 0
    try:
        no_page = max(1, int(page_start))
    except Exception:
        no_page = 1
    col_imposee = None
    if couleur and couleur_perso:
        try:
            col_imposee = colors.HexColor(couleur_perso)
        except Exception:
            col_imposee = None
    while faits < n_:
        c.saveState()
        c.translate(DECAL_X, DECAL_Y)
        c.scale(ECHELLE, ECHELLE)
        try:
            c.drawImage(_IMG_FOND, 0, 0, PAGE_W, PAGE_H, preserveAspectRatio=False, mask="auto")
        except Exception:
            pass
        for idx in range(CARTES_PAGE):
            if faits >= n_:
                break
            ct = CARTONS[idx]
            col = (col_imposee or colors.HexColor(RAINBOW[serie % len(RAINBOW)])) if couleur else NOIR
            nums = _numeros(rng, deja)
            pos = {p: 0 for p in nums}
            c.saveState()
            c.setFillColor(col); c.setStrokeColor(col)
            c.setLineWidth(0.5); c.setLineJoin(1)
            for p, (x0, y0, x1, y1) in ct["cells"]:
                v = str(nums[p][pos[p]]); pos[p] += 1
                o = c.beginText(); o.setTextRenderMode(2); o.setFont(POLICE, TAILLE)
                o.setTextOrigin(_px((x0 + x1) / 2.0) - c.stringWidth(v, POLICE, TAILLE) / 2.0,
                                _py((y0 + y1) / 2.0) - TAILLE * _CAP / 2.0)
                o.textOut(v); c.drawText(o)
            c.restoreState()
            al, sx, sy = ct["serie"]
            c.setFillColor(GRIS_TRAIT)
            c.setFont("Helvetica-Bold", 4.5)
            txt = "N° %06d" % serie
            if al == "R":
                c.drawRightString(_px(sx), _py(sy), txt)
            elif al == "C":
                c.drawCentredString(_px(sx), _py(sy), txt)
            else:
                c.drawString(_px(sx), _py(sy), txt)
            serie += 1
            faits += 1
        c.restoreState()
        c.setFillColor(GRIS_TRAIT)
        c.setFont("Helvetica", 6)
        c.drawRightString(PAGE_W - 17, PAGE_H - 13, "%d" % no_page)
        no_page += 1
        c.showPage()
    c.save()
    buf.seek(0)
    return buf
