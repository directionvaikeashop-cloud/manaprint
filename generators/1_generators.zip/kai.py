# -*- coding: utf-8 -*-
"""MANAPRINT — KAI 7 boules (refait le 18/11/2026 sur la maquette de Maeva).
16 cartons par feuille A4 PAYSAGE. La maquette est reprise TELLE QUELLE comme
fond, en 2 tons francs (rendu propre sur la Konica) ; on n'ajoute que les
chiffres, le n° de série et le n° de page.
Règle : col 1 : 1-10 (2 numéros, case du bas barrée) · col 2 : 11-20 (3) · col 3 : 21-30 (2, case du haut barrée), le petit en haut. Crieur 1-30.
Chiffres en Latin Modern (écriture maison), NOIRS, le plus gros possible avec de l'air dans la case.
Feuille ramenée à 6 mm des bords (la Konica n'imprime pas les 4,2 mm du bord)."""
import io, os as _os, random
from reportlab.pdfgen import canvas
from reportlab.lib.pagesizes import A4, landscape
from reportlab.lib import colors

PAGE_W, PAGE_H = landscape(A4)
CARTES_PAGE = 16
PLAGES = [(1, 10), (11, 20), (21, 30)]
PAR_COLONNE = [2, 3, 2]
NOIR = colors.Color(0.08, 0.08, 0.08)
GRIS_TRAIT = colors.Color(0.40, 0.40, 0.40)
RAINBOW = ["#E53935", "#FB8C00", "#F9A825", "#43A047", "#00ACC1",
           "#1E88E5", "#3949AB", "#8E24AA", "#D81B60", "#6D4C41"]
POLICE, _CAP, _LARG88 = "Helvetica-Bold", 0.717, 1.112
# ⭐ 18/11 (Maeva : « ces jeux avaient déjà leurs propres écritures ») :
#    l'écriture maison des planches ÉCO = LATIN MODERN ROMAN (comme RAI, KEA, P6).
try:
    from reportlab.pdfbase import pdfmetrics as _pm
    from reportlab.pdfbase.ttfonts import TTFont as _TF
    import os as _o
    _pm.registerFont(_TF("LMROMAN", _o.path.join(_o.path.dirname(_o.path.abspath(__file__)), "LatinModern.ttf")))
    POLICE, _CAP, _LARG88 = "LMROMAN", 0.644, 1.0
except Exception:
    pass
_ICI = _os.path.dirname(_os.path.abspath(__file__))
_IMG_W, _IMG_H = 1536.0, 1086.0
_IMG_FOND = _os.path.join(_ICI, "kai_fond.png")
MARGE_SURE = 6 * 72 / 25.4
ECHELLE = min((PAGE_W - 2 * MARGE_SURE) / PAGE_W, (PAGE_H - 2 * MARGE_SURE) / PAGE_H)
DECAL_X = (PAGE_W - PAGE_W * ECHELLE) / 2.0
DECAL_Y = (PAGE_H - PAGE_H * ECHELLE) / 2.0

# pour chaque carton : les cases (x0, y0, x1, y1) px, colonne par colonne,
# de haut en bas ; serie = (x0, y0, x1, y1) px de la place du n° de série.
CARTONS = [
    {'cols': [[(58, 93, 164, 151), (58, 153, 164, 210)], [(167, 93, 272, 151), (167, 153, 272, 210), (167, 212, 272, 270)], [(275, 153, 379, 210), (275, 212, 379, 270)]], 'serie': (91, 65, 161, 80)},
    {'cols': [[(427, 93, 532, 151), (427, 153, 532, 209)], [(534, 93, 638, 151), (534, 153, 638, 209), (534, 212, 638, 270)], [(640, 153, 745, 209), (640, 212, 745, 270)]], 'serie': (460, 65, 530, 80)},
    {'cols': [[(794, 93, 899, 151), (794, 153, 899, 209)], [(902, 93, 1004, 151), (902, 153, 1004, 209), (902, 212, 1004, 270)], [(1007, 153, 1112, 209), (1007, 212, 1112, 270)]], 'serie': (827, 65, 897, 80)},
    {'cols': [[(1163, 93, 1268, 151), (1163, 153, 1268, 209)], [(1271, 93, 1374, 151), (1271, 153, 1374, 209), (1271, 212, 1374, 270)], [(1377, 153, 1482, 209), (1377, 212, 1482, 270)]], 'serie': (1196, 65, 1266, 80)},
    {'cols': [[(58, 347, 164, 405), (58, 407, 164, 464)], [(167, 347, 272, 405), (167, 407, 272, 464), (167, 466, 272, 524)], [(275, 407, 379, 464), (275, 466, 379, 524)]], 'serie': (91, 319, 161, 334)},
    {'cols': [[(427, 347, 532, 405), (427, 407, 532, 464)], [(534, 347, 638, 405), (534, 407, 637, 464), (534, 466, 638, 524)], [(640, 407, 745, 464), (640, 466, 745, 524)]], 'serie': (460, 319, 530, 334)},
    {'cols': [[(794, 347, 899, 405), (794, 407, 899, 463)], [(902, 347, 1004, 405), (902, 407, 1004, 463), (902, 466, 1004, 524)], [(1007, 407, 1112, 463), (1007, 466, 1112, 524)]], 'serie': (827, 319, 897, 334)},
    {'cols': [[(1163, 347, 1268, 405), (1163, 407, 1268, 464)], [(1271, 347, 1375, 405), (1271, 407, 1374, 464), (1271, 466, 1374, 524)], [(1377, 407, 1482, 464), (1377, 466, 1482, 524)]], 'serie': (1196, 319, 1266, 334)},
    {'cols': [[(58, 601, 164, 659), (58, 662, 164, 718)], [(167, 601, 272, 659), (167, 662, 272, 718), (167, 720, 272, 778)], [(275, 662, 379, 718), (275, 720, 379, 778)]], 'serie': (91, 573, 161, 588)},
    {'cols': [[(427, 601, 532, 659), (427, 662, 532, 718)], [(534, 601, 638, 659), (534, 661, 638, 718), (534, 720, 638, 778)], [(640, 662, 745, 718), (640, 720, 745, 778)]], 'serie': (460, 573, 530, 588)},
    {'cols': [[(794, 601, 899, 659), (794, 662, 899, 718)], [(902, 601, 1004, 659), (902, 662, 1004, 718), (902, 720, 1004, 778)], [(1007, 662, 1112, 718), (1007, 720, 1112, 777)]], 'serie': (827, 573, 897, 588)},
    {'cols': [[(1163, 601, 1268, 659), (1163, 662, 1268, 718)], [(1271, 601, 1375, 659), (1271, 662, 1374, 718), (1271, 720, 1374, 778)], [(1377, 662, 1482, 718), (1377, 720, 1482, 778)]], 'serie': (1196, 573, 1266, 588)},
    {'cols': [[(58, 853, 164, 911), (58, 913, 164, 969)], [(167, 853, 272, 911), (167, 913, 272, 969), (167, 972, 272, 1029)], [(275, 913, 379, 969), (275, 972, 379, 1029)]], 'serie': (91, 825, 161, 840)},
    {'cols': [[(427, 853, 532, 911), (427, 913, 532, 969)], [(534, 853, 638, 911), (534, 913, 638, 969), (534, 972, 638, 1029)], [(640, 913, 745, 969), (640, 972, 745, 1029)]], 'serie': (460, 825, 530, 840)},
    {'cols': [[(794, 852, 899, 910), (794, 912, 899, 969)], [(902, 852, 1004, 910), (902, 913, 1004, 969), (902, 971, 1004, 1028)], [(1007, 912, 1112, 969), (1007, 971, 1112, 1028)]], 'serie': (827, 824, 897, 839)},
    {'cols': [[(1163, 853, 1268, 911), (1163, 913, 1268, 969)], [(1271, 853, 1375, 911), (1271, 913, 1374, 969), (1271, 972, 1374, 1029)], [(1377, 913, 1482, 969), (1377, 972, 1482, 1029)]], 'serie': (1196, 825, 1266, 840)},
]
ALIGN_SERIE = "L"
AIR_H, AIR_W = 0.70, 0.80   # part de la case que « 88 » peut occuper


def _px(x):
    return x / _IMG_W * PAGE_W


def _py(y):
    return PAGE_H * (1 - y / _IMG_H)


def _taille_case(x0, y0, x1, y1):
    h = _px(y1) - _px(y0)
    w = _px(x1) - _px(x0)
    t = min(AIR_H * h / _CAP, AIR_W * w / _LARG88)
    return int(t * 2) / 2.0


# une taille par « famille » de cases (même hauteur), la plus petite de la famille
_TAILLES = {}
for _ct in CARTONS:
    for _col in _ct["cols"]:
        for _c in _col:
            _k = round((_c[3] - _c[1]) / 20.0)
            _TAILLES[_k] = min(_TAILLES.get(_k, 999), _taille_case(*_c))


def _taille(c):
    return _TAILLES[round((c[3] - c[1]) / 20.0)]


def _numeros(rng, deja=None):
    while True:
        d = [sorted(rng.sample(range(a, b + 1), n)) for (a, b), n in zip(PLAGES, PAR_COLONNE)]
        cle = tuple(v for p in d for v in p)
        if deja is None or cle not in deja:
            if deja is not None:
                deja.add(cle)
            return d


def _num(c, txt, x, y, t):
    o = c.beginText()
    o.setTextRenderMode(2)
    o.setFont(POLICE, t)
    o.setTextOrigin(x - c.stringWidth(txt, POLICE, t) / 2.0, y)
    o.textOut(txt)
    c.drawText(o)


def generer_pdf(nb_cartes=None, nb_tickets=None, serie_start=1, theme="", couleur=True,
                nom_evenement="", titre_jeu="", couleur_perso="", date_lieu="",
                telephone="", page_start=1, evenement_id="", style="", motif="",
                _deja=None, **_ig):
    n_ = nb_cartes if nb_cartes is not None else nb_tickets
    n_ = max(1, int(n_ if n_ else CARTES_PAGE))
    buf = io.BytesIO()
    c = canvas.Canvas(buf, pagesize=(PAGE_W, PAGE_H), pageCompression=1)
    c.setTitle("KAI 7 boules")
    rng = random.Random(int(serie_start) * 100003 + 2930)
    deja = _deja if _deja is not None else set()
    serie = int(serie_start)
    faits = 0
    try:
        no_page = max(1, int(page_start))
    except Exception:
        no_page = 1
    col_imposee = None
    if couleur and couleur_perso:
        try:
            col_imposee = colors.HexColor(couleur_perso)
        except Exception:
            col_imposee = None
    while faits < n_:
        c.saveState()
        c.translate(DECAL_X, DECAL_Y)
        c.scale(ECHELLE, ECHELLE)
        try:
            c.drawImage(_IMG_FOND, 0, 0, PAGE_W, PAGE_H, preserveAspectRatio=False, mask="auto")
        except Exception:
            pass
        entete = "  ·  ".join(t for t in ((nom_evenement or "").strip(),
                                          (date_lieu or "").strip(),
                                          (telephone or "").strip()) if t)
        for idx in range(CARTES_PAGE):
            if faits >= n_:
                break
            ct = CARTONS[idx]
            col = (col_imposee or colors.HexColor(RAINBOW[serie % len(RAINBOW)])) if couleur else NOIR
            nums = _numeros(rng, deja)
            c.saveState()
            c.setFillColor(col)
            c.setStrokeColor(col)
            c.setLineWidth(0.25)
            c.setLineJoin(1)
            for cases, vals in zip(ct["cols"], nums):
                for (x0, y0, x1, y1), v in zip(cases, vals):
                    t = _taille((x0, y0, x1, y1))
                    _num(c, str(v), _px((x0 + x1) / 2.0), _py((y0 + y1) / 2.0) - t * _CAP / 2.0, t)
            c.restoreState()
            sx0, sy0, sx1, sy1 = ct["serie"]
            ts = min(9.0, (_px(sy1) - _px(sy0)) / 0.72)
            c.setFillColor(GRIS_TRAIT)
            c.setFont("Helvetica-Bold", ts)
            if ALIGN_SERIE == "R":
                c.drawRightString(_px(sx1), _py(sy1), "%06d" % serie)
            else:
                c.drawString(_px(sx0), _py(sy1), "%06d" % serie)
            serie += 1
            faits += 1
        c.restoreState()
        # n° de page (et personnalisation) dans la marge que la Konica imprime
        c.setFillColor(GRIS_TRAIT)
        c.setFont("Helvetica", 6)
        c.drawRightString(PAGE_W - 13.5, 20, "%d" % no_page)
        if entete:
            c.setFont("Helvetica-Bold", 6.5)
            c.drawCentredString(PAGE_W / 2.0, PAGE_H - 13.5, entete)
        no_page += 1
        c.showPage()
    c.save()
    buf.seek(0)
    return buf


if __name__ == "__main__":
    open("test.pdf", "wb").write(generer_pdf(nb_cartes=CARTES_PAGE, couleur=False).read())
