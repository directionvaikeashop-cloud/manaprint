# -*- coding: utf-8 -*-
"""MANAPRINT — SALUTE 6 boules (refait le 20/11/2026 sur la feuille de Maeva,
cartes N° 960001 à 960008).

« Le pays de mon père » : la CORSE au centre (contour pâle, sans la tête de
Maure), un grand X en diagonales, le cartouche « SALUTE » sous l'île.
8 cartes par feuille A4 portrait (2 x 4), en-tête « 2KEA & Associé — Papeete ».
RÈGLE — six numéros :
   gauche               : 1-15
   haut-gauche / bas-gauche   : 16-30 (le plus petit en haut)
   haut-droite / bas-droite   : 46-60 (le plus petit en haut)
   droite               : 61-75
Crieur : 1-30 et 46-75 (le X ne couvre pas le 31-45).
Chiffres noirs, au maximum de la place (36 pt).
"""
import io, os as _os, random
from reportlab.pdfgen import canvas
from reportlab.lib.pagesizes import A4
from reportlab.lib import colors

PAGE_W, PAGE_H = A4
CARTES_PAGE = 8
NOIR = colors.Color(0.05, 0.05, 0.05)
GRIS = colors.Color(0.45, 0.45, 0.45)
GRIS_TRAIT = colors.Color(0.62, 0.62, 0.62)
RAINBOW = ["#E53935", "#FB8C00", "#F9A825", "#43A047", "#00ACC1",
           "#1E88E5", "#3949AB", "#8E24AA", "#D81B60", "#6D4C41"]
_ICI = _os.path.dirname(_os.path.abspath(__file__))
_CORSE = _os.path.join(_ICI, "salute_corse_v2.png")
TEL = "89 52 98 83"

MARGE = 6 * 72 / 25.4
ENTETE_H = 16.0
GOUT_X, GOUT_Y = 8.0, 5.0
CW = (PAGE_W - 2 * MARGE - GOUT_X) / 2.0
CH = min(CW / 1.427, (PAGE_H - 2 * MARGE - ENTETE_H - 3 * GOUT_Y) / 4.0)

POLICE, CAP = "Helvetica", 0.718
TAILLE = 36.0
# (plage, fx, fy depuis le haut de la carte) — l'ordre compte pour le tri
POSTES = [("G", 0.115, 0.561), ("HG", 0.268, 0.303), ("BG", 0.268, 0.829),
          ("HD", 0.682, 0.303), ("BD", 0.682, 0.829), ("D", 0.885, 0.561)]


def _tirage(rng):
    g = rng.randint(1, 15)
    hg, bg = sorted(rng.sample(range(16, 31), 2))
    hd, bd = sorted(rng.sample(range(46, 61), 2))
    d = rng.randint(61, 75)
    return {"G": g, "HG": hg, "BG": bg, "HD": hd, "BD": bd, "D": d}


def _carte(c, x0, y0, nums, serie, col):
    """x0, y0 = coin bas-gauche."""
    X = lambda f: x0 + f * CW
    Y = lambda f: y0 + CH * (1 - f)
    c.setStrokeColor(GRIS_TRAIT)
    c.setLineWidth(0.9)
    c.roundRect(x0, y0, CW, CH, 8, stroke=1, fill=0)
    c.setLineWidth(0.4)
    c.roundRect(x0 + 2.2, y0 + 2.2, CW - 4.4, CH - 4.4, 6.5, stroke=1, fill=0)
    # le X
    c.setLineWidth(0.6)
    for fx, fy in ((0.02, 0.06), (0.98, 0.06), (0.02, 0.95), (0.98, 0.95)):
        c.line(X(fx), Y(fy), X(0.5), Y(0.5))
    # une réserve blanche sous chaque numéro (le X s'interrompt)
    c.setFillColor(colors.white)
    for k, fx, fy in POSTES:
        w = c.stringWidth(str(nums[k]), POLICE, TAILLE) + 8
        h = TAILLE * CAP + 8
        c.rect(X(fx) - w / 2, Y(fy) - h / 2, w, h, stroke=0, fill=1)
    # la Corse
    ih = 0.551 * CH
    iw = ih * 142.0 / 250.0
    try:
        c.drawImage(_CORSE, X(0.5) - iw / 2, Y(0.218) - ih, iw, ih, mask="auto")
    except Exception:
        pass
    # le cartouche SALUTE
    c.setFillColor(colors.white)
    c.setStrokeColor(GRIS_TRAIT)
    c.setLineWidth(0.8)
    c.rect(X(0.35), Y(0.753), X(0.648) - X(0.35), Y(0.625) - Y(0.753), stroke=1, fill=1)
    c.saveState()
    t = c.beginText()
    t.setFont("Helvetica-Bold", 12)
    t.setCharSpace(3.2)
    lw = c.stringWidth("SALUTE", "Helvetica-Bold", 12) + 3.2 * 5
    t.setTextOrigin(X(0.499) - lw / 2, Y(0.689) - 12 * 0.36)
    c.setFillColor(GRIS)
    t.textOut("SALUTE")
    c.drawText(t)
    c.restoreState()
    # textes
    c.setFillColor(GRIS)
    c.setFont("Helvetica", 4.6)
    c.drawCentredString(X(0.5), Y(0.06), "SALUTE 6 boules  —  2KEA & Associé — Papeete   " + TEL)
    c.setFont("Helvetica", 6.5)
    c.drawCentredString(X(0.5), Y(0.12), "Carte N° %06d" % serie)
    c.setFont("Helvetica", 4.2)
    c.drawString(X(0.03), Y(0.965), "Tél : " + TEL)
    # les six numéros
    c.saveState()
    c.setFillColor(col)
    c.setStrokeColor(col)
    c.setLineWidth(TAILLE * 0.012)
    c.setLineJoin(1)
    for k, fx, fy in POSTES:
        s = str(nums[k])
        o = c.beginText()
        o.setTextRenderMode(2)
        o.setFont(POLICE, TAILLE)
        o.setTextOrigin(X(fx) - c.stringWidth(s, POLICE, TAILLE) / 2, Y(fy) - TAILLE * CAP / 2)
        o.textOut(s)
        c.drawText(o)
    c.restoreState()


def generer_pdf(nb_cartes=None, nb_tickets=None, serie_start=1, theme="", couleur=True,
                nom_evenement="", titre_jeu="", couleur_perso="", date_lieu="",
                telephone="", page_start=1, evenement_id="", style="", motif="",
                _deja=None, **_ig):
    n_ = nb_cartes if nb_cartes is not None else nb_tickets
    n_ = max(1, int(n_ if n_ else CARTES_PAGE))
    buf = io.BytesIO()
    c = canvas.Canvas(buf, pagesize=(PAGE_W, PAGE_H), pageCompression=1)
    c.setTitle("SALUTE 6 boules")
    rng = random.Random(int(serie_start) * 100003 + 965000)
    deja = _deja if _deja is not None else set()
    try:
        no_page = max(1, int(page_start))
    except Exception:
        no_page = 1
    serie = int(serie_start)
    faits = 0
    haut = PAGE_H - MARGE - ENTETE_H
    while faits < n_:
        c.setFillColor(colors.black)
        c.setFont("Helvetica", 9)
        c.drawCentredString(PAGE_W / 2, PAGE_H - MARGE - 8, "2KEA & Associé — Papeete")
        c.setFillColor(GRIS)
        c.setFont("Helvetica", 6)
        c.drawRightString(PAGE_W - MARGE, PAGE_H - MARGE - 8, "%03d" % no_page)
        for k in range(CARTES_PAGE):
            if faits >= n_:
                break
            r, col_ = divmod(k, 2)
            x0 = MARGE + col_ * (CW + GOUT_X)
            y0 = haut - (r + 1) * CH - r * GOUT_Y
            while True:
                nums = _tirage(rng)
                cle = tuple(nums[p[0]] for p in POSTES)
                if cle not in deja:
                    deja.add(cle)
                    break
            col = colors.HexColor(RAINBOW[serie % len(RAINBOW)]) if couleur else NOIR
            _carte(c, x0, y0, nums, serie, col)
            serie += 1
            faits += 1
        no_page += 1
        c.showPage()
    c.save()
    buf.seek(0)
    return buf


if __name__ == "__main__":
    open("test_salute.pdf", "wb").write(generer_pdf(nb_cartes=8, serie_start=960001, couleur=False).read())
    print("SALUTE genere")


# ⭐ 21/11 : les variantes spéciales restent celles d'avant (fichier salute_v1.py, inchangé)
def generer_pdf_smorfia(**kw):
    try:
        from generators import salute_v1 as _v1
    except Exception:
        import salute_v1 as _v1
    return _v1.generer_pdf_smorfia(**kw)

