# -*- coding: utf-8 -*-
"""MANAPRINT — LUNDI PAIR 74 (planche de Maeva, refait le 19/11/2026).
12 cartons par feuille A4 PORTRAIT. La planche est reprise TELLE QUELLE comme
fond (trait gris uni, sans aplat gris taché) ; on n'ajoute que les chiffres, le n° de
série et le n° de page.
Règle : 10 numéros PAIRS différents de 2 à 74, 5 par colonne, chaque colonne triée (le plus petit en haut), comme MARDI PAIR 90. Crieur : les 37 boules paires de 2 à 74.
Chiffres Latin Modern GRAS, noirs, le plus gros que chaque case permet.
Feuille ramenée à 6 mm des bords (Konica)."""
import io, os as _os, random
from collections import Counter
from reportlab.pdfgen import canvas
from reportlab.lib.pagesizes import A4, landscape
from reportlab.lib import colors
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont

PAGE_W, PAGE_H = A4
CARTES_PAGE = 12
PLAGES = {'P': (2, 74)}
NOIR = colors.Color(0.05, 0.05, 0.05)
GRIS_TRAIT = colors.Color(0.40, 0.40, 0.40)
RAINBOW = ["#E53935", "#FB8C00", "#F9A825", "#43A047", "#00ACC1",
           "#1E88E5", "#3949AB", "#8E24AA", "#D81B60", "#6D4C41"]
_ICI = _os.path.dirname(_os.path.abspath(__file__))
POLICE, _CAP = "Helvetica-Bold", 0.717
try:
    pdfmetrics.registerFont(TTFont("LMROMANB", _os.path.join(_ICI, "LatinModern-Bold.ttf")))
    POLICE, _CAP = "LMROMANB", 0.66
except Exception:
    pass
_IMG_W, _IMG_H = 1086.0, 1536.0
_IMG_FOND = _os.path.join(_ICI, "lundi_pair74_fond.png")
MARGE_SURE = 6 * 72 / 25.4
ECHELLE = min((PAGE_W - 2 * MARGE_SURE) / PAGE_W, (PAGE_H - 2 * MARGE_SURE) / PAGE_H)
DECAL_X = (PAGE_W - PAGE_W * ECHELLE) / 2.0
DECAL_Y = (PAGE_H - PAGE_H * ECHELLE) / 2.0

# cases : (plage, (x0, y0, x1, y1) px), dans l'ordre où les numéros TRIÉS se posent ;
# serie = (alignement, x, ligne de base) px
CARTONS = [
    {'cells': [('P', (72.8, 124.1, 129.1, 180.4)), ('P', (72.7, 186.3, 128.8, 242.4)), ('P', (72.9, 248.6, 128.9, 304.6)), ('P', (72.8, 311.0, 129.0, 367.1)), ('P', (72.5, 374.0, 129.2, 430.7)), ('P', (189.2, 124.1, 245.7, 180.5)), ('P', (189.2, 186.3, 245.6, 242.6)), ('P', (189.2, 248.4, 245.6, 304.8)), ('P', (189.1, 310.9, 245.6, 367.4)), ('P', (189.0, 373.8, 245.9, 430.7))], 'serie': ('C', 159.1, 443.7)},
    {'cells': [('P', (328.6, 124.1, 384.9, 180.4)), ('P', (328.7, 186.3, 384.7, 242.3)), ('P', (328.7, 248.6, 384.7, 304.6)), ('P', (328.6, 311.0, 384.8, 367.2)), ('P', (328.3, 373.9, 385.1, 430.6)), ('P', (444.7, 124.1, 501.1, 180.5)), ('P', (444.8, 186.4, 501.0, 242.6)), ('P', (444.9, 248.6, 501.1, 304.9)), ('P', (444.7, 310.9, 501.1, 367.3)), ('P', (444.6, 373.9, 501.4, 430.7))], 'serie': ('C', 414.8, 443.6)},
    {'cells': [('P', (584.2, 124.1, 640.5, 180.5)), ('P', (584.1, 186.3, 640.2, 242.4)), ('P', (584.2, 248.5, 640.4, 304.7)), ('P', (584.2, 310.9, 640.5, 367.2)), ('P', (583.8, 373.9, 640.6, 430.7)), ('P', (700.3, 124.0, 756.8, 180.6)), ('P', (700.3, 186.3, 756.7, 242.7)), ('P', (700.3, 248.5, 756.7, 304.9)), ('P', (700.3, 310.9, 756.7, 367.3)), ('P', (700.1, 373.8, 757.0, 430.7))], 'serie': ('C', 670.4, 443.7)},
    {'cells': [('P', (839.2, 124.0, 895.7, 180.5)), ('P', (839.5, 186.3, 895.6, 242.4)), ('P', (839.5, 248.6, 895.6, 304.7)), ('P', (839.4, 310.9, 895.7, 367.2)), ('P', (839.2, 373.9, 896.0, 430.7)), ('P', (955.6, 124.1, 1012.1, 180.6)), ('P', (955.7, 186.2, 1012.0, 242.5)), ('P', (955.7, 248.6, 1012.0, 304.9)), ('P', (955.6, 310.9, 1012.0, 367.4)), ('P', (955.4, 373.9, 1012.3, 430.8))], 'serie': ('C', 925.7, 443.7)},
    {'cells': [('P', (72.8, 632.4, 129.1, 688.6)), ('P', (72.6, 694.4, 129.1, 750.8)), ('P', (72.7, 757.0, 129.1, 813.4)), ('P', (72.7, 819.7, 129.1, 876.1)), ('P', (72.5, 882.9, 129.1, 939.5)), ('P', (189.2, 632.3, 245.6, 688.7)), ('P', (189.1, 694.4, 245.7, 751.0)), ('P', (189.0, 756.8, 245.6, 813.5)), ('P', (189.0, 819.6, 245.6, 876.2)), ('P', (189.0, 882.6, 245.8, 939.4))], 'serie': ('C', 159.1, 952.5)},
    {'cells': [('P', (328.5, 632.4, 384.8, 688.7)), ('P', (328.5, 694.5, 384.9, 750.9)), ('P', (328.4, 757.0, 384.8, 813.4)), ('P', (328.4, 819.7, 384.7, 876.1)), ('P', (328.3, 882.8, 385.0, 939.6)), ('P', (444.8, 632.4, 501.1, 688.7)), ('P', (444.5, 694.4, 501.1, 751.0)), ('P', (444.6, 757.0, 501.1, 813.5)), ('P', (444.6, 819.7, 501.1, 876.2)), ('P', (444.5, 882.8, 501.2, 939.5))], 'serie': ('C', 414.7, 952.6)},
    {'cells': [('P', (584.1, 632.3, 640.5, 688.7)), ('P', (584.0, 694.5, 640.5, 750.9)), ('P', (584.0, 756.9, 640.5, 813.4)), ('P', (584.0, 819.8, 640.5, 876.2)), ('P', (583.9, 882.9, 640.6, 939.6)), ('P', (700.3, 632.3, 756.8, 688.8)), ('P', (700.1, 694.3, 756.8, 751.0)), ('P', (700.2, 756.9, 756.8, 813.5)), ('P', (700.2, 819.5, 756.9, 876.2)), ('P', (700.1, 882.7, 757.0, 939.6))], 'serie': ('C', 670.4, 952.6)},
    {'cells': [('P', (839.4, 632.3, 895.6, 688.6)), ('P', (839.2, 694.4, 895.6, 750.9)), ('P', (839.4, 757.1, 895.7, 813.4)), ('P', (839.2, 819.7, 895.6, 876.1)), ('P', (839.1, 882.8, 895.9, 939.5)), ('P', (955.6, 632.4, 1012.1, 688.8)), ('P', (955.5, 694.4, 1012.1, 751.0)), ('P', (955.4, 756.9, 1012.0, 813.5)), ('P', (955.4, 819.6, 1012.0, 876.2)), ('P', (955.3, 882.7, 1012.1, 939.5))], 'serie': ('C', 925.6, 952.5)},
    {'cells': [('P', (72.7, 1136.5, 129.1, 1192.9)), ('P', (72.7, 1199.1, 129.0, 1255.5)), ('P', (72.6, 1262.4, 129.0, 1318.8)), ('P', (72.6, 1326.1, 129.1, 1382.6)), ('P', (72.1, 1390.8, 129.3, 1448.0)), ('P', (189.1, 1136.4, 245.8, 1193.0)), ('P', (189.0, 1199.0, 245.7, 1255.6)), ('P', (188.9, 1262.3, 245.7, 1319.0)), ('P', (188.9, 1326.0, 245.7, 1382.8)), ('P', (188.7, 1390.9, 245.9, 1448.1))], 'serie': ('C', 159.1, 1461.0)},
    {'cells': [('P', (328.5, 1136.7, 385.0, 1193.1)), ('P', (328.5, 1199.1, 384.9, 1255.5)), ('P', (328.3, 1262.4, 384.8, 1318.9)), ('P', (328.2, 1325.9, 384.9, 1382.6)), ('P', (328.0, 1390.9, 385.1, 1448.0)), ('P', (444.6, 1136.6, 501.2, 1193.2)), ('P', (444.6, 1199.0, 501.2, 1255.6)), ('P', (444.5, 1262.4, 501.1, 1319.0)), ('P', (444.5, 1326.1, 501.2, 1382.8)), ('P', (444.3, 1390.9, 501.4, 1448.0))], 'serie': ('C', 414.8, 1461.0)},
    {'cells': [('P', (584.0, 1136.7, 640.4, 1193.1)), ('P', (583.8, 1199.1, 640.4, 1255.7)), ('P', (583.9, 1262.4, 640.4, 1318.8)), ('P', (583.8, 1326.0, 640.4, 1382.7)), ('P', (583.6, 1391.0, 640.7, 1448.0)), ('P', (700.1, 1136.5, 756.9, 1193.2)), ('P', (700.1, 1199.0, 756.8, 1255.8)), ('P', (700.1, 1262.3, 756.8, 1319.0)), ('P', (700.0, 1325.9, 756.8, 1382.8)), ('P', (699.8, 1390.8, 757.1, 1448.1))], 'serie': ('C', 670.3, 1461.0)},
    {'cells': [('P', (839.3, 1136.6, 895.9, 1193.1)), ('P', (839.2, 1199.1, 895.8, 1255.6)), ('P', (839.3, 1262.4, 895.8, 1319.0)), ('P', (839.1, 1326.0, 895.8, 1382.7)), ('P', (838.9, 1390.9, 896.1, 1448.0)), ('P', (955.5, 1136.6, 1012.1, 1193.3)), ('P', (955.6, 1199.2, 1012.3, 1255.8)), ('P', (955.4, 1262.3, 1012.2, 1319.1)), ('P', (955.6, 1326.1, 1012.3, 1382.9)), ('P', (955.1, 1390.8, 1012.4, 1448.1))], 'serie': ('C', 925.7, 1461.0)},
]
AIR_H, AIR_W = 0.62, 0.78
COMPTE = Counter(p for p, _c in CARTONS[0]["cells"])


def _px(x):
    return x / _IMG_W * PAGE_W


def _py(y):
    return PAGE_H * (1 - y / _IMG_H)


def _t(c):
    x0, y0, x1, y1 = c
    w, h = _px(x1) - _px(x0), _px(y1) - _px(y0)
    return int(min(AIR_H * h / _CAP, AIR_W * w / (pdfmetrics.stringWidth("88", POLICE, 1.0) + 0.02)) * 2) / 2.0


TAILLE = min(_t(c) for ct in CARTONS for _p, c in ct["cells"])
TAILLE = 21.0   # ⭐ grossi au maximum, avec un liseré d air dans le rond (Konica)


def _tirage(rng, p, n):
    a, b = PLAGES[p]
    pool = list(range(a, b + 1, 2)) if (a % 2 == 0 and "PAIR" in "LUNDI PAIR 74") else list(range(a, b + 1))
    return sorted(rng.sample(pool, n))


def _numeros(rng, deja=None):
    """10 pairs différents, 5 par colonne, chaque colonne triée (comme MARDI PAIR 90)."""
    a, b = PLAGES["P"]
    pool = list(range(a, b + 1, 2))
    while True:
        t = rng.sample(pool, 10)
        cle = tuple(sorted(t))
        if deja is None or cle not in deja:
            if deja is not None:
                deja.add(cle)
            return {"P": sorted(t[:5]) + sorted(t[5:])}


def generer_pdf(nb_cartes=None, nb_tickets=None, serie_start=1, theme="", couleur=True,
                nom_evenement="", titre_jeu="", couleur_perso="", date_lieu="",
                telephone="", page_start=1, evenement_id="", style="", motif="",
                _deja=None, **_ig):
    n_ = nb_cartes if nb_cartes is not None else nb_tickets
    n_ = max(1, int(n_ if n_ else CARTES_PAGE))
    buf = io.BytesIO()
    c = canvas.Canvas(buf, pagesize=(PAGE_W, PAGE_H), pageCompression=1)
    c.setTitle("LUNDI PAIR 74")
    rng = random.Random(int(serie_start) * 100003 + 7402)
    deja = _deja if _deja is not None else set()
    serie = int(serie_start)
    faits = 0
    try:
        no_page = max(1, int(page_start))
    except Exception:
        no_page = 1
    col_imposee = None
    if couleur and couleur_perso:
        try:
            col_imposee = colors.HexColor(couleur_perso)
        except Exception:
            col_imposee = None
    while faits < n_:
        c.saveState()
        c.translate(DECAL_X, DECAL_Y)
        c.scale(ECHELLE, ECHELLE)
        try:
            c.drawImage(_IMG_FOND, 0, 0, PAGE_W, PAGE_H, preserveAspectRatio=False, mask="auto")
        except Exception:
            pass
        for idx in range(CARTES_PAGE):
            if faits >= n_:
                break
            ct = CARTONS[idx]
            col = (col_imposee or colors.HexColor(RAINBOW[serie % len(RAINBOW)])) if couleur else NOIR
            nums = _numeros(rng, deja)
            pos = {p: 0 for p in nums}
            c.saveState()
            c.setFillColor(col); c.setStrokeColor(col)
            c.setLineWidth(0.5); c.setLineJoin(1)
            for p, (x0, y0, x1, y1) in ct["cells"]:
                v = str(nums[p][pos[p]]); pos[p] += 1
                o = c.beginText(); o.setTextRenderMode(2); o.setFont(POLICE, TAILLE)
                o.setTextOrigin(_px((x0 + x1) / 2.0) - c.stringWidth(v, POLICE, TAILLE) / 2.0,
                                _py((y0 + y1) / 2.0) - TAILLE * _CAP / 2.0)
                o.textOut(v); c.drawText(o)
            c.restoreState()
            al, sx, sy = ct["serie"]
            c.setFillColor(GRIS_TRAIT)
            c.setFont("Helvetica-Bold", 5)
            txt = "N° %06d" % serie
            if al == "R":
                c.drawRightString(_px(sx), _py(sy), txt)
            elif al == "C":
                c.drawCentredString(_px(sx), _py(sy), txt)
            else:
                c.drawString(_px(sx), _py(sy), txt)
            serie += 1
            faits += 1
        c.restoreState()
        c.setFillColor(GRIS_TRAIT)
        c.setFont("Helvetica", 6)
        c.drawRightString(PAGE_W - 17, PAGE_H - 13, "%d" % no_page)
        no_page += 1
        c.showPage()
    c.save()
    buf.seek(0)
    return buf
