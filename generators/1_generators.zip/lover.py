# -*- coding: utf-8 -*-
"""MANAPRINT — LOVER (planche de Maeva, refait le 19/11/2026).
12 cartons par feuille A4 PORTRAIT. La planche est reprise TELLE QUELLE comme fond
(trait gris uni, sans aplat gris taché) ; on n'ajoute que les chiffres, le n° de
série et le n° de page.
Règle : L 1-15 (haut) · O 16-30 (bas) · V 31-45 (haut) · E 46-60 (bas) · R 61-75 (haut). Crieur 1-75.
Chiffres Latin Modern GRAS, noirs, le plus gros que chaque case permet.
Feuille ramenée à 6 mm des bords (Konica)."""
import io, os as _os, random
from collections import Counter
from reportlab.pdfgen import canvas
from reportlab.lib.pagesizes import A4, landscape
from reportlab.lib import colors
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont

PAGE_W, PAGE_H = A4
CARTES_PAGE = 12
PLAGES = {'L': (1, 15), 'O': (16, 30), 'V': (31, 45), 'E': (46, 60), 'R': (61, 75)}
NOIR = colors.Color(0.05, 0.05, 0.05)
GRIS_TRAIT = colors.Color(0.40, 0.40, 0.40)
RAINBOW = ["#E53935", "#FB8C00", "#F9A825", "#43A047", "#00ACC1",
           "#1E88E5", "#3949AB", "#8E24AA", "#D81B60", "#6D4C41"]
_ICI = _os.path.dirname(_os.path.abspath(__file__))
POLICE, _CAP = "Helvetica-Bold", 0.717
try:
    pdfmetrics.registerFont(TTFont("LMROMANB", _os.path.join(_ICI, "LatinModern-Bold.ttf")))
    POLICE, _CAP = "LMROMANB", 0.66
except Exception:
    pass
_IMG_W, _IMG_H = 1489.0, 2106.0
_IMG_FOND = _os.path.join(_ICI, "lover_fond_v2.png")
MARGE_SURE = 6 * 72 / 25.4
ECHELLE = min((PAGE_W - 2 * MARGE_SURE) / PAGE_W, (PAGE_H - 2 * MARGE_SURE) / PAGE_H)
DECAL_X = (PAGE_W - PAGE_W * ECHELLE) / 2.0
DECAL_Y = (PAGE_H - PAGE_H * ECHELLE) / 2.0

# cases : (plage, (x0, y0, x1, y1) px), dans l'ordre où les numéros triés se posent ;
# serie = (alignement, x, ligne de base) px
CARTONS = [
    {'cells': [('L', (81, 126, 201, 240)), ('O', (208, 245, 327, 359)), ('V', (334, 126, 454, 240)), ('E', (461, 245, 581, 359)), ('R', (588, 126, 707, 240))], 'serie': ('L', 83, 373)},
    {'cells': [('L', (783, 126, 903, 240)), ('O', (910, 245, 1029, 359)), ('V', (1036, 126, 1156, 240)), ('E', (1163, 245, 1283, 359)), ('R', (1290, 126, 1409, 240))], 'serie': ('L', 785, 373)},
    {'cells': [('L', (82, 455, 202, 569)), ('O', (209, 574, 328, 688)), ('V', (335, 455, 455, 569)), ('E', (462, 574, 582, 688)), ('R', (589, 455, 708, 569))], 'serie': ('L', 84, 702)},
    {'cells': [('L', (784, 455, 904, 569)), ('O', (911, 574, 1030, 688)), ('V', (1037, 455, 1157, 569)), ('E', (1164, 574, 1284, 688)), ('R', (1291, 455, 1410, 569))], 'serie': ('L', 786, 702)},
    {'cells': [('L', (81, 785, 201, 899)), ('O', (208, 904, 327, 1018)), ('V', (334, 785, 454, 899)), ('E', (461, 904, 581, 1018)), ('R', (588, 785, 707, 899))], 'serie': ('L', 83, 1032)},
    {'cells': [('L', (783, 785, 903, 899)), ('O', (910, 904, 1029, 1018)), ('V', (1036, 785, 1156, 899)), ('E', (1163, 904, 1283, 1018)), ('R', (1290, 785, 1409, 899))], 'serie': ('L', 785, 1032)},
    {'cells': [('L', (81, 1114, 201, 1228)), ('O', (208, 1233, 327, 1347)), ('V', (334, 1114, 454, 1228)), ('E', (461, 1233, 581, 1347)), ('R', (588, 1114, 707, 1228))], 'serie': ('L', 83, 1361)},
    {'cells': [('L', (783, 1114, 903, 1228)), ('O', (910, 1233, 1029, 1347)), ('V', (1036, 1114, 1156, 1228)), ('E', (1163, 1233, 1283, 1347)), ('R', (1290, 1114, 1409, 1228))], 'serie': ('L', 785, 1361)},
    {'cells': [('L', (81, 1444, 201, 1558)), ('O', (208, 1563, 327, 1677)), ('V', (334, 1444, 454, 1558)), ('E', (461, 1563, 581, 1677)), ('R', (588, 1444, 707, 1558))], 'serie': ('L', 83, 1691)},
    {'cells': [('L', (783, 1444, 903, 1558)), ('O', (910, 1563, 1029, 1677)), ('V', (1036, 1444, 1156, 1558)), ('E', (1163, 1563, 1283, 1677)), ('R', (1290, 1444, 1409, 1558))], 'serie': ('L', 785, 1691)},
    {'cells': [('L', (81, 1774, 201, 1888)), ('O', (208, 1893, 327, 2007)), ('V', (334, 1774, 454, 1888)), ('E', (461, 1893, 581, 2007)), ('R', (588, 1774, 707, 1888))], 'serie': ('L', 83, 2021)},
    {'cells': [('L', (783, 1774, 903, 1888)), ('O', (910, 1893, 1029, 2007)), ('V', (1036, 1774, 1156, 1888)), ('E', (1163, 1893, 1283, 2007)), ('R', (1290, 1774, 1409, 1888))], 'serie': ('L', 785, 2021)},
]
AIR_H, AIR_W = 0.62, 0.78
COMPTE = Counter(pl for pl, _c in CARTONS[0]["cells"])


def _px(x):
    return x / _IMG_W * PAGE_W


def _py(y):
    return PAGE_H * (1 - y / _IMG_H)


def _t(c):
    x0, y0, x1, y1 = c
    w, h = _px(x1) - _px(x0), _px(y1) - _px(y0)
    return int(min(AIR_H * h / _CAP, AIR_W * w / (pdfmetrics.stringWidth("88", POLICE, 1.0) + 0.02)) * 2) / 2.0


TAILLE = min(_t(c) for ct in CARTONS for _p, c in ct["cells"])


def _numeros(rng, deja=None):
    while True:
        d = {pl: sorted(rng.sample(range(PLAGES[pl][0], PLAGES[pl][1] + 1), n)) for pl, n in COMPTE.items()}
        cle = tuple((pl, tuple(d[pl])) for pl in sorted(d))
        if deja is None or cle not in deja:
            if deja is not None:
                deja.add(cle)
            return d


def generer_pdf(nb_cartes=None, nb_tickets=None, serie_start=1, theme="", couleur=True,
                nom_evenement="", titre_jeu="", couleur_perso="", date_lieu="",
                telephone="", page_start=1, evenement_id="", style="", motif="",
                _deja=None, **_ig):
    n_ = nb_cartes if nb_cartes is not None else nb_tickets
    n_ = max(1, int(n_ if n_ else CARTES_PAGE))
    buf = io.BytesIO()
    c = canvas.Canvas(buf, pagesize=(PAGE_W, PAGE_H), pageCompression=1)
    c.setTitle("LOVER")
    rng = random.Random(int(serie_start) * 100003 + 7575)
    deja = _deja if _deja is not None else set()
    serie = int(serie_start)
    faits = 0
    try:
        no_page = max(1, int(page_start))
    except Exception:
        no_page = 1
    col_imposee = None
    if couleur and couleur_perso:
        try:
            col_imposee = colors.HexColor(couleur_perso)
        except Exception:
            col_imposee = None
    while faits < n_:
        c.saveState()
        c.translate(DECAL_X, DECAL_Y)
        c.scale(ECHELLE, ECHELLE)
        try:
            c.drawImage(_IMG_FOND, 0, 0, PAGE_W, PAGE_H, preserveAspectRatio=False, mask="auto")
        except Exception:
            pass
        for idx in range(CARTES_PAGE):
            if faits >= n_:
                break
            ct = CARTONS[idx]
            col = (col_imposee or colors.HexColor(RAINBOW[serie % len(RAINBOW)])) if couleur else NOIR
            nums = _numeros(rng, deja)
            pos = {pl: 0 for pl in nums}
            c.saveState()
            c.setFillColor(col); c.setStrokeColor(col)
            c.setLineWidth(0.5); c.setLineJoin(1)
            for pl, (x0, y0, x1, y1) in ct["cells"]:
                v = str(nums[pl][pos[pl]]); pos[pl] += 1
                o = c.beginText(); o.setTextRenderMode(2); o.setFont(POLICE, TAILLE)
                o.setTextOrigin(_px((x0 + x1) / 2.0) - c.stringWidth(v, POLICE, TAILLE) / 2.0,
                                _py((y0 + y1) / 2.0) - TAILLE * _CAP / 2.0)
                o.textOut(v); c.drawText(o)
            c.restoreState()
            al, sx, sy = ct["serie"]
            c.setFillColor(GRIS_TRAIT)
            c.setFont("Helvetica-Bold", 7 if al == "L" and False else 5.5)
            txt = ("%06d" if False else "N° %06d") % serie
            if al == "R":
                c.drawRightString(_px(sx), _py(sy), txt)
            else:
                c.drawString(_px(sx), _py(sy), txt)
            serie += 1
            faits += 1
        c.restoreState()
        c.setFillColor(GRIS_TRAIT)
        c.setFont("Helvetica", 6)
        c.drawRightString(PAGE_W - 17, PAGE_H - 13, "%d" % no_page)
        no_page += 1
        c.showPage()
    c.save()
    buf.seek(0)
    return buf
