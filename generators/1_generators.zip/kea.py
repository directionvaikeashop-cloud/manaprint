# -*- coding: utf-8 -*-
"""MANAPRINT — KEA (planche de Maeva du 28/09, 16 cartons / A4 PAYSAGE).
La planche est reprise TELLE QUELLE comme fond (traits passés en gris) ;
la croix de la case du centre est RETIRÉE (sceau Maeva 28/09 : « retire la croix »).
On n'ajoute que les chiffres et le n° de série.
9 numéros par carton, grille 3 x 3, le plus petit en haut de chaque colonne :
   K : 35-45 · E : 46-56 · A : 57-67 -> crieur 35 à 67.
Version refaite le 18/11/2026 (chiffres Latin Modern, l'écriture d'origine)."""
import io, os as _os, random
from reportlab.pdfgen import canvas
from reportlab.lib.pagesizes import A4, landscape
from reportlab.lib import colors
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont

PAGE_W, PAGE_H = landscape(A4)
CARTES_PAGE = 16
# niveau B choisi par Maeva le 28/09 pour KEA : chiffres gris 0,40
_GRIS_ECO = colors.Color(0.40, 0.40, 0.40)
GRIS_TRAIT = colors.Color(105 / 255.0, 105 / 255.0, 105 / 255.0)
RAINBOW = ["#E53935", "#FB8C00", "#F9A825", "#43A047", "#00ACC1",
           "#1E88E5", "#3949AB", "#8E24AA", "#D81B60", "#6D4C41"]
COLONNES = [(35, 45), (46, 56), (57, 67)]

_ICI = _os.path.dirname(_os.path.abspath(__file__))
# ⭐ 18/11 (Maeva : « je veux l'original ») : l'écriture d'origine des jeux
#    ÉCO de la maison (POW, RAI, KEA…) = LATIN MODERN ROMAN, gris 0,40,
#    gras léger 0,012. Helvetica-Bold en secours si le fichier manque.
# ⭐ 18/11 (Maeva : « à l'impression sur les Konica 458C ça déborde un peu
#    les grilles ») : chiffres à ~65 % de la hauteur de case (de l'air tout
#    autour, même quand le toner s'étale) + planche ramenée dans une marge
#    de 6 mm (la Konica ne peut pas imprimer les 4,2 mm du bord).
POLICE, _CAP, TAILLE = "Helvetica-Bold", 0.717, 30.0
_GRAS_TRAIT = 0.0
try:
    pdfmetrics.registerFont(TTFont("LMROMAN", _os.path.join(_ICI, "LatinModern.ttf")))
    POLICE, _CAP, _GRAS_TRAIT = "LMROMAN", 0.644, 0.012
    # ⭐ 18/11 (Maeva : « je veux que ça soit bien gras les chiffres sur KEA ») :
    #    la même écriture en GRAS (Latin Modern Roman Bold), + un léger trait.
    pdfmetrics.registerFont(TTFont("LMROMANB", _os.path.join(_ICI, "LatinModern-Bold.ttf")))
    POLICE, _CAP, _GRAS_TRAIT = "LMROMANB", 0.644, 0.02
except Exception:
    pass
MARGE_SURE = 6 * 72 / 25.4      # 6 mm
ECHELLE = min((PAGE_W - 2 * MARGE_SURE) / PAGE_W, (PAGE_H - 2 * MARGE_SURE) / PAGE_H)
DECAL_X = (PAGE_W - PAGE_W * ECHELLE) / 2.0
DECAL_Y = (PAGE_H - PAGE_H * ECHELLE) / 2.0

_IMG_W, _IMG_H = 1536.0, 1024.0
_IMG_FOND = _os.path.join(_ICI, "kea_fond.png")

# centres (x, y) px des 9 cases (3 rangées de 3) ; serie = (x centre, ligne de base)
CARTONS = [
    {'grille': [[(104.0, 87.5), (212.0, 87.5), (320.0, 87.5)], [(104.0, 150.5), (212.0, 150.5), (320.0, 150.5)], [(104.0, 214.5), (212.0, 214.5), (320.0, 215.0)]], 'serie': (72.0, 48)},
    {'grille': [[(474.0, 87.5), (582.0, 87.5), (690.0, 87.5)], [(474.0, 151.0), (582.0, 151.0), (690.0, 150.5)], [(474.0, 215.0), (582.0, 215.0), (690.0, 215.0)]], 'serie': (442.0, 48)},
    {'grille': [[(846.0, 87.5), (954.0, 87.5), (1062.0, 87.5)], [(846.0, 151.0), (954.0, 151.0), (1062.0, 151.0)], [(846.0, 215.0), (954.0, 215.0), (1062.0, 215.0)]], 'serie': (814.0, 48)},
    {'grille': [[(1216.5, 87.5), (1325.0, 87.5), (1433.0, 87.5)], [(1217.0, 151.0), (1325.0, 151.0), (1433.0, 150.5)], [(1217.0, 215.0), (1325.0, 215.0), (1433.0, 215.0)]], 'serie': (1185.0, 48)},
    {'grille': [[(104.0, 341.5), (212.0, 341.5), (320.0, 341.5)], [(104.0, 404.5), (212.0, 404.5), (320.5, 405.0)], [(104.0, 468.5), (212.0, 469.0), (320.0, 469.5)]], 'serie': (72.0, 302)},
    {'grille': [[(474.0, 341.5), (582.0, 341.5), (690.0, 341.5)], [(474.0, 405.0), (582.0, 405.0), (690.0, 405.0)], [(474.0, 469.5), (582.0, 469.5), (690.0, 469.5)]], 'serie': (442.0, 302)},
    {'grille': [[(846.0, 341.5), (954.0, 341.5), (1062.0, 341.5)], [(846.0, 405.5), (954.0, 405.5), (1062.0, 405.0)], [(846.0, 469.5), (954.0, 469.5), (1062.0, 469.5)]], 'serie': (814.0, 302)},
    {'grille': [[(1217.0, 341.5), (1325.0, 341.5), (1433.0, 341.5)], [(1217.0, 405.5), (1325.0, 405.5), (1433.0, 405.0)], [(1217.0, 469.5), (1325.0, 469.5), (1433.0, 469.5)]], 'serie': (1185.0, 302)},
    {'grille': [[(104.0, 595.5), (212.0, 595.0), (320.0, 595.5)], [(104.0, 658.5), (212.0, 658.5), (320.0, 658.5)], [(104.0, 719.5), (212.0, 719.5), (320.0, 720.0)]], 'serie': (72.0, 556)},
    {'grille': [[(474.0, 595.5), (582.0, 595.0), (690.0, 595.5)], [(474.0, 658.5), (582.0, 658.5), (690.0, 658.5)], [(474.0, 720.0), (582.0, 720.0), (690.0, 720.0)]], 'serie': (442.0, 556)},
    {'grille': [[(846.0, 595.5), (954.0, 595.5), (1062.0, 595.5)], [(846.0, 658.5), (954.0, 658.5), (1062.0, 658.5)], [(846.0, 720.5), (954.0, 720.5), (1062.0, 720.5)]], 'serie': (814.0, 556)},
    {'grille': [[(1217.5, 595.5), (1325.0, 595.0), (1433.0, 595.5)], [(1217.5, 658.5), (1325.0, 658.5), (1433.0, 658.5)], [(1217.0, 720.5), (1325.0, 720.5), (1433.0, 721.0)]], 'serie': (1185.0, 556)},
    {'grille': [[(104.0, 843.5), (212.0, 843.5), (320.0, 843.5)], [(104.0, 906.5), (212.0, 906.5), (320.0, 907.0)], [(104.0, 969.0), (212.0, 969.0), (320.0, 969.0)]], 'serie': (72.0, 804)},
    {'grille': [[(474.0, 843.5), (582.0, 843.5), (690.0, 843.5)], [(474.0, 906.5), (582.0, 906.5), (690.0, 907.0)], [(474.0, 969.0), (582.0, 969.0), (690.0, 969.0)]], 'serie': (442.0, 804)},
    {'grille': [[(846.0, 844.0), (954.0, 843.5), (1062.0, 843.5)], [(846.0, 907.0), (954.0, 907.0), (1062.0, 907.0)], [(846.0, 969.0), (954.0, 969.0), (1062.0, 969.0)]], 'serie': (814.0, 804)},
    {'grille': [[(1217.0, 844.5), (1325.0, 844.5), (1433.0, 844.5)], [(1217.0, 907.0), (1325.0, 907.0), (1433.0, 907.0)], [(1217.0, 969.5), (1325.0, 969.5), (1433.0, 969.5)]], 'serie': (1185.0, 805)},
]

_EPAIS = 0.6


def _chiffre(c, x, y, txt, taille):
    txt = str(txt)
    w = c.stringWidth(txt, POLICE, taille)
    c.saveState()
    try:
        t = c.beginText()
        if _GRAS_TRAIT > 0:
            c.setStrokeColor(c._fillColorObj)
            c.setLineWidth(_GRAS_TRAIT * taille)
            c.setLineJoin(1)
            t.setTextRenderMode(2)
        else:
            t.setTextRenderMode(0)
        t.setFont(POLICE, taille)
        t.setTextOrigin(x - w / 2.0, y)
        t.textOut(txt)
        c.drawText(t)
    finally:
        c.restoreState()


def _px(x):
    return x / _IMG_W * PAGE_W


def _py(y):
    return PAGE_H * (1 - y / _IMG_H)


def _numeros(rng, deja=None):
    # 3 numéros par colonne, triés : le plus petit en haut
    while True:
        cols = [sorted(rng.sample(range(a, b + 1), 3)) for a, b in COLONNES]
        cle = tuple(v for col in cols for v in col)
        if deja is None or cle not in deja:
            if deja is not None:
                deja.add(cle)
            return cols


def generer_pdf(nb_cartes=None, nb_tickets=None, serie_start=1, theme="", couleur=True,
                nom_evenement="", titre_jeu="", couleur_perso="", date_lieu="",
                telephone="", page_start=1, evenement_id="", style="", motif="",
                _deja=None, **_ig):
    n_ = nb_cartes if nb_cartes is not None else nb_tickets
    n_ = max(1, int(n_ if n_ else CARTES_PAGE))
    buf = io.BytesIO()
    c = canvas.Canvas(buf, pagesize=(PAGE_W, PAGE_H), pageCompression=1)
    c.setTitle("KEA")
    rng = random.Random(int(serie_start) * 100003 + 3535)
    deja = _deja if _deja is not None else set()
    serie = int(serie_start)
    faits = 0
    try:
        no_page = max(1, int(page_start))
    except Exception:
        no_page = 1
    col_imposee = None
    if couleur and couleur_perso:
        try:
            col_imposee = colors.HexColor(couleur_perso)
        except Exception:
            col_imposee = None

    while faits < n_:
        c.saveState()
        c.translate(DECAL_X, DECAL_Y)
        c.scale(ECHELLE, ECHELLE)
        try:
            c.drawImage(_IMG_FOND, 0, 0, PAGE_W, PAGE_H, preserveAspectRatio=False, mask="auto")
        except Exception:
            pass
        entete = "  ·  ".join(t for t in ((nom_evenement or "").strip(),
                                          (date_lieu or "").strip(),
                                          (telephone or "").strip()) if t)
        if entete:
            c.setFillColor(_GRIS_ECO)
            c.setFont("Helvetica-Bold", 6)
            c.drawString(_px(40), PAGE_H - 7, entete)
        for idx in range(CARTES_PAGE):
            if faits >= n_:
                break
            ct = CARTONS[idx]
            col = (col_imposee or colors.HexColor(RAINBOW[serie % len(RAINBOW)])) if couleur else _GRIS_ECO
            cols = _numeros(rng, deja)
            c.setFillColor(col)
            dy = TAILLE * _CAP / 2.0
            for j in range(3):          # colonne
                for i in range(3):      # rangée
                    x, y = ct["grille"][i][j]
                    _chiffre(c, _px(x), _py(y) - dy, cols[j][i], TAILLE)
            sx, sy = ct["serie"]
            c.setFillColor(GRIS_TRAIT)
            c.setFont("Helvetica-Bold", 4.5)
            c.drawCentredString(_px(sx), _py(sy), "N° %06d" % serie)
            serie += 1
            faits += 1
        c.restoreState()
        # ⭐ 19/11 : n° de page (Maeva : « faut pas oublier nos numéros de page »)
        c.setFillColor(GRIS_TRAIT)
        c.setFont("Helvetica", 6)
        c.drawRightString(PAGE_W - 13.5, 20, "%d" % no_page)
        no_page += 1
        c.showPage()
    c.save()
    buf.seek(0)
    return buf


if __name__ == "__main__":
    open("test_kea.pdf", "wb").write(generer_pdf(nb_cartes=16, couleur=False).read())
    print("KEA genere")
