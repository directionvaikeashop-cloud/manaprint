# -*- coding: utf-8 -*-
"""MANAPRINT — LA JOIE 5 boules (planche de Maeva, refait le 19/11/2026).
16 cartons par feuille A4 PORTRAIT. La planche est reprise TELLE QUELLE comme
fond (trait gris uni, sans aplat gris taché) ; on n'ajoute que les chiffres, le n° de
série et le n° de page.
Règle : I 16-30 : 1 numéro (case du haut à gauche) · G 46-60 : 2 numéros (haut et milieu, le petit en haut) · O 61-75 : 2 numéros (milieu et bas, le petit en haut). Crieur 16-30 et 46-75.
Chiffres Latin Modern GRAS, noirs, le plus gros que chaque case permet.
Feuille ramenée à 6 mm des bords (Konica)."""
import io, os as _os, random
from collections import Counter
from reportlab.pdfgen import canvas
from reportlab.lib.pagesizes import A4, landscape
from reportlab.lib import colors
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont

PAGE_W, PAGE_H = A4
CARTES_PAGE = 16
PLAGES = {'I': (16, 30), 'G': (46, 60), 'O': (61, 75)}
NOIR = colors.Color(0.05, 0.05, 0.05)
GRIS_TRAIT = colors.Color(0.40, 0.40, 0.40)
RAINBOW = ["#E53935", "#FB8C00", "#F9A825", "#43A047", "#00ACC1",
           "#1E88E5", "#3949AB", "#8E24AA", "#D81B60", "#6D4C41"]
_ICI = _os.path.dirname(_os.path.abspath(__file__))
POLICE, _CAP = "Helvetica-Bold", 0.717
try:
    pdfmetrics.registerFont(TTFont("LMROMANB", _os.path.join(_ICI, "LatinModern-Bold.ttf")))
    POLICE, _CAP = "LMROMANB", 0.66
except Exception:
    pass
_IMG_W, _IMG_H = 1086.0, 1536.0
_IMG_FOND = _os.path.join(_ICI, "joie_fond.png")
MARGE_SURE = 6 * 72 / 25.4
ECHELLE = min((PAGE_W - 2 * MARGE_SURE) / PAGE_W, (PAGE_H - 2 * MARGE_SURE) / PAGE_H)
DECAL_X = (PAGE_W - PAGE_W * ECHELLE) / 2.0
DECAL_Y = (PAGE_H - PAGE_H * ECHELLE) / 2.0

# cases : (plage, (x0, y0, x1, y1) px), dans l'ordre où les numéros TRIÉS se posent ;
# serie = (alignement, x, ligne de base) px
CARTONS = [
    {'cells': [('I', (60, 127, 122, 178)), ('G', (132, 127, 195, 178)), ('G', (136, 192, 201, 245)), ('O', (214, 192, 278, 245)), ('O', (215, 259, 280, 313))], 'serie': ('L', 88, 45)},
    {'cells': [('I', (318, 127, 379, 178)), ('G', (389, 127, 451, 178)), ('G', (393, 192, 456, 245)), ('O', (468, 192, 531, 245)), ('O', (468, 259, 533, 313))], 'serie': ('L', 345, 45)},
    {'cells': [('I', (567, 127, 628, 178)), ('G', (638, 127, 700, 178)), ('G', (642, 192, 706, 245)), ('O', (718, 192, 782, 245)), ('O', (718, 259, 783, 313))], 'serie': ('L', 595, 45)},
    {'cells': [('I', (816, 127, 877, 178)), ('G', (888, 127, 949, 178)), ('G', (891, 192, 955, 245)), ('O', (967, 192, 1030, 245)), ('O', (967, 259, 1032, 313))], 'serie': ('L', 845, 45)},
    {'cells': [('I', (60, 472, 122, 524)), ('G', (132, 472, 195, 524)), ('G', (136, 538, 201, 591)), ('O', (214, 539, 278, 591)), ('O', (215, 606, 280, 660))], 'serie': ('L', 88, 389)},
    {'cells': [('I', (318, 472, 379, 524)), ('G', (389, 472, 451, 524)), ('G', (392, 538, 456, 591)), ('O', (468, 538, 531, 591)), ('O', (468, 605, 533, 659))], 'serie': ('L', 345, 389)},
    {'cells': [('I', (567, 472, 628, 524)), ('G', (638, 472, 700, 524)), ('G', (642, 538, 706, 591)), ('O', (718, 538, 782, 591)), ('O', (718, 605, 783, 659))], 'serie': ('L', 595, 389)},
    {'cells': [('I', (816, 472, 877, 524)), ('G', (888, 472, 949, 524)), ('G', (891, 538, 955, 591)), ('O', (967, 538, 1030, 591)), ('O', (967, 605, 1032, 659))], 'serie': ('L', 845, 389)},
    {'cells': [('I', (60, 820, 122, 873)), ('G', (132, 821, 195, 873)), ('G', (136, 887, 201, 940)), ('O', (214, 888, 278, 940)), ('O', (215, 955, 280, 1009))], 'serie': ('L', 88, 735)},
    {'cells': [('I', (318, 821, 379, 873)), ('G', (389, 821, 451, 873)), ('G', (393, 887, 456, 940)), ('O', (468, 888, 531, 940)), ('O', (468, 955, 533, 1009))], 'serie': ('L', 345, 735)},
    {'cells': [('I', (567, 820, 628, 873)), ('G', (638, 821, 700, 873)), ('G', (642, 887, 706, 940)), ('O', (718, 887, 782, 940)), ('O', (718, 955, 783, 1009))], 'serie': ('L', 595, 736)},
    {'cells': [('I', (816, 821, 877, 873)), ('G', (888, 821, 949, 873)), ('G', (891, 888, 955, 940)), ('O', (967, 888, 1030, 940)), ('O', (967, 955, 1032, 1009))], 'serie': ('L', 845, 736)},
    {'cells': [('I', (60, 1178, 122, 1231)), ('G', (132, 1178, 195, 1231)), ('G', (136, 1245, 201, 1298)), ('O', (214, 1245, 278, 1298)), ('O', (215, 1313, 280, 1367))], 'serie': ('L', 88, 1089)},
    {'cells': [('I', (318, 1178, 379, 1231)), ('G', (389, 1178, 451, 1231)), ('G', (393, 1245, 456, 1298)), ('O', (468, 1245, 531, 1298)), ('O', (468, 1312, 533, 1366))], 'serie': ('L', 345, 1090)},
    {'cells': [('I', (567, 1178, 628, 1231)), ('G', (638, 1178, 700, 1231)), ('G', (642, 1245, 706, 1298)), ('O', (718, 1245, 782, 1298)), ('O', (718, 1312, 783, 1366))], 'serie': ('L', 595, 1090)},
    {'cells': [('I', (816, 1178, 877, 1231)), ('G', (888, 1178, 949, 1231)), ('G', (891, 1245, 955, 1298)), ('O', (967, 1245, 1030, 1298)), ('O', (967, 1312, 1032, 1366))], 'serie': ('L', 845, 1090)},
]
AIR_H, AIR_W = 0.62, 0.78
COMPTE = Counter(p for p, _c in CARTONS[0]["cells"])


def _px(x):
    return x / _IMG_W * PAGE_W


def _py(y):
    return PAGE_H * (1 - y / _IMG_H)


def _t(c):
    x0, y0, x1, y1 = c
    w, h = _px(x1) - _px(x0), _px(y1) - _px(y0)
    return int(min(AIR_H * h / _CAP, AIR_W * w / (pdfmetrics.stringWidth("88", POLICE, 1.0) + 0.02)) * 2) / 2.0


TAILLE = min(_t(c) for ct in CARTONS for _p, c in ct["cells"])
TAILLE = 27.0   # ⭐ 20/11 (Maeva : « pourquoi tu rétrécis les chiffres ») : au maximum de la case, comme le POW


def _tirage(rng, p, n):
    a, b = PLAGES[p]
    pool = list(range(a, b + 1, 2)) if (a % 2 == 0 and "PAIR" in "LA JOIE 5 boules") else list(range(a, b + 1))
    return sorted(rng.sample(pool, n))


def _numeros(rng, deja=None):
    while True:
        d = {p: _tirage(rng, p, n) for p, n in COMPTE.items()}
        cle = tuple((p, tuple(d[p])) for p in sorted(d))
        if deja is None or cle not in deja:
            if deja is not None:
                deja.add(cle)
            return d


def generer_pdf(nb_cartes=None, nb_tickets=None, serie_start=1, theme="", couleur=True,
                nom_evenement="", titre_jeu="", couleur_perso="", date_lieu="",
                telephone="", page_start=1, evenement_id="", style="", motif="",
                _deja=None, **_ig):
    n_ = nb_cartes if nb_cartes is not None else nb_tickets
    n_ = max(1, int(n_ if n_ else CARTES_PAGE))
    buf = io.BytesIO()
    c = canvas.Canvas(buf, pagesize=(PAGE_W, PAGE_H), pageCompression=1)
    c.setTitle("LA JOIE 5 boules")
    rng = random.Random(int(serie_start) * 100003 + 1675)
    deja = _deja if _deja is not None else set()
    serie = int(serie_start)
    faits = 0
    try:
        no_page = max(1, int(page_start))
    except Exception:
        no_page = 1
    col_imposee = None
    if couleur and couleur_perso:
        try:
            col_imposee = colors.HexColor(couleur_perso)
        except Exception:
            col_imposee = None
    while faits < n_:
        c.saveState()
        c.translate(DECAL_X, DECAL_Y)
        c.scale(ECHELLE, ECHELLE)
        try:
            c.drawImage(_IMG_FOND, 0, 0, PAGE_W, PAGE_H, preserveAspectRatio=False, mask="auto")
        except Exception:
            pass
        for idx in range(CARTES_PAGE):
            if faits >= n_:
                break
            ct = CARTONS[idx]
            col = (col_imposee or colors.HexColor(RAINBOW[serie % len(RAINBOW)])) if couleur else NOIR
            nums = _numeros(rng, deja)
            pos = {p: 0 for p in nums}
            c.saveState()
            c.setFillColor(col); c.setStrokeColor(col)
            c.setLineWidth(0.5); c.setLineJoin(1)
            for p, (x0, y0, x1, y1) in ct["cells"]:
                v = str(nums[p][pos[p]]); pos[p] += 1
                o = c.beginText(); o.setTextRenderMode(2); o.setFont(POLICE, TAILLE)
                o.setTextOrigin(_px((x0 + x1) / 2.0) - c.stringWidth(v, POLICE, TAILLE) / 2.0,
                                _py((y0 + y1) / 2.0) - TAILLE * _CAP / 2.0)
                o.textOut(v); c.drawText(o)
            c.restoreState()
            al, sx, sy = ct["serie"]
            c.setFillColor(GRIS_TRAIT)
            c.setFont("Helvetica-Bold", 6)
            txt = "%06d" % serie
            if al == "R":
                c.drawRightString(_px(sx), _py(sy), txt)
            elif al == "C":
                c.drawCentredString(_px(sx), _py(sy), txt)
            else:
                c.drawString(_px(sx), _py(sy), txt)
            serie += 1
            faits += 1
        c.restoreState()
        c.setFillColor(GRIS_TRAIT)
        c.setFont("Helvetica", 6)
        c.drawRightString(PAGE_W - 17, PAGE_H - 13, "%d" % no_page)
        no_page += 1
        c.showPage()
    c.save()
    buf.seek(0)
    return buf
