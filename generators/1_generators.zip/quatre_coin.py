# -*- coding: utf-8 -*-
"""MANAPRINT — 4 COINS (le modèle imprimé de Maeva, refait le 19/11/2026).
12 cartons / feuille A4 PORTRAIT. Chaque carton = 4 blocs de 2 x 2 cases = 16 numéros :
   bloc haut-gauche 1-15 · bloc haut-droite 61-75 · bloc bas-gauche 16-30 · bloc bas-droite 46-60
   (4 numéros différents par bloc, ordre libre, comme le modèle) -> crieur 1 à 75.
Pied : « N° 00xxxx » à gauche, « 89 52 98 83 » à droite.
Chiffres Latin Modern (l'écriture du modèle), noirs, le plus gros que la case permet.
Grille gris uni, feuille à 6 mm des bords (Konica)."""
import io, os as _os, random
from reportlab.pdfgen import canvas
from reportlab.lib.pagesizes import A4
from reportlab.lib import colors
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont

PAGE_W, PAGE_H = A4
CARTES_PAGE = 12
PLAGES = {"B": (1, 15), "O": (61, 75), "I": (16, 30), "G": (46, 60)}
TEL = "89 52 98 83"
NOIR = colors.Color(0.05, 0.05, 0.05)
GRIS_TRAIT = colors.Color(0.30, 0.30, 0.30)
RAINBOW = ["#E53935", "#FB8C00", "#F9A825", "#43A047", "#00ACC1",
           "#1E88E5", "#3949AB", "#8E24AA", "#D81B60", "#6D4C41"]
_ICI = _os.path.dirname(_os.path.abspath(__file__))
POLICE, _CAP = "Times-Roman", 0.66
try:
    pdfmetrics.registerFont(TTFont("LMROMAN", _os.path.join(_ICI, "LatinModern.ttf")))
    POLICE, _CAP = "LMROMAN", 0.644
except Exception:
    pass
_IMG_W, _IMG_H = 1103.0, 1560.0
_IMG_FOND = _os.path.join(_ICI, "quatre_coin_fond.png")
MARGE_SURE = 6 * 72 / 25.4
ECHELLE = min((PAGE_W - 2 * MARGE_SURE) / PAGE_W, (PAGE_H - 2 * MARGE_SURE) / PAGE_H)
DECAL_X = (PAGE_W - PAGE_W * ECHELLE) / 2.0
DECAL_Y = (PAGE_H - PAGE_H * ECHELLE) / 2.0

CARTONS = [
    {'cells': [('B', (56, 139, 128, 197)), ('B', (131, 139, 203, 197)), ('O', (218, 139, 292, 197)), ('O', (294, 139, 364, 197)), ('B', (56, 200, 128, 257)), ('B', (131, 199, 203, 257)), ('O', (218, 200, 291, 256)), ('O', (294, 200, 364, 256)), ('I', (56, 273, 128, 332)), ('I', (131, 273, 203, 332)), ('G', (218, 273, 292, 332)), ('G', (294, 273, 364, 332)), ('I', (56, 335, 128, 392)), ('I', (131, 335, 203, 392)), ('G', (218, 335, 291, 392)), ('G', (294, 335, 364, 392))], 'sg': (56, 392), 'sd': (364, 392)},
    {'cells': [('B', (407, 139, 475, 197)), ('B', (478, 139, 546, 197)), ('O', (561, 139, 628, 197)), ('O', (630, 139, 698, 197)), ('B', (407, 199, 475, 256)), ('B', (478, 200, 546, 257)), ('O', (561, 200, 628, 256)), ('O', (630, 200, 698, 256)), ('I', (407, 273, 475, 332)), ('I', (478, 273, 546, 332)), ('G', (561, 273, 628, 332)), ('G', (631, 273, 698, 332)), ('I', (407, 335, 475, 392)), ('I', (478, 335, 546, 392)), ('G', (561, 335, 628, 392)), ('G', (630, 335, 698, 392))], 'sg': (407, 392), 'sd': (698, 392)},
    {'cells': [('B', (741, 139, 812, 197)), ('B', (814, 139, 887, 197)), ('O', (901, 139, 973, 197)), ('O', (976, 139, 1048, 197)), ('B', (741, 200, 812, 256)), ('B', (814, 200, 887, 256)), ('O', (901, 199, 973, 257)), ('O', (976, 200, 1048, 257)), ('I', (741, 273, 812, 332)), ('I', (814, 273, 887, 332)), ('G', (901, 273, 973, 332)), ('G', (976, 273, 1048, 332)), ('I', (741, 335, 812, 392)), ('I', (814, 335, 887, 392)), ('G', (901, 335, 973, 392)), ('G', (976, 335, 1048, 392))], 'sg': (741, 392), 'sd': (1048, 392)},
    {'cells': [('B', (56, 484, 128, 543)), ('B', (131, 484, 203, 542)), ('O', (218, 484, 292, 543)), ('O', (294, 484, 364, 542)), ('B', (56, 545, 128, 603)), ('B', (131, 545, 203, 603)), ('O', (218, 545, 292, 603)), ('O', (294, 545, 364, 603)), ('I', (56, 619, 128, 678)), ('I', (131, 619, 203, 678)), ('G', (218, 619, 291, 678)), ('G', (294, 619, 364, 678)), ('I', (56, 680, 128, 737)), ('I', (131, 680, 203, 737)), ('G', (218, 680, 291, 737)), ('G', (294, 680, 364, 737))], 'sg': (56, 737), 'sd': (364, 737)},
    {'cells': [('B', (407, 484, 475, 543)), ('B', (478, 484, 546, 543)), ('O', (561, 484, 628, 543)), ('O', (630, 484, 698, 543)), ('B', (407, 545, 475, 603)), ('B', (478, 545, 546, 603)), ('O', (561, 545, 628, 603)), ('O', (630, 545, 698, 603)), ('I', (407, 619, 475, 678)), ('I', (478, 619, 546, 678)), ('G', (561, 619, 628, 678)), ('G', (630, 619, 698, 678)), ('I', (407, 680, 475, 737)), ('I', (478, 680, 546, 737)), ('G', (561, 680, 628, 737)), ('G', (630, 680, 698, 737))], 'sg': (407, 737), 'sd': (698, 737)},
    {'cells': [('B', (741, 484, 812, 542)), ('B', (814, 484, 887, 543)), ('O', (901, 484, 973, 542)), ('O', (976, 484, 1048, 543)), ('B', (741, 545, 812, 603)), ('B', (814, 545, 887, 603)), ('O', (901, 545, 973, 603)), ('O', (976, 545, 1048, 603)), ('I', (741, 619, 812, 678)), ('I', (814, 619, 887, 678)), ('G', (901, 619, 973, 678)), ('G', (976, 619, 1048, 678)), ('I', (741, 680, 812, 737)), ('I', (814, 680, 887, 737)), ('G', (901, 680, 973, 737)), ('G', (976, 680, 1048, 737))], 'sg': (741, 737), 'sd': (1048, 737)},
    {'cells': [('B', (56, 833, 128, 892)), ('B', (131, 833, 203, 892)), ('O', (218, 833, 291, 892)), ('O', (294, 833, 364, 892)), ('B', (56, 894, 128, 952)), ('B', (131, 894, 203, 952)), ('O', (218, 894, 291, 951)), ('O', (294, 894, 364, 951)), ('I', (56, 968, 128, 1027)), ('I', (131, 968, 203, 1027)), ('G', (218, 968, 291, 1027)), ('G', (294, 968, 364, 1027)), ('I', (56, 1030, 128, 1087)), ('I', (131, 1030, 203, 1087)), ('G', (218, 1030, 291, 1087)), ('G', (294, 1030, 364, 1087))], 'sg': (56, 1087), 'sd': (364, 1087)},
    {'cells': [('B', (407, 833, 475, 892)), ('B', (478, 833, 546, 892)), ('O', (561, 833, 628, 892)), ('O', (630, 833, 698, 892)), ('B', (407, 894, 475, 951)), ('B', (478, 894, 546, 951)), ('O', (561, 894, 628, 951)), ('O', (630, 894, 698, 951)), ('I', (407, 968, 475, 1027)), ('I', (478, 968, 546, 1027)), ('G', (561, 968, 628, 1027)), ('G', (630, 968, 698, 1027)), ('I', (407, 1030, 475, 1087)), ('I', (478, 1030, 546, 1087)), ('G', (561, 1030, 628, 1087)), ('G', (630, 1030, 698, 1087))], 'sg': (407, 1087), 'sd': (698, 1087)},
    {'cells': [('B', (741, 833, 812, 892)), ('B', (814, 833, 887, 892)), ('O', (901, 833, 973, 892)), ('O', (976, 833, 1048, 892)), ('B', (741, 894, 812, 951)), ('B', (814, 894, 887, 951)), ('O', (901, 894, 973, 951)), ('O', (976, 894, 1048, 951)), ('I', (741, 968, 812, 1027)), ('I', (814, 968, 887, 1027)), ('G', (901, 968, 973, 1027)), ('G', (976, 968, 1048, 1027)), ('I', (741, 1030, 812, 1087)), ('I', (814, 1030, 887, 1087)), ('G', (901, 1030, 973, 1087)), ('G', (976, 1030, 1048, 1087))], 'sg': (741, 1087), 'sd': (1048, 1087)},
    {'cells': [('B', (56, 1180, 128, 1238)), ('B', (131, 1180, 203, 1238)), ('O', (218, 1180, 291, 1238)), ('O', (294, 1180, 364, 1238)), ('B', (56, 1241, 128, 1298)), ('B', (131, 1241, 203, 1298)), ('O', (218, 1241, 292, 1298)), ('O', (294, 1241, 364, 1298)), ('I', (56, 1315, 128, 1375)), ('I', (131, 1315, 203, 1375)), ('G', (218, 1315, 291, 1375)), ('G', (294, 1315, 364, 1375)), ('I', (56, 1377, 128, 1436)), ('I', (131, 1377, 203, 1436)), ('G', (218, 1377, 292, 1436)), ('G', (294, 1377, 364, 1436))], 'sg': (56, 1436), 'sd': (364, 1436)},
    {'cells': [('B', (407, 1180, 475, 1238)), ('B', (478, 1180, 546, 1238)), ('O', (561, 1180, 628, 1238)), ('O', (630, 1180, 698, 1238)), ('B', (407, 1241, 475, 1299)), ('B', (478, 1241, 546, 1299)), ('O', (561, 1241, 628, 1298)), ('O', (630, 1241, 698, 1298)), ('I', (407, 1315, 475, 1375)), ('I', (478, 1315, 545, 1375)), ('G', (561, 1315, 628, 1375)), ('G', (630, 1315, 698, 1375)), ('I', (407, 1377, 475, 1436)), ('I', (478, 1377, 546, 1436)), ('G', (561, 1377, 628, 1436)), ('G', (630, 1377, 698, 1436))], 'sg': (407, 1436), 'sd': (698, 1436)},
    {'cells': [('B', (741, 1180, 812, 1238)), ('B', (814, 1180, 887, 1238)), ('O', (901, 1180, 973, 1238)), ('O', (976, 1180, 1048, 1238)), ('B', (741, 1241, 812, 1298)), ('B', (814, 1241, 887, 1298)), ('O', (901, 1241, 973, 1298)), ('O', (976, 1241, 1048, 1298)), ('I', (741, 1315, 812, 1375)), ('I', (814, 1315, 887, 1375)), ('G', (901, 1315, 973, 1375)), ('G', (976, 1315, 1048, 1375)), ('I', (741, 1377, 812, 1436)), ('I', (814, 1377, 887, 1436)), ('G', (901, 1377, 973, 1436)), ('G', (976, 1377, 1048, 1436))], 'sg': (741, 1436), 'sd': (1048, 1436)},
]
AIR_H, AIR_W = 0.72, 0.86


def _px(x):
    return x / _IMG_W * PAGE_W


def _py(y):
    return PAGE_H * (1 - y / _IMG_H)


def _t(c):
    x0, y0, x1, y1 = c
    w, h = _px(x1) - _px(x0), _px(y1) - _px(y0)
    return int(min(AIR_H * h / _CAP, AIR_W * w / pdfmetrics.stringWidth("88", POLICE, 1.0)) * 2) / 2.0


TAILLE = min(_t(c) for ct in CARTONS for _p, c in ct["cells"])


def _numeros(rng, deja=None):
    while True:
        d = {pl: rng.sample(range(a, b + 1), 4) for pl, (a, b) in PLAGES.items()}
        cle = tuple((pl, tuple(sorted(d[pl]))) for pl in sorted(d))
        if deja is None or cle not in deja:
            if deja is not None:
                deja.add(cle)
            return d


def generer_pdf(nb_cartes=None, nb_tickets=None, serie_start=1, theme="", couleur=True,
                nom_evenement="", titre_jeu="", couleur_perso="", date_lieu="",
                telephone="", page_start=1, evenement_id="", style="", motif="",
                _deja=None, **_ig):
    n_ = nb_cartes if nb_cartes is not None else nb_tickets
    n_ = max(1, int(n_ if n_ else CARTES_PAGE))
    buf = io.BytesIO()
    c = canvas.Canvas(buf, pagesize=(PAGE_W, PAGE_H), pageCompression=1)
    c.setTitle("4 COINS")
    rng = random.Random(int(serie_start) * 100003 + 4444)
    deja = _deja if _deja is not None else set()
    tel = (telephone or "").strip() or TEL
    serie = int(serie_start)
    faits = 0
    try:
        no_page = max(1, int(page_start))
    except Exception:
        no_page = 1
    col_imposee = None
    if couleur and couleur_perso:
        try:
            col_imposee = colors.HexColor(couleur_perso)
        except Exception:
            col_imposee = None
    while faits < n_:
        c.saveState()
        c.translate(DECAL_X, DECAL_Y)
        c.scale(ECHELLE, ECHELLE)
        try:
            c.drawImage(_IMG_FOND, 0, 0, PAGE_W, PAGE_H, preserveAspectRatio=False, mask="auto")
        except Exception:
            pass
        for idx in range(CARTES_PAGE):
            if faits >= n_:
                break
            ct = CARTONS[idx]
            col = (col_imposee or colors.HexColor(RAINBOW[serie % len(RAINBOW)])) if couleur else NOIR
            nums = _numeros(rng, deja)
            pos = {pl: 0 for pl in nums}
            c.saveState()
            c.setFillColor(col); c.setStrokeColor(col)
            c.setLineWidth(0.2); c.setLineJoin(1)
            for pl, (x0, y0, x1, y1) in ct["cells"]:
                v = str(nums[pl][pos[pl]]); pos[pl] += 1
                o = c.beginText(); o.setTextRenderMode(2); o.setFont(POLICE, TAILLE)
                o.setTextOrigin(_px((x0 + x1) / 2.0) - c.stringWidth(v, POLICE, TAILLE) / 2.0,
                                _py((y0 + y1) / 2.0) - TAILLE * _CAP / 2.0)
                o.textOut(v); c.drawText(o)
            c.restoreState()
            c.setFillColor(GRIS_TRAIT)
            c.setFont("Helvetica", 5)
            gx, gy = ct["sg"]; dx_, dy_ = ct["sd"]
            c.drawString(_px(gx + 4), _py(gy + 11), "N° %06d" % serie)
            c.drawRightString(_px(dx_ - 4), _py(dy_ + 11), tel)
            serie += 1
            faits += 1
        c.restoreState()
        c.setFillColor(GRIS_TRAIT)
        c.setFont("Helvetica", 6)
        c.drawRightString(PAGE_W - 17, PAGE_H - 13, "%d" % no_page)
        no_page += 1
        c.showPage()
    c.save()
    buf.seek(0)
    return buf
