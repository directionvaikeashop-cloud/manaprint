# -*- coding: utf-8 -*-
"""MANAPRINT — OHANA 75 · 8 BOULES (20/11/2026, frère du OHANA 75 · 10 boules
refait d'après la feuille de référence de Maeva).

9 cartons par feuille A4 PORTRAIT, en bandeaux pleine largeur :
   · en haut à gauche, le n° de série dans un petit cadre arrondi ;
   · au centre du haut, « OHANA 75 · 8 boules · 2KEA & Associé — Papeete » ;
   · une rangée de 8 numéros : un numéro SIMPLE (gros) puis un numéro dans
     un ROND POINTILLÉ (plus petit), quatre fois.
Règle : 2 numéros par plage, triés, de gauche à droite —
   B 1-15 · I 16-30 · G 46-60 · O 61-75 (pas de N) -> crieur 1-30 et 46-75.
Chiffres LATIN MODERN ROMAN nourris (même écriture que le 10 boules).
N° de page en haut à droite.
"""
import io, os as _os, random
from reportlab.pdfgen import canvas
from reportlab.lib.pagesizes import A4
from reportlab.lib import colors
from reportlab.lib.units import mm
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont

PAGE_W, PAGE_H = A4
CARTES_PAGE = 9
PLAGES = [(1, 15), (16, 30), (46, 60), (61, 75)]

GRIS_CHIFFRE = colors.Color(0.27, 0.27, 0.27)
GRIS_CADRE = colors.Color(0.62, 0.62, 0.62)
GRIS_ROND = colors.Color(0.55, 0.55, 0.55)
GRIS_TEXTE = colors.Color(0.55, 0.55, 0.55)
RAINBOW = ["#E53935", "#FB8C00", "#F9A825", "#43A047", "#00ACC1",
           "#1E88E5", "#3949AB", "#8E24AA", "#D81B60", "#6D4C41"]

_ICI = _os.path.dirname(_os.path.abspath(__file__))
POLICE = "Helvetica"
try:
    pdfmetrics.registerFont(TTFont("LMROMAN", _os.path.join(_ICI, "LatinModern.ttf")))
    POLICE = "LMROMAN"
except Exception:
    pass
_CENTRE_Y = 0.322          # milieu vertical des chiffres Latin Modern (en taille de police)

# ── géométrie (points), relevée sur la feuille de référence ──────────────
MARGE_X = 6 * mm
MARGE_Y = 8 * mm
GOUTTIERE = 6.0
CARTE_W = PAGE_W - 2 * MARGE_X
CARTE_H = (PAGE_H - 2 * MARGE_Y - (CARTES_PAGE - 1) * GOUTTIERE) / CARTES_PAGE
RAYON_CARTE = 4.0

# ⭐ 18/11 (Maeva : « grossis au maximum comme on l'a toujours fait ») :
#    le rond prend toute la hauteur libre du bandeau (sous la ligne du haut),
#    les 5 paires remplissent la largeur ; même rapport gros/petit que le modèle.
T_SIMPLE = 42.0            # le gros numéro simple
T_ROND = 31.0              # le numéro dans le rond
R_ROND = 24.0              # rayon du rond pointillé
_PAS = 136.0               # une paire « simple + rond » tous les 136 pt (4 paires)
_DEBUT = 30.0
# centres x (en points, depuis le bord gauche de la carte) : simple / rond
X_SIMPLE = [_DEBUT + k * _PAS + 19.0 for k in range(4)]
X_ROND = [_DEBUT + k * _PAS + 72.0 for k in range(4)]
Y_CHIFFRES = 0.403         # depuis le BAS de la carte, en fraction de sa hauteur

SERIE_BOX = (5.0, 5.0, 45.0, 12.0)   # x, y depuis le haut-gauche, largeur, hauteur
T_SERIE = 6.5
T_ENTETE = 5.0
ENTETE = "OHANA 75 · 8 boules · 2KEA & Associé — Papeete"


def _numeros(rng, deja=None):
    while True:
        d = [sorted(rng.sample(range(a, b + 1), 2)) for a, b in PLAGES]
        cle = tuple(v for p in d for v in p)
        if deja is None or cle not in deja:
            if deja is not None:
                deja.add(cle)
            return d


def _carte(c, x0, y0, nums, serie, col, entete):
    # cadre
    c.setStrokeColor(GRIS_CADRE)
    c.setLineWidth(0.8)
    c.roundRect(x0, y0, CARTE_W, CARTE_H, RAYON_CARTE, stroke=1, fill=0)
    # n° de série
    bx, by, bw, bh = SERIE_BOX
    c.setLineWidth(0.5)
    c.roundRect(x0 + bx, y0 + CARTE_H - by - bh, bw, bh, 2.5, stroke=1, fill=0)
    c.setFillColor(GRIS_TEXTE)
    c.setFont("Helvetica", T_SERIE)
    c.drawCentredString(x0 + bx + bw / 2.0, y0 + CARTE_H - by - bh + (bh - T_SERIE * 0.72) / 2.0,
                        "%06d" % serie)
    # ligne du haut
    c.setFont("Helvetica", T_ENTETE)
    c.drawCentredString(x0 + CARTE_W / 2.0, y0 + CARTE_H - by - bh / 2.0 - T_ENTETE * 0.36, entete)
    # les 10 numéros
    yc = y0 + CARTE_H * Y_CHIFFRES
    c.setDash(1.2, 1.2)
    c.setStrokeColor(GRIS_ROND)
    c.setLineWidth(0.5)
    for xr in X_ROND:
        c.circle(x0 + xr, yc, R_ROND, stroke=1, fill=0)
    c.setDash()
    c.saveState()             # le mode « trait » des chiffres ne doit pas déborder sur le reste
    c.setFillColor(col)
    c.setStrokeColor(col)
    c.setLineWidth(0.6)       # chiffres un peu nourris, comme sur le modèle
    c.setLineJoin(1)
    for (petit, grand), xs, xr in zip(nums, X_SIMPLE, X_ROND):
        for txt, x, t in ((str(petit), x0 + xs, T_SIMPLE), (str(grand), x0 + xr, T_ROND)):
            c.setLineWidth(0.026 * t)   # ⭐ 20/11 : le gras OHANA du 23/09 (0,026 de la taille)
            o = c.beginText()
            o.setTextRenderMode(2)
            o.setFont(POLICE, t)
            o.setTextOrigin(x - c.stringWidth(txt, POLICE, t) / 2.0, yc - t * _CENTRE_Y)
            o.textOut(txt)
            c.drawText(o)
    c.restoreState()


def generer_pdf(nb_cartes=None, nb_tickets=None, serie_start=1, theme="", couleur=True,
                nom_evenement="", titre_jeu="", couleur_perso="", date_lieu="",
                telephone="", page_start=1, evenement_id="", style="", motif="",
                _deja=None, **_ig):
    n_ = nb_cartes if nb_cartes is not None else nb_tickets
    n_ = max(1, int(n_ if n_ else CARTES_PAGE))
    buf = io.BytesIO()
    c = canvas.Canvas(buf, pagesize=(PAGE_W, PAGE_H), pageCompression=1)
    c.setTitle("OHANA 75 - 8 boules")
    rng = random.Random(int(serie_start) * 100003 + 7508)
    deja = _deja if _deja is not None else set()
    entete = ENTETE + ((" " + telephone.strip()) if (telephone or "").strip() else "")
    col_imposee = None
    if couleur and couleur_perso:
        try:
            col_imposee = colors.HexColor(couleur_perso)
        except Exception:
            col_imposee = None
    serie = int(serie_start)
    faits = 0
    try:
        no_page = max(1, int(page_start))
    except Exception:
        no_page = 1
    while faits < n_:
        for k in range(CARTES_PAGE):
            if faits >= n_:
                break
            y0 = PAGE_H - MARGE_Y - (k + 1) * CARTE_H - k * GOUTTIERE
            col = (col_imposee or colors.HexColor(RAINBOW[serie % len(RAINBOW)])) if couleur else GRIS_CHIFFRE
            _carte(c, MARGE_X, y0, _numeros(rng, deja), serie, col, entete)
            serie += 1
            faits += 1
        c.setFillColor(GRIS_TEXTE)
        c.setFont("Helvetica", 7)
        c.drawRightString(PAGE_W - MARGE_X, PAGE_H - MARGE_Y + 8, "%d" % no_page)
        no_page += 1
        c.showPage()
    c.save()
    buf.seek(0)
    return buf


if __name__ == "__main__":
    open("test_ohana75_8b.pdf", "wb").write(generer_pdf(nb_cartes=9, couleur=False).read())
    print("OHANA 75 8 boules genere")


# ⭐ 21/11 : les variantes spéciales restent celles d'avant (fichier ohana75_8boules_v1.py, inchangé)
def generer_pdf_mystere(**kw):
    try:
        from generators import ohana75_8boules_v1 as _v1
    except Exception:
        import ohana75_8boules_v1 as _v1
    return _v1.generer_pdf_mystere(**kw)

def generer_pdf_smorfia(**kw):
    try:
        from generators import ohana75_8boules_v1 as _v1
    except Exception:
        import ohana75_8boules_v1 as _v1
    return _v1.generer_pdf_smorfia(**kw)

