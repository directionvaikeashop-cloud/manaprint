# -*- coding: utf-8 -*-
"""MANAPRINT — TUBUAI · 6 boules (création RANIHEI, maquette du 31/10).
Refait le 19/11/2026. 8 cartons / feuille A4 PORTRAIT. La maquette est reprise
TELLE QUELLE comme fond (n° imprimé gommé, 2 tons francs pour la Konica) ; on
n'ajoute que les chiffres, le n° de série et le n° de page.
6 cercles = les plages du BINGO 90 :
   gauche haut->bas : 1-15 · 16-30 · 31-45 ; droite haut->bas : 46-60 · 61-75 · 76-90
   -> crieur 1 à 90.
Chiffres League Gothic épaissi, le plus gros que la plus petite boule permet."""
import io, os as _os, random
from reportlab.pdfgen import canvas
from reportlab.lib.pagesizes import A4
from reportlab.lib import colors
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont

PAGE_W, PAGE_H = A4
CARTES_PAGE = 8
PLAGES = [(1, 15), (16, 30), (31, 45), (46, 60), (61, 75), (76, 90)]
PAR_COLONNE = [1, 1, 1, 1, 1, 1]
NOIR = colors.Color(0.10, 0.10, 0.10)
GRIS_TRAIT = colors.Color(0.40, 0.40, 0.40)
RAINBOW = ["#E53935", "#FB8C00", "#F9A825", "#43A047", "#00ACC1",
           "#1E88E5", "#3949AB", "#8E24AA", "#D81B60", "#6D4C41"]
_ICI = _os.path.dirname(_os.path.abspath(__file__))
POLICE, _CAP = "Helvetica-Bold", 0.717
try:
    pdfmetrics.registerFont(TTFont("LGOTH", _os.path.join(_ICI, "LeagueGothic-Regular_v2.ttf")))
    POLICE, _CAP = "LGOTH", 0.735
except Exception:
    pass
_EPAIS = 0.6
_IMG_W, _IMG_H = 1054.0, 1492.0
_IMG_FOND = _os.path.join(_ICI, "tubuai_fond.png")
MARGE_SURE = 6 * 72 / 25.4
ECHELLE = min((PAGE_W - 2 * MARGE_SURE) / PAGE_W, (PAGE_H - 2 * MARGE_SURE) / PAGE_H)
DECAL_X = (PAGE_W - PAGE_W * ECHELLE) / 2.0
DECAL_Y = (PAGE_H - PAGE_H * ECHELLE) / 2.0

# boules : (cx, cy, largeur, hauteur) px, colonne par colonne ; serie = place du n° imprimé
CARTONS = [
    {'cols': [[(121.9, 98.0, 80.2, 80.2)], [(63.2, 155.7, 82.2, 82.2)], [(149.8, 281.6, 82.4, 82.4)], [(434.8, 99.3, 79.2, 79.2)], [(473.2, 174.7, 80.4, 80.4)], [(417.3, 283.1, 81.2, 81.2)]], 'serie': (391.0, 59)},
    {'cols': [[(648.0, 98.1, 81.2, 81.2)], [(586.9, 155.7, 82.2, 82.2)], [(676.4, 281.6, 82.0, 82.0)], [(961.1, 99.4, 79.2, 79.2)], [(999.5, 174.8, 80.0, 80.0)], [(944.0, 283.1, 82.0, 82.0)]], 'serie': (918.5, 59)},
    {'cols': [[(121.7, 455.8, 80.0, 80.0)], [(60.9, 513.1, 82.0, 82.0)], [(149.7, 638.7, 82.4, 82.4)], [(434.9, 456.9, 79.2, 79.2)], [(473.3, 532.0, 80.2, 80.2)], [(417.3, 640.2, 81.2, 81.2)]], 'serie': (391.0, 417)},
    {'cols': [[(648.0, 455.8, 81.2, 81.2)], [(586.9, 513.0, 82.2, 82.2)], [(676.3, 638.7, 82.0, 82.0)], [(961.1, 456.8, 79.2, 79.2)], [(999.7, 532.0, 80.4, 80.4)], [(943.9, 640.2, 82.0, 82.0)]], 'serie': (918.5, 417)},
    {'cols': [[(121.9, 812.5, 80.0, 80.0)], [(62.7, 869.8, 81.8, 81.8)], [(149.8, 995.6, 82.4, 82.4)], [(434.8, 813.7, 78.8, 78.8)], [(473.3, 888.7, 80.2, 80.2)], [(417.4, 997.1, 81.2, 81.2)]], 'serie': (391.0, 774)},
    {'cols': [[(644.6, 812.5, 80.0, 80.0)], [(585.1, 869.7, 82.4, 82.4)], [(676.3, 995.6, 82.0, 82.0)], [(961.1, 813.7, 79.2, 79.2)], [(999.8, 888.7, 81.2, 81.2)], [(944.0, 997.1, 82.0, 82.0)]], 'serie': (918.5, 774)},
    {'cols': [[(121.1, 1171.0, 80.6, 80.6)], [(60.5, 1228.4, 81.4, 81.4)], [(149.6, 1353.9, 82.2, 82.2)], [(434.8, 1172.0, 79.2, 79.2)], [(473.2, 1247.2, 80.4, 80.4)], [(417.3, 1355.4, 81.2, 81.2)]], 'serie': (391.0, 1133)},
    {'cols': [[(646.6, 1171.0, 80.6, 80.6)], [(585.4, 1228.3, 81.6, 81.6)], [(676.3, 1353.9, 82.0, 82.0)], [(961.3, 1172.0, 79.2, 79.2)], [(999.9, 1247.1, 81.2, 81.2)], [(944.0, 1355.4, 81.6, 81.6)]], 'serie': (918.5, 1133)},
]


def _px(x):
    return x / _IMG_W * PAGE_W


def _py(y):
    return PAGE_H * (1 - y / _IMG_H)


def _taille_max():
    # « 88 » doit tenir dans la plus petite boule (ellipse intérieure, 7 px d'air)
    a = min(e[2] for ct in CARTONS for col in ct["cols"] for e in col) / 2.0 - 7
    b = min(e[3] for ct in CARTONS for col in ct["cols"] for e in col) / 2.0 - 7
    a, b = _px(a) - _px(0), _px(b) - _px(0)
    t = 10.0
    while True:
        t2 = t + 0.5
        w = pdfmetrics.stringWidth("88", POLICE, t2) / 2.0 + _EPAIS
        h = t2 * _CAP / 2.0 + _EPAIS
        if (w / a) ** 2 + (h / b) ** 2 > 1.0:
            return t
        t = t2


TAILLE = _taille_max()   # 19/11 : au maximum (Maeva)


def _numeros(rng, deja=None):
    while True:
        d = [sorted(rng.sample(range(lo, hi + 1), n)) for (lo, hi), n in zip(PLAGES, PAR_COLONNE)]
        cle = tuple(v for p in d for v in p)
        if deja is None or cle not in deja:
            if deja is not None:
                deja.add(cle)
            return d


def _chiffre(c, x, y, txt, t):
    c.saveState()
    c.setStrokeColor(c._fillColorObj)
    c.setLineWidth(_EPAIS)
    c.setLineJoin(1)
    o = c.beginText()
    o.setTextRenderMode(2)
    o.setFont(POLICE, t)
    o.setTextOrigin(x - c.stringWidth(txt, POLICE, t) / 2.0, y)
    o.textOut(txt)
    c.drawText(o)
    c.restoreState()


def generer_pdf(nb_cartes=None, nb_tickets=None, serie_start=1, theme="", couleur=True,
                nom_evenement="", titre_jeu="", couleur_perso="", date_lieu="",
                telephone="", page_start=1, evenement_id="", style="", motif="",
                _deja=None, **_ig):
    n_ = nb_cartes if nb_cartes is not None else nb_tickets
    n_ = max(1, int(n_ if n_ else CARTES_PAGE))
    buf = io.BytesIO()
    c = canvas.Canvas(buf, pagesize=(PAGE_W, PAGE_H), pageCompression=1)
    c.setTitle("TUBUAI")
    rng = random.Random(int(serie_start) * 100003 + 3190)
    deja = _deja if _deja is not None else set()
    serie = int(serie_start)
    faits = 0
    try:
        no_page = max(1, int(page_start))
    except Exception:
        no_page = 1
    col_imposee = None
    if couleur and couleur_perso:
        try:
            col_imposee = colors.HexColor(couleur_perso)
        except Exception:
            col_imposee = None
    while faits < n_:
        c.saveState()
        c.translate(DECAL_X, DECAL_Y)
        c.scale(ECHELLE, ECHELLE)
        try:
            c.drawImage(_IMG_FOND, 0, 0, PAGE_W, PAGE_H, preserveAspectRatio=False, mask="auto")
        except Exception:
            pass
        for idx in range(CARTES_PAGE):
            if faits >= n_:
                break
            ct = CARTONS[idx]
            col = (col_imposee or colors.HexColor(RAINBOW[serie % len(RAINBOW)])) if couleur else NOIR
            nums = _numeros(rng, deja)
            c.setFillColor(col)
            for boules, vals in zip(ct["cols"], nums):
                for (x, y, w, h), v in zip(boules, vals):
                    _chiffre(c, _px(x), _py(y) - TAILLE * _CAP / 2.0, str(v), TAILLE)
            sx, sy = ct["serie"]
            c.setFillColor(GRIS_TRAIT)
            c.setFont("Helvetica-Bold", 6)
            c.drawCentredString(_px(sx), _py(sy), "N° %06d" % serie)
            serie += 1
            faits += 1
        c.restoreState()
        c.setFillColor(GRIS_TRAIT)
        c.setFont("Helvetica", 6)
        c.drawRightString(PAGE_W - 17, PAGE_H - 19, "%d" % no_page)
        no_page += 1
        c.showPage()
    c.save()
    buf.seek(0)
    return buf
