# -*- coding: utf-8 -*-
"""MANAPRINT — WOW 4 boules (planche de Maeva, refait le 19/11/2026).
12 cartons par feuille A4 PORTRAIT. La planche est reprise TELLE QUELLE comme fond
(trait gris uni, sans aplat gris taché) ; on n'ajoute que les chiffres, le n° de
série et le n° de page.
Règle : colonne de gauche 30-44 (2 numéros) · colonne de droite 45-60 (2 numéros), triés du plus petit en haut. Crieur 30-60.
Chiffres Latin Modern GRAS, noirs, le plus gros que chaque case permet.
Feuille ramenée à 6 mm des bords (Konica)."""
import io, os as _os, random
from collections import Counter
from reportlab.pdfgen import canvas
from reportlab.lib.pagesizes import A4, landscape
from reportlab.lib import colors
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont

PAGE_W, PAGE_H = A4
CARTES_PAGE = 12
PLAGES = {'G': (30, 44), 'D': (45, 60)}
NOIR = colors.Color(0.05, 0.05, 0.05)
GRIS_TRAIT = colors.Color(0.40, 0.40, 0.40)
RAINBOW = ["#E53935", "#FB8C00", "#F9A825", "#43A047", "#00ACC1",
           "#1E88E5", "#3949AB", "#8E24AA", "#D81B60", "#6D4C41"]
_ICI = _os.path.dirname(_os.path.abspath(__file__))
POLICE, _CAP = "Helvetica-Bold", 0.717
try:
    pdfmetrics.registerFont(TTFont("LMROMANB", _os.path.join(_ICI, "LatinModern-Bold.ttf")))
    POLICE, _CAP = "LMROMANB", 0.66
except Exception:
    pass
_IMG_W, _IMG_H = 1055.0, 1492.0
_IMG_FOND = _os.path.join(_ICI, "wow4_fond.png")
MARGE_SURE = 6 * 72 / 25.4
ECHELLE = min((PAGE_W - 2 * MARGE_SURE) / PAGE_W, (PAGE_H - 2 * MARGE_SURE) / PAGE_H)
DECAL_X = (PAGE_W - PAGE_W * ECHELLE) / 2.0
DECAL_Y = (PAGE_H - PAGE_H * ECHELLE) / 2.0

# cases : (plage, (x0, y0, x1, y1) px), dans l'ordre où les numéros triés se posent ;
# serie = (alignement, x, ligne de base) px
CARTONS = [
    {'cells': [('G', (60, 90, 189, 196)), ('G', (60, 212, 189, 326)), ('D', (205, 90, 336, 197)), ('D', (205, 212, 336, 326))], 'serie': ('L', 62, 340)},
    {'cells': [('G', (392, 90, 521, 196)), ('G', (392, 212, 521, 326)), ('D', (534, 90, 664, 196)), ('D', (534, 212, 664, 326))], 'serie': ('L', 394, 340)},
    {'cells': [('G', (721, 90, 851, 197)), ('G', (721, 212, 851, 326)), ('D', (865, 90, 995, 196)), ('D', (865, 212, 995, 326))], 'serie': ('L', 723, 340)},
    {'cells': [('G', (60, 449, 189, 555)), ('G', (60, 572, 189, 685)), ('D', (205, 449, 336, 555)), ('D', (205, 572, 336, 685))], 'serie': ('L', 62, 699)},
    {'cells': [('G', (392, 449, 521, 555)), ('G', (392, 572, 520, 685)), ('D', (534, 449, 664, 555)), ('D', (534, 571, 664, 685))], 'serie': ('L', 394, 699)},
    {'cells': [('G', (721, 449, 851, 555)), ('G', (721, 572, 851, 685)), ('D', (865, 449, 995, 555)), ('D', (865, 571, 995, 685))], 'serie': ('L', 723, 699)},
    {'cells': [('G', (60, 811, 189, 917)), ('G', (60, 933, 189, 1047)), ('D', (205, 811, 336, 917)), ('D', (205, 933, 336, 1047))], 'serie': ('L', 62, 1061)},
    {'cells': [('G', (392, 811, 521, 917)), ('G', (392, 933, 520, 1047)), ('D', (534, 811, 664, 917)), ('D', (534, 933, 664, 1047))], 'serie': ('L', 394, 1061)},
    {'cells': [('G', (721, 811, 851, 917)), ('G', (721, 933, 851, 1047)), ('D', (865, 811, 995, 917)), ('D', (865, 933, 995, 1047))], 'serie': ('L', 723, 1061)},
    {'cells': [('G', (60, 1169, 189, 1275)), ('G', (60, 1291, 189, 1406)), ('D', (205, 1169, 336, 1275)), ('D', (205, 1291, 336, 1406))], 'serie': ('L', 62, 1420)},
    {'cells': [('G', (392, 1169, 520, 1275)), ('G', (392, 1291, 520, 1406)), ('D', (534, 1169, 664, 1275)), ('D', (534, 1291, 664, 1406))], 'serie': ('L', 394, 1420)},
    {'cells': [('G', (721, 1169, 851, 1275)), ('G', (721, 1291, 851, 1406)), ('D', (865, 1169, 995, 1275)), ('D', (865, 1291, 995, 1406))], 'serie': ('L', 723, 1420)},
]
AIR_H, AIR_W = 0.62, 0.78
COMPTE = Counter(pl for pl, _c in CARTONS[0]["cells"])


def _px(x):
    return x / _IMG_W * PAGE_W


def _py(y):
    return PAGE_H * (1 - y / _IMG_H)


def _t(c):
    x0, y0, x1, y1 = c
    w, h = _px(x1) - _px(x0), _px(y1) - _px(y0)
    return int(min(AIR_H * h / _CAP, AIR_W * w / (pdfmetrics.stringWidth("88", POLICE, 1.0) + 0.02)) * 2) / 2.0


TAILLE = min(_t(c) for ct in CARTONS for _p, c in ct["cells"])


def _numeros(rng, deja=None):
    while True:
        d = {pl: sorted(rng.sample(range(PLAGES[pl][0], PLAGES[pl][1] + 1), n)) for pl, n in COMPTE.items()}
        cle = tuple((pl, tuple(d[pl])) for pl in sorted(d))
        if deja is None or cle not in deja:
            if deja is not None:
                deja.add(cle)
            return d


def generer_pdf(nb_cartes=None, nb_tickets=None, serie_start=1, theme="", couleur=True,
                nom_evenement="", titre_jeu="", couleur_perso="", date_lieu="",
                telephone="", page_start=1, evenement_id="", style="", motif="",
                _deja=None, **_ig):
    n_ = nb_cartes if nb_cartes is not None else nb_tickets
    n_ = max(1, int(n_ if n_ else CARTES_PAGE))
    buf = io.BytesIO()
    c = canvas.Canvas(buf, pagesize=(PAGE_W, PAGE_H), pageCompression=1)
    c.setTitle("WOW 4 boules")
    rng = random.Random(int(serie_start) * 100003 + 3060)
    deja = _deja if _deja is not None else set()
    serie = int(serie_start)
    faits = 0
    try:
        no_page = max(1, int(page_start))
    except Exception:
        no_page = 1
    col_imposee = None
    if couleur and couleur_perso:
        try:
            col_imposee = colors.HexColor(couleur_perso)
        except Exception:
            col_imposee = None
    while faits < n_:
        c.saveState()
        c.translate(DECAL_X, DECAL_Y)
        c.scale(ECHELLE, ECHELLE)
        try:
            c.drawImage(_IMG_FOND, 0, 0, PAGE_W, PAGE_H, preserveAspectRatio=False, mask="auto")
        except Exception:
            pass
        for idx in range(CARTES_PAGE):
            if faits >= n_:
                break
            ct = CARTONS[idx]
            col = (col_imposee or colors.HexColor(RAINBOW[serie % len(RAINBOW)])) if couleur else NOIR
            nums = _numeros(rng, deja)
            pos = {pl: 0 for pl in nums}
            c.saveState()
            c.setFillColor(col); c.setStrokeColor(col)
            c.setLineWidth(0.5); c.setLineJoin(1)
            for pl, (x0, y0, x1, y1) in ct["cells"]:
                v = str(nums[pl][pos[pl]]); pos[pl] += 1
                o = c.beginText(); o.setTextRenderMode(2); o.setFont(POLICE, TAILLE)
                o.setTextOrigin(_px((x0 + x1) / 2.0) - c.stringWidth(v, POLICE, TAILLE) / 2.0,
                                _py((y0 + y1) / 2.0) - TAILLE * _CAP / 2.0)
                o.textOut(v); c.drawText(o)
            c.restoreState()
            al, sx, sy = ct["serie"]
            c.setFillColor(GRIS_TRAIT)
            c.setFont("Helvetica-Bold", 7 if al == "L" and False else 5.5)
            txt = ("%06d" if False else "N° %06d") % serie
            if al == "R":
                c.drawRightString(_px(sx), _py(sy), txt)
            else:
                c.drawString(_px(sx), _py(sy), txt)
            serie += 1
            faits += 1
        c.restoreState()
        c.setFillColor(GRIS_TRAIT)
        c.setFont("Helvetica", 6)
        c.drawRightString(PAGE_W - 17, PAGE_H - 13, "%d" % no_page)
        no_page += 1
        c.showPage()
    c.save()
    buf.seek(0)
    return buf
