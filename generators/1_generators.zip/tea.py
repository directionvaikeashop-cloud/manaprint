# -*- coding: utf-8 -*-
"""MANAPRINT — TEA (planche de Maeva du 29/09, refait le 19/11/2026).
16 cartons par feuille A4 PAYSAGE. La maquette est reprise TELLE QUELLE comme
fond, en 2 tons francs (rendu propre sur la Konica) ; on n'ajoute que les
chiffres, le n° de série et le n° de page.
Règle : T 35-45 · E 46-56 · A 57-67, deux numéros par colonne, le petit en haut. Six numéros. Crieur 35-67.
Chiffres en Latin Modern (écriture maison), NOIRS, le plus gros possible avec de l'air dans la case.
Feuille ramenée à 6 mm des bords (la Konica n'imprime pas les 4,2 mm du bord)."""
import io, os as _os, random
from reportlab.pdfgen import canvas
from reportlab.lib.pagesizes import A4, landscape
from reportlab.lib import colors

PAGE_W, PAGE_H = landscape(A4)
CARTES_PAGE = 16
PLAGES = [(35, 45), (46, 56), (57, 67)]
PAR_COLONNE = [2, 2, 2]
NOIR = colors.Color(0.08, 0.08, 0.08)
GRIS_TRAIT = colors.Color(0.40, 0.40, 0.40)
RAINBOW = ["#E53935", "#FB8C00", "#F9A825", "#43A047", "#00ACC1",
           "#1E88E5", "#3949AB", "#8E24AA", "#D81B60", "#6D4C41"]
POLICE, _CAP, _LARG88 = "Helvetica-Bold", 0.717, 1.112
# ⭐ 18/11 (Maeva : « ces jeux avaient déjà leurs propres écritures ») :
#    l'écriture maison des planches ÉCO = LATIN MODERN ROMAN (comme RAI, KEA, P6).
try:
    from reportlab.pdfbase import pdfmetrics as _pm
    from reportlab.pdfbase.ttfonts import TTFont as _TF
    import os as _o
    _pm.registerFont(_TF("LMROMAN", _o.path.join(_o.path.dirname(_o.path.abspath(__file__)), "LatinModern.ttf")))
    POLICE, _CAP, _LARG88 = "LMROMAN", 0.644, 1.0
    # ⭐ 19/11 (Maeva : « mets du gras ») : la même écriture en GRAS, comme KEA
    _pm.registerFont(_TF("LMROMANB", _o.path.join(_o.path.dirname(_o.path.abspath(__file__)), "LatinModern-Bold.ttf")))
    POLICE, _CAP, _LARG88 = "LMROMANB", 0.644, 1.15
except Exception:
    pass
_ICI = _os.path.dirname(_os.path.abspath(__file__))
_IMG_W, _IMG_H = 1536.0, 1086.0
_IMG_FOND = _os.path.join(_ICI, "tea_fond.png")
MARGE_SURE = 6 * 72 / 25.4
ECHELLE = min((PAGE_W - 2 * MARGE_SURE) / PAGE_W, (PAGE_H - 2 * MARGE_SURE) / PAGE_H)
DECAL_X = (PAGE_W - PAGE_W * ECHELLE) / 2.0
DECAL_Y = (PAGE_H - PAGE_H * ECHELLE) / 2.0

# pour chaque carton : les cases (x0, y0, x1, y1) px, colonne par colonne,
# de haut en bas ; serie = (x0, y0, x1, y1) px de la place du n° de série.
CARTONS = [
    {'cols': [[(88.0, 102.0, 161.0, 172.0), (87.0, 180.0, 160.0, 251.0)], [(180.0, 102.0, 253.0, 173.0), (179.0, 180.0, 252.0, 251.0)], [(272.0, 103.0, 344.0, 173.0), (271.0, 181.0, 343.0, 251.0)]], 'serie': (222, 265, 371, 278)},
    {'cols': [[(463.0, 102.0, 536.0, 172.0), (461.0, 180.0, 534.0, 251.0)], [(556.0, 102.0, 629.0, 172.0), (556.0, 180.0, 628.0, 251.0)], [(649.0, 102.0, 722.0, 173.0), (649.0, 180.0, 722.0, 251.0)]], 'serie': (600, 265, 749, 278)},
    {'cols': [[(835.0, 102.0, 908.0, 172.0), (833.0, 180.0, 906.0, 251.0)], [(927.0, 102.0, 1001.0, 173.0), (927.0, 180.0, 1000.0, 251.0)], [(1020.0, 102.0, 1093.0, 173.0), (1020.0, 180.0, 1093.0, 251.0)]], 'serie': (976, 265, 1125, 278)},
    {'cols': [[(1217.0, 102.0, 1289.0, 172.0), (1215.0, 180.0, 1288.0, 251.0)], [(1310.0, 102.0, 1383.0, 173.0), (1308.0, 180.0, 1381.0, 251.0)], [(1403.0, 103.0, 1475.0, 173.0), (1402.0, 181.0, 1475.0, 251.0)]], 'serie': (1357, 265, 1506, 278)},
    {'cols': [[(87.0, 363.0, 160.0, 434.0), (86.0, 442.0, 158.0, 512.0)], [(179.0, 363.0, 252.0, 434.0), (178.0, 442.0, 251.0, 512.0)], [(271.0, 364.0, 343.0, 434.0), (271.0, 442.0, 343.0, 512.0)]], 'serie': (222, 525, 371, 538)},
    {'cols': [[(462.0, 363.0, 535.0, 434.0), (460.0, 442.0, 533.0, 512.0)], [(554.0, 363.0, 628.0, 434.0), (553.0, 442.0, 627.0, 512.0)], [(648.0, 364.0, 721.0, 434.0), (647.0, 442.0, 720.0, 512.0)]], 'serie': (600, 526, 749, 539)},
    {'cols': [[(835.0, 363.0, 908.0, 433.0), (833.0, 441.0, 907.0, 511.0)], [(927.0, 363.0, 1000.0, 434.0), (926.0, 442.0, 1000.0, 512.0)], [(1020.0, 363.0, 1093.0, 434.0), (1020.0, 441.0, 1093.0, 512.0)]], 'serie': (976, 526, 1125, 539)},
    {'cols': [[(1216.0, 363.0, 1289.0, 434.0), (1214.0, 442.0, 1287.0, 512.0)], [(1309.0, 363.0, 1382.0, 434.0), (1307.0, 442.0, 1380.0, 512.0)], [(1402.0, 364.0, 1475.0, 434.0), (1401.0, 442.0, 1475.0, 512.0)]], 'serie': (1357, 526, 1506, 539)},
    {'cols': [[(87.0, 623.0, 160.0, 693.0), (85.0, 701.0, 158.0, 770.0)], [(179.0, 624.0, 252.0, 694.0), (178.0, 702.0, 251.0, 771.0)], [(271.0, 625.0, 343.0, 694.0), (271.0, 702.0, 343.0, 771.0)]], 'serie': (222, 784, 371, 798)},
    {'cols': [[(463.0, 624.0, 536.0, 694.0), (462.0, 701.0, 535.0, 771.0)], [(556.0, 625.0, 628.0, 695.0), (554.0, 702.0, 628.0, 772.0)], [(648.0, 626.0, 720.0, 695.0), (648.0, 703.0, 721.0, 772.0)]], 'serie': (600, 785, 747, 798)},
    {'cols': [[(834.0, 625.0, 907.0, 694.0), (833.0, 702.0, 906.0, 769.0)], [(927.0, 624.0, 1000.0, 694.0), (926.0, 702.0, 1000.0, 770.0)], [(1020.0, 624.0, 1093.0, 694.0), (1020.0, 701.0, 1093.0, 770.0)]], 'serie': (976, 785, 1123, 799)},
    {'cols': [[(1216.0, 625.0, 1288.0, 694.0), (1214.0, 702.0, 1287.0, 770.0)], [(1309.0, 625.0, 1382.0, 695.0), (1307.0, 702.0, 1380.0, 771.0)], [(1401.0, 626.0, 1474.0, 695.0), (1401.0, 702.0, 1474.0, 770.0)]], 'serie': (1356, 785, 1503, 799)},
    {'cols': [[(86.0, 882.0, 159.0, 946.0), (85.0, 953.0, 158.0, 1014.0)], [(178.0, 882.0, 251.0, 946.0), (177.0, 954.0, 250.0, 1014.0)], [(269.0, 884.0, 341.0, 946.0), (269.0, 954.0, 341.0, 1014.0)]], 'serie': (223, 1024, 369, 1037)},
    {'cols': [[(465.0, 882.0, 538.0, 946.0), (463.0, 954.0, 537.0, 1014.0)], [(557.0, 882.0, 630.0, 946.0), (557.0, 954.0, 629.0, 1014.0)], [(647.0, 883.0, 720.0, 946.0), (648.0, 953.0, 720.0, 1013.0)]], 'serie': (601, 1025, 747, 1038)},
    {'cols': [[(835.0, 881.0, 908.0, 945.0), (833.0, 953.0, 906.0, 1013.0)], [(928.0, 882.0, 1001.0, 946.0), (926.0, 954.0, 1000.0, 1014.0)], [(1019.0, 882.0, 1092.0, 946.0), (1018.0, 954.0, 1091.0, 1014.0)]], 'serie': (977, 1025, 1123, 1038)},
    {'cols': [[(1218.0, 882.0, 1291.0, 946.0), (1213.0, 954.0, 1287.0, 1014.0)], [(1311.0, 882.0, 1384.0, 946.0), (1307.0, 954.0, 1380.0, 1014.0)], [(1403.0, 884.0, 1475.0, 946.0), (1401.0, 954.0, 1474.0, 1014.0)]], 'serie': (1356, 1026, 1503, 1039)},
]
ALIGN_SERIE = "R"
AIR_H, AIR_W = 0.64, 0.74   # part de la case que « 88 » peut occuper


def _px(x):
    return x / _IMG_W * PAGE_W


def _py(y):
    return PAGE_H * (1 - y / _IMG_H)


def _taille_case(x0, y0, x1, y1):
    h = _px(y1) - _px(y0)
    w = _px(x1) - _px(x0)
    t = min(AIR_H * h / _CAP, AIR_W * w / _LARG88)
    return int(t * 2) / 2.0


# une taille par « famille » de cases (même hauteur), la plus petite de la famille
_TAILLES = {}
for _ct in CARTONS:
    for _col in _ct["cols"]:
        for _c in _col:
            _k = round((_c[3] - _c[1]) / 20.0)
            _TAILLES[_k] = min(_TAILLES.get(_k, 999), _taille_case(*_c))


def _taille(c):
    return _TAILLES[round((c[3] - c[1]) / 20.0)]


def _numeros(rng, deja=None):
    while True:
        d = [sorted(rng.sample(range(a, b + 1), n)) for (a, b), n in zip(PLAGES, PAR_COLONNE)]
        cle = tuple(v for p in d for v in p)
        if deja is None or cle not in deja:
            if deja is not None:
                deja.add(cle)
            return d


def _num(c, txt, x, y, t):
    o = c.beginText()
    o.setTextRenderMode(2)
    o.setFont(POLICE, t)
    o.setTextOrigin(x - c.stringWidth(txt, POLICE, t) / 2.0, y)
    o.textOut(txt)
    c.drawText(o)


def generer_pdf(nb_cartes=None, nb_tickets=None, serie_start=1, theme="", couleur=True,
                nom_evenement="", titre_jeu="", couleur_perso="", date_lieu="",
                telephone="", page_start=1, evenement_id="", style="", motif="",
                _deja=None, **_ig):
    n_ = nb_cartes if nb_cartes is not None else nb_tickets
    n_ = max(1, int(n_ if n_ else CARTES_PAGE))
    buf = io.BytesIO()
    c = canvas.Canvas(buf, pagesize=(PAGE_W, PAGE_H), pageCompression=1)
    c.setTitle("TEA")
    rng = random.Random(int(serie_start) * 100003 + 3567)
    deja = _deja if _deja is not None else set()
    serie = int(serie_start)
    faits = 0
    try:
        no_page = max(1, int(page_start))
    except Exception:
        no_page = 1
    col_imposee = None
    if couleur and couleur_perso:
        try:
            col_imposee = colors.HexColor(couleur_perso)
        except Exception:
            col_imposee = None
    while faits < n_:
        c.saveState()
        c.translate(DECAL_X, DECAL_Y)
        c.scale(ECHELLE, ECHELLE)
        try:
            c.drawImage(_IMG_FOND, 0, 0, PAGE_W, PAGE_H, preserveAspectRatio=False, mask="auto")
        except Exception:
            pass
        entete = "  ·  ".join(t for t in ((nom_evenement or "").strip(),
                                          (date_lieu or "").strip(),
                                          (telephone or "").strip()) if t)
        for idx in range(CARTES_PAGE):
            if faits >= n_:
                break
            ct = CARTONS[idx]
            col = (col_imposee or colors.HexColor(RAINBOW[serie % len(RAINBOW)])) if couleur else NOIR
            nums = _numeros(rng, deja)
            c.saveState()
            c.setFillColor(col)
            c.setStrokeColor(col)
            c.setLineWidth(0.5)
            c.setLineJoin(1)
            for cases, vals in zip(ct["cols"], nums):
                for (x0, y0, x1, y1), v in zip(cases, vals):
                    t = _taille((x0, y0, x1, y1))
                    _num(c, str(v), _px((x0 + x1) / 2.0), _py((y0 + y1) / 2.0) - t * _CAP / 2.0, t)
            c.restoreState()
            sx0, sy0, sx1, sy1 = ct["serie"]
            ts = min(9.0, (_px(sy1) - _px(sy0)) / 0.72)
            c.setFillColor(GRIS_TRAIT)
            c.setFont("Helvetica-Bold", ts)
            if ALIGN_SERIE == "R":
                c.drawRightString(_px(sx1), _py(sy1), "%06d" % serie)
            else:
                c.drawString(_px(sx0), _py(sy1), "%06d" % serie)
            serie += 1
            faits += 1
        c.restoreState()
        # n° de page (et personnalisation) dans la marge que la Konica imprime
        c.setFillColor(GRIS_TRAIT)
        c.setFont("Helvetica", 6)
        c.drawRightString(PAGE_W - 17, PAGE_H - 19, "%03d" % no_page)
        if entete:
            c.setFont("Helvetica-Bold", 6.5)
            c.drawCentredString(PAGE_W / 2.0, PAGE_H - 13.5, entete)
        no_page += 1
        c.showPage()
    c.save()
    buf.seek(0)
    return buf


if __name__ == "__main__":
    open("test.pdf", "wb").write(generer_pdf(nb_cartes=CARTES_PAGE, couleur=False).read())
