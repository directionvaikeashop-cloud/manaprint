# -*- coding: utf-8 -*-
"""MANAPRINT — ALOHA 75 (refait le 18/11/2026 sur la maquette de Maeva).
12 cartons par feuille A4 PORTRAIT. La maquette est reprise TELLE QUELLE comme
fond, en 2 tons francs (rendu propre sur la Konica) ; on n'ajoute que les
chiffres, le n° de série et le n° de page.
Règle : A 1-15 · L 16-30 · O 31-45 · H 46-60 · A 61-75, 2 numéros par colonne, triés du plus petit en haut. Crieur 1-75.
Chiffres en Latin Modern (écriture maison), NOIRS, le plus gros possible avec de l'air dans la case.
Feuille ramenée à 6 mm des bords (la Konica n'imprime pas les 4,2 mm du bord)."""
import io, os as _os, random
from reportlab.pdfgen import canvas
from reportlab.lib.pagesizes import A4, landscape
from reportlab.lib import colors

PAGE_W, PAGE_H = A4
CARTES_PAGE = 12
PLAGES = [(1, 15), (16, 30), (31, 45), (46, 60), (61, 75)]
PAR_COLONNE = [2, 2, 2, 2, 2]
NOIR = colors.Color(0.08, 0.08, 0.08)
GRIS_TRAIT = colors.Color(0.40, 0.40, 0.40)
RAINBOW = ["#E53935", "#FB8C00", "#F9A825", "#43A047", "#00ACC1",
           "#1E88E5", "#3949AB", "#8E24AA", "#D81B60", "#6D4C41"]
POLICE, _CAP, _LARG88 = "Helvetica-Bold", 0.717, 1.112
# ⭐ 18/11 (Maeva : « ces jeux avaient déjà leurs propres écritures ») :
#    l'écriture maison des planches ÉCO = LATIN MODERN ROMAN (comme RAI, KEA, P6).
try:
    from reportlab.pdfbase import pdfmetrics as _pm
    from reportlab.pdfbase.ttfonts import TTFont as _TF
    import os as _o
    _pm.registerFont(_TF("LMROMAN", _o.path.join(_o.path.dirname(_o.path.abspath(__file__)), "LatinModern.ttf")))
    POLICE, _CAP, _LARG88 = "LMROMAN", 0.644, 1.0
except Exception:
    pass
_ICI = _os.path.dirname(_os.path.abspath(__file__))
_IMG_W, _IMG_H = 1489.0, 2105.0
_IMG_FOND = _os.path.join(_ICI, "aloha75_fond_v2.png")
MARGE_SURE = 6 * 72 / 25.4
ECHELLE = min((PAGE_W - 2 * MARGE_SURE) / PAGE_W, (PAGE_H - 2 * MARGE_SURE) / PAGE_H)
DECAL_X = (PAGE_W - PAGE_W * ECHELLE) / 2.0
DECAL_Y = (PAGE_H - PAGE_H * ECHELLE) / 2.0

# pour chaque carton : les cases (x0, y0, x1, y1) px, colonne par colonne,
# de haut en bas ; serie = (x0, y0, x1, y1) px de la place du n° de série.
CARTONS = [
    {'cols': [[(59, 140, 183, 237), (59, 250, 183, 347)], [(190, 140, 314, 237), (190, 250, 314, 347)], [(321, 140, 445, 237), (321, 250, 445, 347)], [(451, 140, 575, 237), (451, 250, 575, 347)], [(582, 140, 706, 237), (582, 250, 706, 347)]], 'serie': (79, 57, 134, 76)},
    {'cols': [[(782, 140, 906, 237), (782, 250, 906, 347)], [(913, 140, 1037, 237), (913, 250, 1037, 347)], [(1043, 140, 1168, 237), (1043, 250, 1168, 347)], [(1174, 140, 1298, 237), (1174, 250, 1298, 347)], [(1305, 140, 1429, 237), (1305, 250, 1429, 347)]], 'serie': (802, 57, 857, 76)},
    {'cols': [[(59, 480, 183, 576), (59, 590, 183, 686)], [(190, 480, 314, 576), (190, 590, 314, 686)], [(321, 480, 445, 576), (321, 590, 445, 686)], [(451, 480, 575, 576), (451, 590, 575, 686)], [(582, 480, 706, 576), (582, 590, 706, 686)]], 'serie': (79, 396, 134, 415)},
    {'cols': [[(782, 480, 906, 576), (782, 590, 906, 686)], [(913, 480, 1037, 576), (913, 590, 1037, 686)], [(1043, 480, 1168, 576), (1043, 590, 1168, 686)], [(1174, 480, 1298, 576), (1174, 590, 1298, 686)], [(1305, 480, 1429, 576), (1305, 590, 1429, 686)]], 'serie': (802, 396, 857, 415)},
    {'cols': [[(59, 820, 183, 916), (59, 929, 183, 1026)], [(190, 820, 314, 916), (190, 929, 314, 1026)], [(321, 820, 445, 916), (321, 929, 445, 1026)], [(451, 820, 575, 916), (451, 929, 575, 1026)], [(582, 820, 706, 916), (582, 929, 706, 1026)]], 'serie': (79, 736, 134, 755)},
    {'cols': [[(782, 820, 906, 916), (782, 929, 906, 1026)], [(913, 820, 1037, 916), (913, 929, 1037, 1026)], [(1043, 820, 1168, 916), (1043, 929, 1168, 1026)], [(1174, 820, 1298, 916), (1174, 929, 1298, 1026)], [(1305, 820, 1429, 916), (1305, 929, 1429, 1026)]], 'serie': (802, 736, 857, 755)},
    {'cols': [[(59, 1159, 183, 1255), (59, 1269, 183, 1365)], [(190, 1159, 314, 1255), (190, 1269, 314, 1365)], [(321, 1159, 445, 1255), (321, 1269, 445, 1365)], [(451, 1159, 575, 1255), (451, 1269, 575, 1365)], [(582, 1159, 706, 1255), (582, 1269, 706, 1365)]], 'serie': (79, 1075, 134, 1094)},
    {'cols': [[(782, 1159, 906, 1255), (782, 1269, 906, 1365)], [(913, 1159, 1037, 1255), (913, 1269, 1037, 1365)], [(1043, 1159, 1168, 1255), (1043, 1269, 1168, 1365)], [(1174, 1159, 1298, 1255), (1174, 1269, 1298, 1365)], [(1305, 1159, 1429, 1255), (1305, 1269, 1429, 1365)]], 'serie': (802, 1075, 857, 1094)},
    {'cols': [[(59, 1499, 183, 1595), (59, 1609, 183, 1705)], [(190, 1499, 314, 1595), (190, 1609, 314, 1705)], [(321, 1499, 445, 1595), (321, 1609, 445, 1705)], [(451, 1499, 575, 1595), (451, 1609, 575, 1705)], [(582, 1499, 706, 1595), (582, 1609, 706, 1705)]], 'serie': (79, 1415, 134, 1434)},
    {'cols': [[(782, 1499, 906, 1595), (782, 1609, 906, 1705)], [(913, 1499, 1037, 1595), (913, 1609, 1037, 1705)], [(1043, 1499, 1168, 1595), (1043, 1609, 1168, 1705)], [(1174, 1499, 1298, 1595), (1174, 1609, 1298, 1705)], [(1305, 1499, 1429, 1595), (1305, 1609, 1429, 1705)]], 'serie': (802, 1415, 857, 1434)},
    {'cols': [[(59, 1838, 183, 1934), (59, 1948, 183, 2044)], [(190, 1838, 314, 1934), (190, 1948, 314, 2044)], [(321, 1838, 445, 1934), (321, 1948, 445, 2044)], [(451, 1838, 575, 1934), (451, 1948, 575, 2044)], [(582, 1838, 706, 1934), (582, 1948, 706, 2044)]], 'serie': (79, 1755, 134, 1774)},
    {'cols': [[(782, 1838, 906, 1934), (782, 1948, 906, 2044)], [(913, 1838, 1037, 1934), (913, 1948, 1037, 2044)], [(1043, 1838, 1168, 1934), (1043, 1948, 1168, 2044)], [(1174, 1838, 1298, 1934), (1174, 1948, 1298, 2044)], [(1305, 1838, 1429, 1934), (1305, 1948, 1429, 2044)]], 'serie': (802, 1755, 857, 1774)},
]
ALIGN_SERIE = "L"
AIR_H, AIR_W = 0.60, 0.70   # part de la case que « 88 » peut occuper


def _px(x):
    return x / _IMG_W * PAGE_W


def _py(y):
    return PAGE_H * (1 - y / _IMG_H)


def _taille_case(x0, y0, x1, y1):
    h = _px(y1) - _px(y0)
    w = _px(x1) - _px(x0)
    t = min(AIR_H * h / _CAP, AIR_W * w / _LARG88)
    return int(t * 2) / 2.0


# une taille par « famille » de cases (même hauteur), la plus petite de la famille
_TAILLES = {}
for _ct in CARTONS:
    for _col in _ct["cols"]:
        for _c in _col:
            _k = round((_c[3] - _c[1]) / 20.0)
            _TAILLES[_k] = min(_TAILLES.get(_k, 999), _taille_case(*_c))


def _taille(c):
    return _TAILLES[round((c[3] - c[1]) / 20.0)]


def _numeros(rng, deja=None):
    while True:
        d = [sorted(rng.sample(range(a, b + 1), n)) for (a, b), n in zip(PLAGES, PAR_COLONNE)]
        cle = tuple(v for p in d for v in p)
        if deja is None or cle not in deja:
            if deja is not None:
                deja.add(cle)
            return d


def _num(c, txt, x, y, t):
    o = c.beginText()
    o.setTextRenderMode(2)
    o.setFont(POLICE, t)
    o.setTextOrigin(x - c.stringWidth(txt, POLICE, t) / 2.0, y)
    o.textOut(txt)
    c.drawText(o)


def generer_pdf(nb_cartes=None, nb_tickets=None, serie_start=1, theme="", couleur=True,
                nom_evenement="", titre_jeu="", couleur_perso="", date_lieu="",
                telephone="", page_start=1, evenement_id="", style="", motif="",
                _deja=None, **_ig):
    n_ = nb_cartes if nb_cartes is not None else nb_tickets
    n_ = max(1, int(n_ if n_ else CARTES_PAGE))
    buf = io.BytesIO()
    c = canvas.Canvas(buf, pagesize=(PAGE_W, PAGE_H), pageCompression=1)
    c.setTitle("ALOHA 75")
    rng = random.Random(int(serie_start) * 100003 + 7501)
    deja = _deja if _deja is not None else set()
    serie = int(serie_start)
    faits = 0
    try:
        no_page = max(1, int(page_start))
    except Exception:
        no_page = 1
    col_imposee = None
    if couleur and couleur_perso:
        try:
            col_imposee = colors.HexColor(couleur_perso)
        except Exception:
            col_imposee = None
    while faits < n_:
        c.saveState()
        c.translate(DECAL_X, DECAL_Y)
        c.scale(ECHELLE, ECHELLE)
        try:
            c.drawImage(_IMG_FOND, 0, 0, PAGE_W, PAGE_H, preserveAspectRatio=False, mask="auto")
        except Exception:
            pass
        entete = "  ·  ".join(t for t in ((nom_evenement or "").strip(),
                                          (date_lieu or "").strip(),
                                          (telephone or "").strip()) if t)
        for idx in range(CARTES_PAGE):
            if faits >= n_:
                break
            ct = CARTONS[idx]
            col = (col_imposee or colors.HexColor(RAINBOW[serie % len(RAINBOW)])) if couleur else NOIR
            nums = _numeros(rng, deja)
            c.saveState()
            c.setFillColor(col)
            c.setStrokeColor(col)
            c.setLineWidth(0.25)
            c.setLineJoin(1)
            for cases, vals in zip(ct["cols"], nums):
                for (x0, y0, x1, y1), v in zip(cases, vals):
                    t = _taille((x0, y0, x1, y1))
                    _num(c, str(v), _px((x0 + x1) / 2.0), _py((y0 + y1) / 2.0) - t * _CAP / 2.0, t)
            c.restoreState()
            sx0, sy0, sx1, sy1 = ct["serie"]
            ts = min(9.0, (_px(sy1) - _px(sy0)) / 0.72)
            c.setFillColor(GRIS_TRAIT)
            c.setFont("Helvetica-Bold", ts)
            if ALIGN_SERIE == "R":
                c.drawRightString(_px(sx1), _py(sy1), "%06d" % serie)
            else:
                c.drawString(_px(sx0), _py(sy1), "%06d" % serie)
            serie += 1
            faits += 1
        c.restoreState()
        # n° de page (et personnalisation) dans la marge que la Konica imprime
        c.setFillColor(GRIS_TRAIT)
        c.setFont("Helvetica", 6)
        c.drawRightString(PAGE_W - 17, PAGE_H - 19, "%d" % no_page)
        if entete:
            c.setFont("Helvetica-Bold", 6.5)
            c.drawCentredString(PAGE_W / 2.0, PAGE_H - 13.5, entete)
        no_page += 1
        c.showPage()
    c.save()
    buf.seek(0)
    return buf


if __name__ == "__main__":
    open("test.pdf", "wb").write(generer_pdf(nb_cartes=CARTES_PAGE, couleur=False).read())
