# -*- coding: utf-8 -*-
"""MANAPRINT — RUBIS 75 (planche de Maeva, refait le 19/11/2026).
9 cartons par feuille A4 PAYSAGE. La planche est reprise TELLE QUELLE comme fond
(trait gris uni, sans aplat gris taché) ; on n'ajoute que les chiffres, le n° de
série et le n° de page.
Règle : R 1-15 · U 16-30 · B 31-45 (2 numéros, la case du milieu reste libre) · I 46-60 · S 61-75, triés du plus petit en haut. Crieur 1-75.
Chiffres Latin Modern GRAS, noirs, le plus gros que chaque case permet.
Feuille ramenée à 6 mm des bords (Konica)."""
import io, os as _os, random
from collections import Counter
from reportlab.pdfgen import canvas
from reportlab.lib.pagesizes import A4, landscape
from reportlab.lib import colors
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont

PAGE_W, PAGE_H = landscape(A4)
CARTES_PAGE = 9
PLAGES = {'R': (1, 15), 'U': (16, 30), 'B': (31, 45), 'I': (46, 60), 'S': (61, 75)}
NOIR = colors.Color(0.05, 0.05, 0.05)
GRIS_TRAIT = colors.Color(0.40, 0.40, 0.40)
RAINBOW = ["#E53935", "#FB8C00", "#F9A825", "#43A047", "#00ACC1",
           "#1E88E5", "#3949AB", "#8E24AA", "#D81B60", "#6D4C41"]
_ICI = _os.path.dirname(_os.path.abspath(__file__))
POLICE, _CAP = "Helvetica-Bold", 0.717
try:
    pdfmetrics.registerFont(TTFont("LMROMANB", _os.path.join(_ICI, "LatinModern-Bold.ttf")))
    POLICE, _CAP = "LMROMANB", 0.66
except Exception:
    pass
_IMG_W, _IMG_H = 1536.0, 1086.0
_IMG_FOND = _os.path.join(_ICI, "rubis75_fond.png")
MARGE_SURE = 6 * 72 / 25.4
ECHELLE = min((PAGE_W - 2 * MARGE_SURE) / PAGE_W, (PAGE_H - 2 * MARGE_SURE) / PAGE_H)
DECAL_X = (PAGE_W - PAGE_W * ECHELLE) / 2.0
DECAL_Y = (PAGE_H - PAGE_H * ECHELLE) / 2.0

# cases : (plage, (x0, y0, x1, y1) px), dans l'ordre où les numéros triés se posent ;
# serie = (alignement, x, ligne de base) px
CARTONS = [
    {'cells': [('R', (41, 165, 124, 220)), ('R', (42, 230, 124, 284)), ('R', (42, 294, 124, 349)), ('U', (133, 165, 217, 220)), ('U', (133, 230, 217, 284)), ('U', (133, 294, 216, 349)), ('B', (225, 165, 309, 220)), ('B', (226, 294, 309, 349)), ('I', (319, 165, 402, 220)), ('I', (319, 230, 402, 284)), ('I', (319, 294, 402, 349)), ('S', (411, 165, 495, 220)), ('S', (411, 230, 495, 284)), ('S', (411, 294, 495, 349))], 'serie': ('L', 77, 73)},
    {'cells': [('R', (542, 165, 624, 220)), ('R', (543, 230, 624, 284)), ('R', (543, 295, 624, 349)), ('U', (634, 165, 717, 220)), ('U', (634, 230, 717, 284)), ('U', (634, 295, 717, 350)), ('B', (726, 165, 809, 220)), ('B', (726, 295, 809, 350)), ('I', (818, 165, 902, 220)), ('I', (818, 230, 902, 284)), ('I', (818, 295, 902, 349)), ('S', (912, 165, 994, 220)), ('S', (912, 230, 994, 284)), ('S', (912, 295, 994, 349))], 'serie': ('L', 578, 73)},
    {'cells': [('R', (1041, 165, 1124, 220)), ('R', (1041, 230, 1124, 284)), ('R', (1041, 295, 1124, 350)), ('U', (1133, 165, 1216, 220)), ('U', (1133, 230, 1216, 284)), ('U', (1133, 295, 1216, 350)), ('B', (1225, 165, 1308, 220)), ('B', (1225, 295, 1308, 350)), ('I', (1317, 165, 1400, 220)), ('I', (1317, 230, 1400, 284)), ('I', (1317, 295, 1400, 350)), ('S', (1409, 165, 1494, 220)), ('S', (1409, 230, 1494, 284)), ('S', (1409, 295, 1494, 350))], 'serie': ('L', 1077, 73)},
    {'cells': [('R', (42, 509, 125, 563)), ('R', (42, 574, 124, 628)), ('R', (42, 639, 124, 693)), ('U', (134, 509, 217, 563)), ('U', (134, 574, 217, 628)), ('U', (134, 639, 217, 693)), ('B', (226, 509, 309, 563)), ('B', (226, 639, 309, 693)), ('I', (319, 509, 402, 563)), ('I', (319, 574, 402, 628)), ('I', (319, 639, 402, 693)), ('S', (411, 509, 496, 563)), ('S', (412, 574, 496, 628)), ('S', (412, 639, 496, 693))], 'serie': ('L', 78, 417)},
    {'cells': [('R', (543, 510, 624, 564)), ('R', (543, 575, 624, 628)), ('R', (543, 640, 625, 693)), ('U', (634, 510, 716, 564)), ('U', (634, 575, 716, 628)), ('U', (634, 639, 717, 693)), ('B', (726, 510, 809, 564)), ('B', (726, 639, 809, 693)), ('I', (818, 510, 902, 564)), ('I', (818, 575, 902, 628)), ('I', (818, 639, 902, 693)), ('S', (912, 510, 994, 564)), ('S', (912, 575, 994, 628)), ('S', (912, 639, 994, 693))], 'serie': ('L', 579, 418)},
    {'cells': [('R', (1041, 510, 1124, 564)), ('R', (1041, 575, 1124, 628)), ('R', (1041, 640, 1124, 693)), ('U', (1133, 510, 1216, 564)), ('U', (1133, 575, 1216, 628)), ('U', (1133, 639, 1216, 693)), ('B', (1225, 510, 1308, 564)), ('B', (1225, 639, 1308, 693)), ('I', (1318, 510, 1400, 564)), ('I', (1317, 575, 1400, 628)), ('I', (1317, 640, 1400, 693)), ('S', (1409, 510, 1494, 564)), ('S', (1409, 575, 1494, 628)), ('S', (1410, 640, 1494, 693))], 'serie': ('L', 1077, 418)},
    {'cells': [('R', (42, 845, 125, 899)), ('R', (42, 910, 125, 964)), ('R', (42, 974, 125, 1029)), ('U', (134, 845, 217, 899)), ('U', (134, 910, 217, 964)), ('U', (134, 974, 217, 1029)), ('B', (225, 845, 309, 900)), ('B', (225, 974, 309, 1029)), ('I', (319, 845, 402, 899)), ('I', (319, 910, 402, 964)), ('I', (319, 974, 402, 1029)), ('S', (411, 844, 495, 899)), ('S', (411, 910, 495, 965)), ('S', (411, 975, 495, 1029))], 'serie': ('L', 78, 753)},
    {'cells': [('R', (542, 845, 625, 899)), ('R', (542, 910, 625, 965)), ('R', (542, 975, 625, 1029)), ('U', (634, 845, 716, 899)), ('U', (634, 910, 716, 965)), ('U', (634, 975, 716, 1029)), ('B', (726, 845, 809, 899)), ('B', (726, 974, 809, 1029)), ('I', (818, 845, 902, 899)), ('I', (818, 910, 902, 964)), ('I', (818, 975, 902, 1029)), ('S', (911, 845, 994, 899)), ('S', (911, 910, 993, 965)), ('S', (911, 975, 993, 1029))], 'serie': ('L', 578, 753)},
    {'cells': [('R', (1041, 845, 1124, 899)), ('R', (1041, 910, 1124, 964)), ('R', (1041, 975, 1124, 1029)), ('U', (1133, 845, 1216, 899)), ('U', (1133, 910, 1216, 964)), ('U', (1133, 974, 1216, 1029)), ('B', (1225, 845, 1308, 899)), ('B', (1225, 974, 1308, 1029)), ('I', (1318, 845, 1400, 899)), ('I', (1317, 910, 1400, 964)), ('I', (1317, 974, 1400, 1029)), ('S', (1409, 845, 1494, 899)), ('S', (1409, 910, 1494, 964)), ('S', (1409, 975, 1494, 1029))], 'serie': ('L', 1077, 753)},
]
AIR_H, AIR_W = 0.62, 0.78
COMPTE = Counter(pl for pl, _c in CARTONS[0]["cells"])


def _px(x):
    return x / _IMG_W * PAGE_W


def _py(y):
    return PAGE_H * (1 - y / _IMG_H)


def _t(c):
    x0, y0, x1, y1 = c
    w, h = _px(x1) - _px(x0), _px(y1) - _px(y0)
    return int(min(AIR_H * h / _CAP, AIR_W * w / (pdfmetrics.stringWidth("88", POLICE, 1.0) + 0.02)) * 2) / 2.0


TAILLE = min(_t(c) for ct in CARTONS for _p, c in ct["cells"])


def _numeros(rng, deja=None):
    while True:
        d = {pl: sorted(rng.sample(range(PLAGES[pl][0], PLAGES[pl][1] + 1), n)) for pl, n in COMPTE.items()}
        cle = tuple((pl, tuple(d[pl])) for pl in sorted(d))
        if deja is None or cle not in deja:
            if deja is not None:
                deja.add(cle)
            return d


def generer_pdf(nb_cartes=None, nb_tickets=None, serie_start=1, theme="", couleur=True,
                nom_evenement="", titre_jeu="", couleur_perso="", date_lieu="",
                telephone="", page_start=1, evenement_id="", style="", motif="",
                _deja=None, **_ig):
    n_ = nb_cartes if nb_cartes is not None else nb_tickets
    n_ = max(1, int(n_ if n_ else CARTES_PAGE))
    buf = io.BytesIO()
    c = canvas.Canvas(buf, pagesize=(PAGE_W, PAGE_H), pageCompression=1)
    c.setTitle("RUBIS 75")
    rng = random.Random(int(serie_start) * 100003 + 7515)
    deja = _deja if _deja is not None else set()
    serie = int(serie_start)
    faits = 0
    try:
        no_page = max(1, int(page_start))
    except Exception:
        no_page = 1
    col_imposee = None
    if couleur and couleur_perso:
        try:
            col_imposee = colors.HexColor(couleur_perso)
        except Exception:
            col_imposee = None
    while faits < n_:
        c.saveState()
        c.translate(DECAL_X, DECAL_Y)
        c.scale(ECHELLE, ECHELLE)
        try:
            c.drawImage(_IMG_FOND, 0, 0, PAGE_W, PAGE_H, preserveAspectRatio=False, mask="auto")
        except Exception:
            pass
        for idx in range(CARTES_PAGE):
            if faits >= n_:
                break
            ct = CARTONS[idx]
            col = (col_imposee or colors.HexColor(RAINBOW[serie % len(RAINBOW)])) if couleur else NOIR
            nums = _numeros(rng, deja)
            pos = {pl: 0 for pl in nums}
            c.saveState()
            c.setFillColor(col); c.setStrokeColor(col)
            c.setLineWidth(0.5); c.setLineJoin(1)
            for pl, (x0, y0, x1, y1) in ct["cells"]:
                v = str(nums[pl][pos[pl]]); pos[pl] += 1
                o = c.beginText(); o.setTextRenderMode(2); o.setFont(POLICE, TAILLE)
                o.setTextOrigin(_px((x0 + x1) / 2.0) - c.stringWidth(v, POLICE, TAILLE) / 2.0,
                                _py((y0 + y1) / 2.0) - TAILLE * _CAP / 2.0)
                o.textOut(v); c.drawText(o)
            c.restoreState()
            al, sx, sy = ct["serie"]
            c.setFillColor(GRIS_TRAIT)
            c.setFont("Helvetica-Bold", 7 if al == "L" and True else 5.5)
            txt = ("%06d" if True else "N° %06d") % serie
            if al == "R":
                c.drawRightString(_px(sx), _py(sy), txt)
            else:
                c.drawString(_px(sx), _py(sy), txt)
            serie += 1
            faits += 1
        c.restoreState()
        c.setFillColor(GRIS_TRAIT)
        c.setFont("Helvetica", 6)
        c.drawRightString(PAGE_W - 17, PAGE_H - 13, "%d" % no_page)
        no_page += 1
        c.showPage()
    c.save()
    buf.seek(0)
    return buf
