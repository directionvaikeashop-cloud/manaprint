# -*- coding: utf-8 -*-
"""MANAPRINT — BRIQUET · 7 boules (création 2KEA & Associé, maquette Maeva 08/11).
Refait le 19/11/2026. 8 cartons / feuille A4 PORTRAIT. La maquette est reprise
TELLE QUELLE comme fond (n° imprimé gommé, 2 tons francs pour la Konica) ; on
n'ajoute que les chiffres, le n° de série et le n° de page.
7 flammes lues par colonne de gauche à droite : B 1 · I 2 · N 1 · G 2 · O 1
   1-15 · 16-30 · 31-45 · 46-60 · 61-75 (les deux d'une colonne : le petit en haut)
   -> crieur 1 à 75.
Chiffres League Gothic épaissi, le plus gros que la plus petite flamme permet."""
import io, os as _os, random
from reportlab.pdfgen import canvas
from reportlab.lib.pagesizes import A4
from reportlab.lib import colors
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont

PAGE_W, PAGE_H = A4
CARTES_PAGE = 8
PLAGES = [(1, 15), (16, 30), (31, 45), (46, 60), (61, 75)]
PAR_COLONNE = [1, 2, 1, 2, 1]
NOIR = colors.Color(0.10, 0.10, 0.10)
GRIS_TRAIT = colors.Color(0.40, 0.40, 0.40)
RAINBOW = ["#E53935", "#FB8C00", "#F9A825", "#43A047", "#00ACC1",
           "#1E88E5", "#3949AB", "#8E24AA", "#D81B60", "#6D4C41"]
_ICI = _os.path.dirname(_os.path.abspath(__file__))
POLICE, _CAP = "Helvetica-Bold", 0.717
try:
    pdfmetrics.registerFont(TTFont("LGOTH", _os.path.join(_ICI, "LeagueGothic-Regular_v2.ttf")))
    POLICE, _CAP = "LGOTH", 0.735
except Exception:
    pass
_EPAIS = 0.6
_IMG_W, _IMG_H = 1055.0, 1491.0
_IMG_FOND = _os.path.join(_ICI, "briquet_fond.png")
MARGE_SURE = 6 * 72 / 25.4
ECHELLE = min((PAGE_W - 2 * MARGE_SURE) / PAGE_W, (PAGE_H - 2 * MARGE_SURE) / PAGE_H)
DECAL_X = (PAGE_W - PAGE_W * ECHELLE) / 2.0
DECAL_Y = (PAGE_H - PAGE_H * ECHELLE) / 2.0

# flammes : (cx, cy, largeur, hauteur) px du cercle libre au cœur de la flamme, colonne par colonne ; serie = place du n° imprimé
CARTONS = [
    {'cols': [[(110, 224, 95, 83.0)], [(196, 135, 91, 80.2), (185, 312, 91, 76.8)], [(269, 225, 96, 83.0)], [(357, 135, 91, 76.4), (353, 311, 95, 76.0)], [(433, 226, 97, 81.6)]], 'serie': (75, 17, 171, 42)},
    {'cols': [[(630, 225, 94, 82.0)], [(713, 136, 86, 77.4), (704, 312, 90, 76.0)], [(786, 226, 94, 80.6)], [(871, 136, 93, 79.6), (867, 311, 93, 76.0)], [(947, 225, 96, 81.6)]], 'serie': (599, 17, 699, 41)},
    {'cols': [[(110, 598, 96, 83.0)], [(196, 510, 93, 80.0), (185, 685, 91, 76.2)], [(270, 599, 96, 82.2)], [(358, 509, 90, 77.4), (354, 684, 94, 76.0)], [(434, 599, 97, 80.2)]], 'serie': (76, 390, 175, 416)},
    {'cols': [[(630, 598, 95, 81.6)], [(713, 510, 87, 77.4), (704, 685, 90, 74.6)], [(786, 598, 94, 80.2)], [(872, 510, 94, 79.2), (868, 684, 93, 76.0)], [(949, 599, 96, 80.0)]], 'serie': (600, 391, 701, 416)},
    {'cols': [[(110, 972, 97, 84.0)], [(196, 882, 93, 80.2), (185, 1058, 91, 76.2)], [(269, 972, 95, 83.0)], [(358, 882, 90, 77.4), (353, 1057, 94, 76.0)], [(433, 974, 97, 81.6)]], 'serie': (75, 762, 175, 787)},
    {'cols': [[(629, 973, 94, 82.0)], [(714, 884, 87, 78.0), (704, 1058, 89, 76.0)], [(786, 973, 94, 81.2)], [(872, 883, 93, 80.0), (867, 1057, 93, 76.0)], [(948, 973, 96, 80.2)]], 'serie': (600, 762, 701, 787)},
    {'cols': [[(110, 1343, 96, 83.0)], [(197, 1254, 93, 80.2), (184, 1428, 91, 76.0)], [(270, 1344, 97, 83.0)], [(359, 1254, 91, 78.0), (353, 1427, 95, 74.8)], [(434, 1345, 97, 81.6)]], 'serie': (76, 1135, 176, 1160)},
    {'cols': [[(630, 1343, 94, 81.6)], [(714, 1255, 87, 77.4), (704, 1428, 91, 74.6)], [(786, 1344, 94, 80.6)], [(872, 1254, 94, 79.0), (867, 1427, 93, 74.6)], [(949, 1344, 96, 80.2)]], 'serie': (600, 1135, 701, 1160)},
]


def _px(x):
    return x / _IMG_W * PAGE_W


def _py(y):
    return PAGE_H * (1 - y / _IMG_H)


def _taille_max():
    # « 88 » doit tenir dans la plus petite boule (ellipse intérieure, 7 px d'air)
    a = min(e[2] for ct in CARTONS for col in ct["cols"] for e in col) / 2.0 - 7
    b = min(e[3] for ct in CARTONS for col in ct["cols"] for e in col) / 2.0 - 7
    a, b = _px(a) - _px(0), _px(b) - _px(0)
    t = 10.0
    while True:
        t2 = t + 0.5
        w = pdfmetrics.stringWidth("88", POLICE, t2) / 2.0 + _EPAIS
        h = t2 * _CAP / 2.0 + _EPAIS
        if (w / a) ** 2 + (h / b) ** 2 > 1.0:
            return t
        t = t2


TAILLE = _taille_max()   # 19/11 : au maximum (Maeva)


def _numeros(rng, deja=None):
    while True:
        d = [sorted(rng.sample(range(lo, hi + 1), n)) for (lo, hi), n in zip(PLAGES, PAR_COLONNE)]
        cle = tuple(v for p in d for v in p)
        if deja is None or cle not in deja:
            if deja is not None:
                deja.add(cle)
            return d


def _chiffre(c, x, y, txt, t):
    c.saveState()
    c.setStrokeColor(c._fillColorObj)
    c.setLineWidth(_EPAIS)
    c.setLineJoin(1)
    o = c.beginText()
    o.setTextRenderMode(2)
    o.setFont(POLICE, t)
    o.setTextOrigin(x - c.stringWidth(txt, POLICE, t) / 2.0, y)
    o.textOut(txt)
    c.drawText(o)
    c.restoreState()


def generer_pdf(nb_cartes=None, nb_tickets=None, serie_start=1, theme="", couleur=True,
                nom_evenement="", titre_jeu="", couleur_perso="", date_lieu="",
                telephone="", page_start=1, evenement_id="", style="", motif="",
                _deja=None, **_ig):
    n_ = nb_cartes if nb_cartes is not None else nb_tickets
    n_ = max(1, int(n_ if n_ else CARTES_PAGE))
    buf = io.BytesIO()
    c = canvas.Canvas(buf, pagesize=(PAGE_W, PAGE_H), pageCompression=1)
    c.setTitle("BRIQUET")
    rng = random.Random(int(serie_start) * 100003 + 7171)
    deja = _deja if _deja is not None else set()
    serie = int(serie_start)
    faits = 0
    try:
        no_page = max(1, int(page_start))
    except Exception:
        no_page = 1
    col_imposee = None
    if couleur and couleur_perso:
        try:
            col_imposee = colors.HexColor(couleur_perso)
        except Exception:
            col_imposee = None
    while faits < n_:
        c.saveState()
        c.translate(DECAL_X, DECAL_Y)
        c.scale(ECHELLE, ECHELLE)
        try:
            c.drawImage(_IMG_FOND, 0, 0, PAGE_W, PAGE_H, preserveAspectRatio=False, mask="auto")
        except Exception:
            pass
        for idx in range(CARTES_PAGE):
            if faits >= n_:
                break
            ct = CARTONS[idx]
            col = (col_imposee or colors.HexColor(RAINBOW[serie % len(RAINBOW)])) if couleur else NOIR
            nums = _numeros(rng, deja)
            c.setFillColor(col)
            for boules, vals in zip(ct["cols"], nums):
                for (x, y, w, h), v in zip(boules, vals):
                    _chiffre(c, _px(x), _py(y) - TAILLE * _CAP / 2.0, str(v), TAILLE)
            sx0, sy0, sx1, sy1 = ct["serie"]
            ts = (_px(sy1) - _px(sy0)) / 0.72
            c.setFillColor(NOIR)
            c.setFont("Helvetica-Bold", ts)
            c.drawString(_px(sx0), _py(sy1), "%06d" % serie)
            serie += 1
            faits += 1
        c.restoreState()
        c.setFillColor(GRIS_TRAIT)
        c.setFont("Helvetica", 6)
        c.drawRightString(PAGE_W - 17, PAGE_H - 19, "%d" % no_page)
        no_page += 1
        c.showPage()
    c.save()
    buf.seek(0)
    return buf
