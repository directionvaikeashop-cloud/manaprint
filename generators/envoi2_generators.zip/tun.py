# -*- coding: utf-8 -*-
"""MANAPRINT — TUN (maquette de Maeva du 18/11/2026).
16 cartons / feuille A4 PAYSAGE (4 x 4). La maquette est reprise TELLE QUELLE
comme fond (traits passés en gris) ; on n'ajoute que les chiffres et le n° de série.
3 bulles pointillées par carton, DEUX numéros par bulle (le plus petit en haut) :
   bulle 1 : 1-10 · bulle 2 : 11-20 · bulle 3 : 21-30 -> 6 numéros, crieur 1 à 30.
91 125 cartons différents possibles (45 x 45 x 45).
Chiffres Helvetica-Bold (comme le modèle rempli), le plus gros que la bulle permet.
⭐ 18/11 (impression Konica) : fond nettoyé en 2 tons francs — les pastilles
grises de la maquette sortaient en taches marbrées ; elles sont maintenant
blanches, cerclées du trait gris. Chiffres légèrement épaissis.
Feuille ramenée à 6 mm des bords (la Konica n'imprime pas les 4,2 mm du bord)."""
import io, os as _os, random
from reportlab.pdfgen import canvas
from reportlab.lib.pagesizes import A4, landscape
from reportlab.lib import colors

PAGE_W, PAGE_H = landscape(A4)
CARTES_PAGE = 16
NOIR = colors.Color(0.10, 0.10, 0.10)
GRIS_TRAIT = colors.Color(105 / 255.0, 105 / 255.0, 105 / 255.0)
RAINBOW = ["#E53935", "#FB8C00", "#F9A825", "#43A047", "#00ACC1",
           "#1E88E5", "#3949AB", "#8E24AA", "#D81B60", "#6D4C41"]
PLAGES = [(1, 10), (11, 20), (21, 30)]

_ICI = _os.path.dirname(_os.path.abspath(__file__))
POLICE, _CAP = "Helvetica-Bold", 0.717
_IMG_W, _IMG_H = 1536.0, 1024.0
_IMG_FOND = _os.path.join(_ICI, "tun_fond.png")

MARGE_SURE = 6 * 72 / 25.4
ECHELLE = min((PAGE_W - 2 * MARGE_SURE) / PAGE_W, (PAGE_H - 2 * MARGE_SURE) / PAGE_H)
DECAL_X = (PAGE_W - PAGE_W * ECHELLE) / 2.0
DECAL_Y = (PAGE_H - PAGE_H * ECHELLE) / 2.0

# ⭐ 18/11 (Maeva : « le numéro de téléphone fait mal aux yeux ») : le « Tél »
#    de la maquette (écriture écrasée, baveuse à l'impression) est GOMMÉ du fond
#    et réécrit en vrai texte net, à la même place.
TEL_BOX = [(28, 215, 191, 235), (412, 215, 575, 235), (796, 215, 959, 235), (1180, 215, 1343, 235), (28, 471, 191, 491), (412, 471, 575, 491), (796, 471, 959, 491), (1180, 471, 1344, 491), (28, 727, 191, 747), (412, 727, 575, 747), (796, 727, 959, 747), (1180, 727, 1344, 747), (28, 975, 191, 995), (412, 975, 575, 995), (796, 975, 959, 995), (1180, 975, 1344, 995)]
TEL_DEFAUT = "89 22 23 05"

# pour chaque carton : les 3 bulles (x, y, rayon intérieur) px ;
# serie = (x bord droit, ligne de base) px du n° de série, en bas à droite.
CARTONS = [
    {'ronds': [(75.6, 156.5, 48.8), (192.8, 156.6, 49.0), (311.2, 157.0, 49.0)], 'serie': (368.2, 234.0)},
    {'ronds': [(459.9, 156.6, 48.8), (576.8, 156.6, 49.0), (695.1, 156.9, 49.0)], 'serie': (752.1, 233.9)},
    {'ronds': [(844.0, 156.6, 49.0), (961.1, 156.7, 49.0), (1079.3, 156.9, 49.0)], 'serie': (1136.3, 233.9)},
    {'ronds': [(1228.0, 156.6, 48.8), (1345.0, 156.7, 49.0), (1463.3, 156.9, 49.0)], 'serie': (1520.3, 233.9)},
    {'ronds': [(75.7, 412.7, 48.8), (192.8, 412.9, 49.0), (311.2, 413.1, 49.0)], 'serie': (368.2, 490.1)},
    {'ronds': [(459.9, 412.8, 48.8), (576.8, 412.8, 49.0), (695.1, 413.0, 49.0)], 'serie': (752.1, 490.0)},
    {'ronds': [(844.0, 412.7, 48.8), (961.2, 412.8, 49.0), (1079.2, 413.1, 49.0)], 'serie': (1136.2, 490.1)},
    {'ronds': [(1227.9, 412.7, 48.8), (1345.0, 412.9, 49.0), (1463.2, 413.1, 49.0)], 'serie': (1520.2, 490.1)},
    {'ronds': [(75.7, 667.9, 49.0), (192.9, 668.1, 49.0), (311.1, 668.4, 49.0)], 'serie': (368.1, 745.4)},
    {'ronds': [(459.9, 667.9, 48.9), (576.8, 668.1, 49.0), (695.0, 668.3, 49.0)], 'serie': (752.0, 745.3)},
    {'ronds': [(844.0, 667.9, 48.9), (961.0, 668.0, 49.0), (1079.2, 668.4, 49.0)], 'serie': (1136.2, 745.4)},
    {'ronds': [(1227.9, 668.0, 48.7), (1344.9, 668.0, 48.9), (1462.6, 668.4, 48.9)], 'serie': (1519.6, 745.4)},
    {'ronds': [(75.9, 917.0, 47.9), (193.0, 917.3, 47.9), (311.2, 918.1, 48.0)], 'serie': (368.2, 995.1)},
    {'ronds': [(460.2, 917.4, 47.4), (576.9, 917.6, 48.0), (695.1, 918.1, 48.0)], 'serie': (752.1, 995.1)},
    {'ronds': [(844.3, 917.4, 47.7), (961.3, 917.7, 48.0), (1079.4, 918.1, 47.7)], 'serie': (1136.4, 995.1)},
    {'ronds': [(1228.3, 917.5, 47.7), (1345.0, 917.7, 47.9), (1463.4, 918.1, 48.0)], 'serie': (1520.4, 995.1)},
]

ECART = 0.20   # blanc entre les deux numéros, en hauteur de chiffre


def _taille_max():
    r = min(rd[2] for ct in CARTONS for rd in ct["ronds"]) - 2.5
    r_pt = r / _IMG_W * PAGE_W
    t = 8.0
    while True:
        t2 = t + 0.5
        demi_h = (2 + ECART) * _CAP * t2 / 2.0
        demi_w = 0.556 * t2
        if demi_h ** 2 + demi_w ** 2 > r_pt ** 2:
            return t
        t = t2


TAILLE = _taille_max()


def _px(x):
    return x / _IMG_W * PAGE_W


def _py(y):
    return PAGE_H * (1 - y / _IMG_H)


def _numeros(rng, deja=None):
    while True:
        d = [sorted(rng.sample(range(a, b + 1), 2)) for a, b in PLAGES]
        cle = tuple(v for p in d for v in p)
        if deja is None or cle not in deja:
            if deja is not None:
                deja.add(cle)
            return d


def generer_pdf(nb_cartes=None, nb_tickets=None, serie_start=1, theme="", couleur=True,
                nom_evenement="", titre_jeu="", couleur_perso="", date_lieu="",
                telephone="", page_start=1, evenement_id="", style="", motif="",
                _deja=None, **_ig):
    n_ = nb_cartes if nb_cartes is not None else nb_tickets
    n_ = max(1, int(n_ if n_ else CARTES_PAGE))
    buf = io.BytesIO()
    c = canvas.Canvas(buf, pagesize=(PAGE_W, PAGE_H), pageCompression=1)
    c.setTitle("TUN")
    rng = random.Random(int(serie_start) * 100003 + 3030)
    deja = _deja if _deja is not None else set()
    serie = int(serie_start)
    faits = 0
    col_imposee = None
    if couleur and couleur_perso:
        try:
            col_imposee = colors.HexColor(couleur_perso)
        except Exception:
            col_imposee = None
    ecart = ECART * _CAP * TAILLE
    try:
        no_page = max(1, int(page_start))
    except Exception:
        no_page = 1
    while faits < n_:
        c.saveState()
        c.translate(DECAL_X, DECAL_Y)
        c.scale(ECHELLE, ECHELLE)
        try:
            c.drawImage(_IMG_FOND, 0, 0, PAGE_W, PAGE_H, preserveAspectRatio=False, mask="auto")
        except Exception:
            pass
        for idx in range(CARTES_PAGE):
            if faits >= n_:
                break
            ct = CARTONS[idx]
            col = (col_imposee or colors.HexColor(RAINBOW[serie % len(RAINBOW)])) if couleur else NOIR
            nums = _numeros(rng, deja)
            c.saveState()
            c.setFillColor(col)
            c.setStrokeColor(col)
            c.setLineWidth(0.5)     # chiffres nourris : bien francs à l'impression
            c.setLineJoin(1)
            for (x, y, r), (haut, bas) in zip(ct["ronds"], nums):
                cx, cy = _px(x), _py(y)
                for txt, yy in ((str(haut), cy + ecart / 2.0),
                                (str(bas), cy - ecart / 2.0 - _CAP * TAILLE)):
                    t = c.beginText()
                    t.setTextRenderMode(2)
                    t.setFont(POLICE, TAILLE)
                    t.setTextOrigin(cx - c.stringWidth(txt, POLICE, TAILLE) / 2.0, yy)
                    t.textOut(txt)
                    c.drawText(t)
            c.restoreState()
            tx0, ty0, tx1, ty1 = TEL_BOX[idx]
            c.setFillColor(NOIR)
            c.setFont("Helvetica-Bold", 9.5)
            c.drawString(_px(tx0), _py(ty1) + 0.5,
                         "Tél : " + ((telephone or "").strip() or TEL_DEFAUT))
            sx, sy = ct["serie"]
            c.setFillColor(GRIS_TRAIT)
            c.setFont("Helvetica-Bold", 6.5)
            c.drawRightString(_px(sx), _py(sy), "N° %06d" % serie)
            serie += 1
            faits += 1
        c.restoreState()
        # ⭐ n° de page (Maeva 18/11) : dans la marge de droite, en bas,
        #    à plus de 4,2 mm du bord (zone que la Konica imprime).
        c.setFillColor(GRIS_TRAIT)
        c.setFont("Helvetica", 5.5)
        c.drawRightString(PAGE_W - 13.5, 20, "%03d" % no_page)
        no_page += 1
        c.showPage()
    c.save()
    buf.seek(0)
    return buf


if __name__ == "__main__":
    open("test_tun.pdf", "wb").write(generer_pdf(nb_cartes=16, couleur=False).read())
    print("TUN genere")
