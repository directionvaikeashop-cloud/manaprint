# -*- coding: utf-8 -*-
"""CIBLE (Ranihei) - 6 cartons par feuille, 8 cibles : B I N x2, G O x1. Plages 1-75."""
import os, io, random
from reportlab.lib.pagesizes import A4
from reportlab.pdfgen import canvas
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.lib.colors import black, Color

PAGE_W, PAGE_H = A4
CARTES_PAGE = 6
PLAGES = {'B': (1, 15), 'I': (16, 30), 'N': (31, 45), 'G': (46, 60), 'O': (61, 75)}
_DIR = os.path.dirname(os.path.abspath(__file__))
_FOND = os.path.join(_DIR, 'cible_fond_v2.png')
_IMG_W, _IMG_H = 1054, 1492
GRIS_TRAIT = Color(0.41, 0.41, 0.41)
_CAP = 0.70

def _font(name, files):
    try:
        pdfmetrics.getFont(name); return name
    except Exception:
        pass
    for f in files:
        if os.path.exists(f):
            pdfmetrics.registerFont(TTFont(name, f)); return name
    return 'Helvetica-Bold'

BEBAS = _font('BebasNeue', [os.path.join(_DIR, 'BebasNeue-Regular.ttf'),
                           os.path.join(_DIR, '..', 'fonts', 'BebasNeue-Regular.ttf'),
                           '/usr/share/fonts/truetype/bebas/BebasNeue-Regular.ttf'])
SERIE_F = _font('DejaVuCondB', [os.path.join(_DIR, 'DejaVuSansCondensed-Bold.ttf'),
                               '/usr/share/fonts/truetype/dejavu/DejaVuSansCondensed-Bold.ttf'])

CARTONS = [{'serie': (149, 19, 242, 41), 'pots': {'B': [(97.5, 248.3, 39.6), (264.0, 248.6, 39.4)], 'I': [(88.8, 415.1, 38.5), (271.3, 415.9, 36.7)], 'N': [(89.6, 582.1, 37.3), (269.7, 582.4, 37.0)], 'G': [(179.3, 340.6, 31.0)], 'O': [(179.4, 496.3, 30.8)]}}, {'serie': (498, 19, 596, 41), 'pots': {'B': [(445.0, 248.8, 39.9), (611.9, 248.7, 39.2)], 'I': [(436.2, 415.3, 38.5), (619.6, 415.9, 36.4)], 'N': [(438.5, 582.3, 37.1), (617.5, 582.9, 37.7)], 'G': [(527.4, 340.6, 31.8)], 'O': [(528.0, 496.3, 31.2)]}}, {'serie': (844, 19, 942, 41), 'pots': {'B': [(794.1, 248.3, 39.8), (960.8, 248.9, 39.4)], 'I': [(783.8, 415.2, 38.4), (968.5, 415.9, 36.9)], 'N': [(786.8, 582.0, 37.5), (967.0, 582.9, 37.6)], 'G': [(875.8, 340.6, 31.1)], 'O': [(875.6, 496.4, 31.1)]}}, {'serie': (148, 761, 248, 784), 'pots': {'B': [(97.4, 992.9, 39.2), (264.3, 993.1, 38.9)], 'I': [(88.9, 1159.7, 38.2), (271.4, 1160.1, 37.0)], 'N': [(89.6, 1325.6, 37.5), (269.6, 1325.8, 37.6)], 'G': [(179.5, 1084.4, 30.8)], 'O': [(179.5, 1240.2, 30.4)]}}, {'serie': (498, 761, 596, 784), 'pots': {'B': [(445.1, 993.1, 39.4), (611.8, 993.0, 38.6)], 'I': [(436.5, 1159.6, 38.2), (619.5, 1160.2, 36.7)], 'N': [(438.4, 1325.7, 37.5), (617.4, 1326.2, 37.5)], 'G': [(527.3, 1084.4, 31.8)], 'O': [(527.9, 1240.0, 31.1)]}}, {'serie': (844, 761, 944, 784), 'pots': {'B': [(793.7, 992.5, 39.8), (961.0, 993.2, 39.1)], 'I': [(783.9, 1159.7, 38.3), (968.5, 1160.1, 37.0)], 'N': [(786.8, 1325.6, 37.5), (967.0, 1326.2, 37.5)], 'G': [(875.6, 1084.4, 31.8)], 'O': [(875.7, 1240.1, 31.1)]}}]

def _px(x): return x / _IMG_W * PAGE_W
def _py(y): return PAGE_H * (1 - y / _IMG_H)

def _taille_pour(r):
    r_pt = r / _IMG_W * PAGE_W * 0.99
    t = 10.0
    while True:
        w = pdfmetrics.stringWidth('88', BEBAS, t + 0.5) / 2
        h = (t + 0.5) * _CAP / 2
        if w * w + h * h > r_pt * r_pt: return t
        t += 0.5

def _tailles():
    gr = min(p[2] for c in CARTONS for k in 'BIN' for p in c['pots'][k])
    pe = min(p[2] for c in CARTONS for k in 'GO' for p in c['pots'][k])
    return _taille_pour(gr), _taille_pour(pe)

_T_GRANDES, _T_PETITES = _tailles()

def _chiffre(c, x, y, txt, taille):
    c.saveState()
    c.setFillColor(black); c.setStrokeColor(black); c.setLineWidth(0.6)
    t = c.beginText(); t.setTextRenderMode(2); t.setFont(BEBAS, taille)
    w = pdfmetrics.stringWidth(txt, BEBAS, taille)
    t.setTextOrigin(x - w / 2, y - taille * _CAP / 2); t.textOut(txt)
    c.drawText(t); c.restoreState()

def _numeros(rng):
    out = {}
    for k, (a, b) in PLAGES.items():
        n = 2 if k in 'BIN' else 1
        out[k] = sorted(rng.sample(range(a, b + 1), n))
    return out

# ⭐ 19/11 : feuille ramenée à 6 mm des bords (la Konica n'imprime pas les
#    4,2 mm du bord) + n° de page (Maeva : « faut pas oublier nos numéros de page »).
MARGE_SURE = 6 * 72 / 25.4
ECHELLE = min((PAGE_W - 2 * MARGE_SURE) / PAGE_W, (PAGE_H - 2 * MARGE_SURE) / PAGE_H)
DECAL_X = (PAGE_W - PAGE_W * ECHELLE) / 2.0
DECAL_Y = (PAGE_H - PAGE_H * ECHELLE) / 2.0


def _debut_page(c):
    c.saveState()
    c.translate(DECAL_X, DECAL_Y)
    c.scale(ECHELLE, ECHELLE)


def _fin_page(c, no_page):
    c.restoreState()
    from reportlab.lib.colors import Color as _C
    c.setFillColor(_C(0.40, 0.40, 0.40))
    c.setFont("Helvetica", 6)
    if PAGE_W > PAGE_H:
        c.drawRightString(PAGE_W - 13.5, 20, "%d" % no_page)
    else:
        c.drawRightString(PAGE_W - 17, PAGE_H - 19, "%d" % no_page)


def generer_pdf(nb_cartes=6, nb_tickets=0, serie_start=1, theme=None, couleur=False,
                nom_evenement='', titre_jeu='', couleur_perso=None, date_lieu='',
                telephone='', page_start=1, evenement_id=None, style=None, motif=None, _deja=None, **_ig):
    try:
        import securite; securite.activer_mode_rapide(True)
    except Exception:
        pass
    buf = io.BytesIO()
    c = canvas.Canvas(buf, pagesize=A4)
    c.setTitle('CIBLE')
    rng = random.Random(serie_start * 100003 + 77)
    nb_pages = max(1, -(-int(nb_cartes) // CARTES_PAGE))
    serie = serie_start
    try:
        no_page = max(1, int(page_start))
    except Exception:
        no_page = 1
    for p in range(nb_pages):
        _debut_page(c)
        c.drawImage(_FOND, 0, 0, PAGE_W, PAGE_H)
        for ct in CARTONS:
            if serie >= serie_start + nb_cartes: break
            nums = _numeros(rng)
            if _deja is not None:
                _k = tuple((k, tuple(v)) for k, v in sorted(nums.items()))
                while _k in _deja:
                    nums = _numeros(rng)
                    _k = tuple((k, tuple(v)) for k, v in sorted(nums.items()))
                _deja.add(_k)
            for k, pots in ct['pots'].items():
                t = _T_GRANDES if k in 'BIN' else _T_PETITES
                for (cx, cy, r), v in zip(pots, nums[k]):
                    _chiffre(c, _px(cx), _py(cy), str(v), t)
            x0, y0, x1, y1 = ct['serie']
            hs = (_py(y0) - _py(y1)) * 1.0
            c.setFillColor(GRIS_TRAIT); c.setFont(SERIE_F, hs * 1.3)
            c.drawString(_px(x0), _py(y1), '%06d' % serie)
            serie += 1
        _fin_page(c, no_page)
        no_page += 1
        c.showPage()
    c.save()
    return buf.getvalue()
