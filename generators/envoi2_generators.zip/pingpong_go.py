# -*- coding: utf-8 -*-
"""MANAPRINT — PING-PONG GO (création RANIHEI, maquettes Maeva).
6 cartons / feuille A4 PORTRAIT (2 x 3) — la feuille de la maquette est reprise
TELLE QUELLE comme fond (n° de série d'origine gommé, traits passés en gris) ;
on n'ajoute que les chiffres et le n° de série.
8 paires de raquettes = 16 numéros par carton (chaque paire triée) :
   paires du haut (gauche + droite)     -> B 1-15  (4 numéros)
   paires du milieu (gauche + droite)   -> I 16-30 (4 numéros)
   paires du bas (gauche + droite)      -> N 31-45 (4 numéros)
   paire centrale du haut               -> G 46-60 (2 numéros)
   paire centrale du bas                -> O 61-75 (2 numéros)
   -> crieur 1 à 75. Chiffres en BEBAS NEUE épaissi."""
import io, os as _os, random
from reportlab.pdfgen import canvas
from reportlab.lib.pagesizes import A4
from reportlab.lib import colors
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont

PAGE_W, PAGE_H = A4
CARTES_PAGE = 6
NOIR = colors.black
GRIS_TRAIT = colors.Color(105 / 255.0, 105 / 255.0, 105 / 255.0)
RAINBOW = ["#E53935", "#FB8C00", "#F9A825", "#43A047", "#00ACC1",
           "#1E88E5", "#3949AB", "#8E24AA", "#D81B60", "#6D4C41"]
PLAGES = {"B": (1, 15), "I": (16, 30), "N": (31, 45), "G": (46, 60), "O": (61, 75)}
NB = {"B": 4, "I": 4, "N": 4, "G": 2, "O": 2}

_ICI = _os.path.dirname(_os.path.abspath(__file__))


def _police(nom, fichiers, defaut):
    for f in fichiers:
        try:
            if _os.path.exists(f):
                pdfmetrics.registerFont(TTFont(nom, f))
                return nom
        except Exception:
            pass
    return defaut


POLICE = _police("BebasNeue", [_os.path.join(_ICI, "BebasNeue-Regular.ttf")], "Helvetica-Bold")
_CAP = 0.70 if POLICE == "BebasNeue" else 0.717
# « 88 » le plus gros qui tient dans la PLUS PETITE raquette (mesuré au pixel,
# 3 px de marge) — même taille partout. NE PAS MONTER.
TAILLE = 28.5 if POLICE == "BebasNeue" else 24.0
# ⭐ 19/11 (Maeva : « grossir au maximum ») : une taille par famille de
#    raquettes, la plus grosse que la plus petite raquette de la famille permet.
TAILLES = ({"B": 33.5, "I": 28.5, "N": 30.0, "G": 28.5, "O": 33.0} if POLICE == "BebasNeue"
           else {k: 24.0 for k in "BINGO"})
SERIE_F = _police("DejaVuCondB", [_os.path.join(_ICI, "DejaVuSansCondensed-Bold.ttf"),
                                  "/usr/share/fonts/truetype/dejavu/DejaVuSansCondensed-Bold.ttf"],
                  "Helvetica-Bold")
T_SERIE = 12.5

_IMG_W, _IMG_H = 1058.0, 1486.0
_IMG_FOND = _os.path.join(_ICI, "pingpong_go_fond_v2.png")

# centres (x, y) px : pour chaque plage, la liste des paires [(gauche), (droite)] ;
# serie = (x0, y0, x1, y1) px de la place du n° de série (après « N° »).
CARTONS = [
    {'B': [[(127.5, 95.5), (216.5, 96.0)], [(369.0, 95.0), (454.0, 96.5)]], 'I': [[(65.5, 210.0), (142.0, 210.5)], [(395.0, 215.0), (470.0, 216.0)]], 'N': [[(68.5, 353.5), (144.5, 354.0)], [(385.5, 353.5), (463.5, 355.0)]], 'G': [[(239.5, 180.0), (316.5, 179.5)]], 'O': [[(228.0, 297.0), (312.0, 298.5)]], 'serie': (68, 26, 154, 48)},
    {'B': [[(653.5, 95.0), (742.5, 95.5)], [(894.5, 94.0), (979.5, 96.0)]], 'I': [[(591.0, 210.0), (668.0, 211.5)], [(921.0, 215.0), (996.5, 216.0)]], 'N': [[(596.0, 353.0), (672.0, 353.5)], [(911.0, 353.5), (989.5, 355.0)]], 'G': [[(764.5, 179.5), (841.0, 178.5)]], 'O': [[(753.5, 297.0), (838.0, 298.5)]], 'serie': (593, 26, 679, 48)},
    {'B': [[(128.0, 588.5), (217.0, 589.5)], [(369.5, 588.0), (454.5, 589.5)]], 'I': [[(65.5, 701.5), (142.0, 702.5)], [(394.5, 708.0), (470.0, 709.0)]], 'N': [[(68.0, 845.0), (143.5, 845.0)], [(386.5, 844.0), (463.0, 846.0)]], 'G': [[(239.5, 672.5), (316.5, 672.0)]], 'O': [[(228.0, 789.5), (312.5, 791.0)]], 'serie': (67, 520, 153, 542)},
    {'B': [[(655.0, 588.5), (743.5, 589.5)], [(896.0, 587.5), (980.5, 590.0)]], 'I': [[(592.0, 701.5), (669.5, 703.0)], [(922.5, 707.5), (998.0, 709.0)]], 'N': [[(595.0, 844.0), (671.0, 844.5)], [(913.0, 844.0), (989.5, 846.0)]], 'G': [[(766.0, 672.5), (842.5, 671.5)]], 'O': [[(755.0, 789.5), (839.0, 790.0)]], 'serie': (595, 520, 681, 542)},
    {'B': [[(128.5, 1076.5), (217.0, 1078.0)], [(370.0, 1075.0), (454.5, 1077.5)]], 'I': [[(65.0, 1186.0), (142.5, 1187.0)], [(396.0, 1193.0), (471.0, 1195.0)]], 'N': [[(68.0, 1330.0), (145.0, 1330.0)], [(387.0, 1330.5), (464.0, 1331.0)]], 'G': [[(240.5, 1158.0), (317.0, 1158.0)]], 'O': [[(229.0, 1274.0), (312.5, 1275.5)]], 'serie': (68, 1011, 154, 1033)},
    {'B': [[(655.5, 1076.0), (744.5, 1077.0)], [(895.0, 1075.0), (980.0, 1077.0)]], 'I': [[(592.5, 1186.5), (669.5, 1187.0)], [(922.5, 1193.0), (997.5, 1195.0)]], 'N': [[(596.0, 1330.0), (672.0, 1329.5)], [(913.0, 1329.5), (990.0, 1330.5)]], 'G': [[(766.5, 1158.0), (842.0, 1158.0)]], 'O': [[(755.5, 1274.0), (839.5, 1274.5)]], 'serie': (595, 1011, 681, 1033)},
]

_EPAIS = 0.6


def _chiffre(c, x, y, txt, taille):
    txt = str(txt)
    w = c.stringWidth(txt, POLICE, taille)
    c.saveState()
    try:
        c.setStrokeColor(c._fillColorObj)
        c.setLineWidth(_EPAIS)
        c.setLineJoin(1)
        t = c.beginText()
        t.setTextRenderMode(2)
        t.setFont(POLICE, taille)
        t.setTextOrigin(x - w / 2.0, y)
        t.textOut(txt)
        c.drawText(t)
    finally:
        c.restoreState()


def _px(x):
    return x / _IMG_W * PAGE_W


def _py(y):
    return PAGE_H * (1 - y / _IMG_H)


def _numeros(rng, deja=None):
    while True:
        d = {}
        for k, (a, b) in PLAGES.items():
            v = rng.sample(range(a, b + 1), NB[k])
            d[k] = [sorted(v[i:i + 2]) for i in range(0, len(v), 2)]
        cle = tuple(tuple(sorted(sum(d[k], []))) for k in "BINGO")
        if deja is None or cle not in deja:
            if deja is not None:
                deja.add(cle)
            return d


# ⭐ 19/11 : feuille ramenée à 6 mm des bords (la Konica n'imprime pas les
#    4,2 mm du bord) + n° de page (Maeva : « faut pas oublier nos numéros de page »).
MARGE_SURE = 6 * 72 / 25.4
ECHELLE = min((PAGE_W - 2 * MARGE_SURE) / PAGE_W, (PAGE_H - 2 * MARGE_SURE) / PAGE_H)
DECAL_X = (PAGE_W - PAGE_W * ECHELLE) / 2.0
DECAL_Y = (PAGE_H - PAGE_H * ECHELLE) / 2.0


def _debut_page(c):
    c.saveState()
    c.translate(DECAL_X, DECAL_Y)
    c.scale(ECHELLE, ECHELLE)


def _fin_page(c, no_page):
    c.restoreState()
    from reportlab.lib.colors import Color as _C
    c.setFillColor(_C(0.40, 0.40, 0.40))
    c.setFont("Helvetica", 6)
    if PAGE_W > PAGE_H:
        c.drawRightString(PAGE_W - 13.5, 20, "%d" % no_page)
    else:
        c.drawRightString(PAGE_W - 17, PAGE_H - 19, "%d" % no_page)


def generer_pdf(nb_cartes=None, nb_tickets=None, serie_start=1, theme="", couleur=True,
                nom_evenement="", titre_jeu="", couleur_perso="", date_lieu="",
                telephone="", page_start=1, evenement_id="", style="", motif="", _deja=None, **_ig):
    n_ = nb_cartes if nb_cartes is not None else nb_tickets
    n_ = max(1, int(n_ if n_ else CARTES_PAGE))
    buf = io.BytesIO()
    c = canvas.Canvas(buf, pagesize=(PAGE_W, PAGE_H), pageCompression=1)
    c.setTitle("PING-PONG GO")
    rng = random.Random(int(serie_start) * 100003 + 7766)
    serie = int(serie_start)
    faits = 0
    deja = _deja if _deja is not None else set()
    col_imposee = None
    if couleur and couleur_perso:
        try:
            col_imposee = colors.HexColor(couleur_perso)
        except Exception:
            col_imposee = None

    try:
        no_page = max(1, int(page_start))
    except Exception:
        no_page = 1
    while faits < n_:
        _debut_page(c)
        try:
            c.drawImage(_IMG_FOND, 0, 0, PAGE_W, PAGE_H, preserveAspectRatio=False, mask="auto")
        except Exception:
            pass
        entete = "  ·  ".join(t for t in ((nom_evenement or "").strip(),
                                          (date_lieu or "").strip(),
                                          (telephone or "").strip()) if t)
        if entete:
            c.setFillColor(NOIR)
            c.setFont("Helvetica-Bold", 6)
            c.drawString(_px(20), PAGE_H - 5.5, entete)
        for idx in range(CARTES_PAGE):
            if faits >= n_:
                break
            ct = CARTONS[idx]
            col = (col_imposee or colors.HexColor(RAINBOW[serie % len(RAINBOW)])) if couleur else NOIR
            nums = _numeros(rng, deja)
            c.setFillColor(col)
            for k in "BINGO":
                t = TAILLES[k]
                dy = t * _CAP / 2.0
                for paire_pos, paire_val in zip(ct[k], nums[k]):
                    for (x, y), v in zip(paire_pos, paire_val):
                        _chiffre(c, _px(x), _py(y) - dy, v, t)
            x0, y0, x1, y1 = ct["serie"]
            c.setFillColor(GRIS_TRAIT)
            c.setFont(SERIE_F, T_SERIE)
            c.drawString(_px(x0), _py(y1), "%06d" % serie)
            serie += 1
            faits += 1
        _fin_page(c, no_page)
        no_page += 1
        c.showPage()
    c.save()
    buf.seek(0)
    return buf


if __name__ == "__main__":
    open("test_pingpong_go.pdf", "wb").write(generer_pdf(nb_cartes=6, couleur=False).read())
    print("PING-PONG GO genere")
