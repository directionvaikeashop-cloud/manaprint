# -*- coding: utf-8 -*-
"""MANAPRINT — PÉTANQUE · 7 boules (création 2KEA & Associé, maquette Maeva 09/11).
Refait le 19/11/2026. 8 cartons / feuille A4 PORTRAIT. La maquette est reprise
TELLE QUELLE comme fond (n° imprimé gommé, 2 tons francs pour la Konica) ; on
n'ajoute que les chiffres, le n° de série et le n° de page.
7 boules lues par colonne de gauche à droite : 1 · 2 · 1 · 2 · 1
   1-18 · 19-36 · 37-54 · 55-72 · 73-90 (les deux d'une colonne : le petit en haut)
   -> crieur 1 à 90.
Chiffres League Gothic épaissi, le plus gros que la plus petite boule permet."""
import io, os as _os, random
from reportlab.pdfgen import canvas
from reportlab.lib.pagesizes import A4
from reportlab.lib import colors
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont

PAGE_W, PAGE_H = A4
CARTES_PAGE = 8
PLAGES = [(1, 18), (19, 36), (37, 54), (55, 72), (73, 90)]
PAR_COLONNE = [1, 2, 1, 2, 1]
NOIR = colors.Color(0.10, 0.10, 0.10)
GRIS_TRAIT = colors.Color(0.40, 0.40, 0.40)
RAINBOW = ["#E53935", "#FB8C00", "#F9A825", "#43A047", "#00ACC1",
           "#1E88E5", "#3949AB", "#8E24AA", "#D81B60", "#6D4C41"]
_ICI = _os.path.dirname(_os.path.abspath(__file__))
POLICE, _CAP = "Helvetica-Bold", 0.717
try:
    pdfmetrics.registerFont(TTFont("LGOTH", _os.path.join(_ICI, "LeagueGothic-Regular_v2.ttf")))
    POLICE, _CAP = "LGOTH", 0.735
except Exception:
    pass
_EPAIS = 0.6
_IMG_W, _IMG_H = 1055.0, 1491.0
_IMG_FOND = _os.path.join(_ICI, "petanque_fond.png")
MARGE_SURE = 6 * 72 / 25.4
ECHELLE = min((PAGE_W - 2 * MARGE_SURE) / PAGE_W, (PAGE_H - 2 * MARGE_SURE) / PAGE_H)
DECAL_X = (PAGE_W - PAGE_W * ECHELLE) / 2.0
DECAL_Y = (PAGE_H - PAGE_H * ECHELLE) / 2.0

# boules : (cx, cy, largeur, hauteur) px, colonne par colonne ; serie = place du n° imprimé
CARTONS = [
    {'cols': [[(150.0, 227.0, 124, 96)], [(228.5, 146.0, 111, 92), (217.5, 311.0, 119, 96)], [(291.5, 228.0, 119, 96)], [(361.5, 144.5, 115, 93), (358.5, 308.0, 119, 88)], [(430.5, 228.0, 121, 96)]], 'serie': (80, 25, 166, 49)},
    {'cols': [[(674.0, 227.0, 124, 96)], [(752.5, 146.0, 111, 92), (741.5, 311.0, 119, 96)], [(815.5, 228.0, 119, 96)], [(885.5, 144.5, 115, 93), (882.5, 308.0, 119, 88)], [(954.5, 228.0, 121, 96)]], 'serie': (602, 24, 694, 48)},
    {'cols': [[(150.0, 600.0, 124, 96)], [(228.5, 519.0, 111, 92), (217.5, 684.0, 119, 96)], [(291.5, 601.0, 119, 96)], [(361.5, 517.5, 115, 93), (358.5, 681.0, 119, 88)], [(430.5, 601.0, 121, 96)]], 'serie': (81, 400, 171, 423)},
    {'cols': [[(675.0, 600.0, 124, 96)], [(753.5, 519.0, 111, 92), (742.5, 684.0, 119, 96)], [(816.5, 601.0, 119, 96)], [(886.5, 517.5, 115, 93), (883.5, 681.0, 119, 88)], [(955.5, 601.0, 121, 96)]], 'serie': (602, 400, 695, 423)},
    {'cols': [[(149.5, 968.8, 124, 96)], [(228.0, 887.8, 111, 92), (217.0, 1052.8, 119, 96)], [(291.0, 969.8, 119, 96)], [(361.0, 886.2, 115, 93), (358.0, 1049.8, 119, 88)], [(430.0, 969.8, 121, 96)]], 'serie': (80, 770, 171, 793)},
    {'cols': [[(674.5, 968.5, 124, 96)], [(753.0, 887.5, 111, 92), (742.0, 1052.5, 119, 96)], [(816.0, 969.5, 119, 96)], [(886.0, 886.0, 115, 93), (883.0, 1049.5, 119, 88)], [(955.0, 969.5, 121, 96)]], 'serie': (602, 769, 695, 792)},
    {'cols': [[(150.0, 1330.2, 124, 96)], [(228.5, 1249.2, 111, 92), (217.5, 1414.2, 119, 96)], [(291.5, 1331.2, 119, 96)], [(361.5, 1247.8, 115, 93), (358.5, 1411.2, 119, 88)], [(430.5, 1331.2, 121, 96)]], 'serie': (81, 1136, 171, 1159)},
    {'cols': [[(675.0, 1330.8, 124, 96)], [(753.5, 1249.8, 111, 92), (742.5, 1414.8, 119, 96)], [(816.5, 1331.8, 119, 96)], [(886.5, 1248.2, 115, 93), (883.5, 1411.8, 119, 88)], [(955.5, 1331.8, 121, 96)]], 'serie': (604, 1137, 697, 1160)},
]


def _px(x):
    return x / _IMG_W * PAGE_W


def _py(y):
    return PAGE_H * (1 - y / _IMG_H)


def _taille_max():
    # « 88 » doit tenir dans la plus petite boule (ellipse intérieure, 7 px d'air)
    a = min(e[2] for ct in CARTONS for col in ct["cols"] for e in col) / 2.0 - 7
    b = min(e[3] for ct in CARTONS for col in ct["cols"] for e in col) / 2.0 - 7
    a, b = _px(a) - _px(0), _px(b) - _px(0)
    t = 10.0
    while True:
        t2 = t + 0.5
        w = pdfmetrics.stringWidth("88", POLICE, t2) / 2.0 + _EPAIS
        h = t2 * _CAP / 2.0 + _EPAIS
        if (w / a) ** 2 + (h / b) ** 2 > 1.0:
            return t
        t = t2


TAILLE = _taille_max()   # 19/11 : au maximum (Maeva)


def _numeros(rng, deja=None):
    while True:
        d = [sorted(rng.sample(range(lo, hi + 1), n)) for (lo, hi), n in zip(PLAGES, PAR_COLONNE)]
        cle = tuple(v for p in d for v in p)
        if deja is None or cle not in deja:
            if deja is not None:
                deja.add(cle)
            return d


def _chiffre(c, x, y, txt, t):
    c.saveState()
    c.setStrokeColor(c._fillColorObj)
    c.setLineWidth(_EPAIS)
    c.setLineJoin(1)
    o = c.beginText()
    o.setTextRenderMode(2)
    o.setFont(POLICE, t)
    o.setTextOrigin(x - c.stringWidth(txt, POLICE, t) / 2.0, y)
    o.textOut(txt)
    c.drawText(o)
    c.restoreState()


def generer_pdf(nb_cartes=None, nb_tickets=None, serie_start=1, theme="", couleur=True,
                nom_evenement="", titre_jeu="", couleur_perso="", date_lieu="",
                telephone="", page_start=1, evenement_id="", style="", motif="",
                _deja=None, **_ig):
    n_ = nb_cartes if nb_cartes is not None else nb_tickets
    n_ = max(1, int(n_ if n_ else CARTES_PAGE))
    buf = io.BytesIO()
    c = canvas.Canvas(buf, pagesize=(PAGE_W, PAGE_H), pageCompression=1)
    c.setTitle("PETANQUE")
    rng = random.Random(int(serie_start) * 100003 + 9090)
    deja = _deja if _deja is not None else set()
    serie = int(serie_start)
    faits = 0
    try:
        no_page = max(1, int(page_start))
    except Exception:
        no_page = 1
    col_imposee = None
    if couleur and couleur_perso:
        try:
            col_imposee = colors.HexColor(couleur_perso)
        except Exception:
            col_imposee = None
    while faits < n_:
        c.saveState()
        c.translate(DECAL_X, DECAL_Y)
        c.scale(ECHELLE, ECHELLE)
        try:
            c.drawImage(_IMG_FOND, 0, 0, PAGE_W, PAGE_H, preserveAspectRatio=False, mask="auto")
        except Exception:
            pass
        for idx in range(CARTES_PAGE):
            if faits >= n_:
                break
            ct = CARTONS[idx]
            col = (col_imposee or colors.HexColor(RAINBOW[serie % len(RAINBOW)])) if couleur else NOIR
            nums = _numeros(rng, deja)
            c.setFillColor(col)
            for boules, vals in zip(ct["cols"], nums):
                for (x, y, w, h), v in zip(boules, vals):
                    _chiffre(c, _px(x), _py(y) - TAILLE * _CAP / 2.0, str(v), TAILLE)
            sx0, sy0, sx1, sy1 = ct["serie"]
            ts = (_px(sy1) - _px(sy0)) / 0.72
            c.setFillColor(NOIR)
            c.setFont("Helvetica-Bold", ts)
            c.drawString(_px(sx0), _py(sy1), "%06d" % serie)
            serie += 1
            faits += 1
        c.restoreState()
        c.setFillColor(GRIS_TRAIT)
        c.setFont("Helvetica", 6)
        c.drawRightString(PAGE_W - 17, PAGE_H - 19, "%d" % no_page)
        no_page += 1
        c.showPage()
    c.save()
    buf.seek(0)
    return buf
