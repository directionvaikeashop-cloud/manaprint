# -*- coding: utf-8 -*-
"""MANAPRINT — NUKU HIVA · 6 numéros (jeu MARIO).
⭐ 18/11/2026 : NOUVELLE MAQUETTE « MARIO » (bulles vides, titre MARIO),
   même règle, mêmes plages, même crieur.
8 cartons / feuille A4 PORTRAIT (2 colonnes x 4 rangées) — la feuille de la
maquette est reprise TELLE QUELLE comme fond (chiffres d'origine gommés,
traits passés en gris) ; on n'ajoute que les chiffres et le n° de série.
Chaque carton = 6 BULLES (sceau Maeva : plages 1 à 75 par 15) :
   gauche haut  -> B  1-15      droite haut   -> G 46-60
   gauche milieu-> I 16-30      droite milieu -> O 61-75 (le plus petit)
   gauche bas   -> N 31-45      droite bas    -> O 61-75 (le plus grand)
   -> 6 numéros différents, crieur 1 à 75."""
import io, os as _os, random
from reportlab.pdfgen import canvas
from reportlab.lib.pagesizes import A4
from reportlab.lib import colors
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont

PAGE_W, PAGE_H = A4
CARTES_PAGE = 8
GRIS = colors.Color(0.18, 0.18, 0.18)
GRIS_TRAIT = colors.Color(105 / 255.0, 105 / 255.0, 105 / 255.0)
RAINBOW = ["#E53935", "#FB8C00", "#F9A825", "#43A047", "#00ACC1",
           "#1E88E5", "#3949AB", "#8E24AA", "#D81B60", "#6D4C41"]
PLAGES = {"B": (1, 15), "I": (16, 30), "N": (31, 45), "G": (46, 60), "O": (61, 75)}

_ICI = _os.path.dirname(_os.path.abspath(__file__))
# chiffres en LEAGUE GOTHIC épaissi (comme FATU HIVA / HIVA OA)
POLICE, _CAP, _T_NUM = "Helvetica-Bold", 0.717, 30.0
try:
    pdfmetrics.registerFont(TTFont("LGOTH", _os.path.join(_ICI, "LeagueGothic-Regular_v2.ttf")))
    # ⭐ MESURÉ (18/11, nouvelle maquette MARIO, bulles plus grandes) :
    #    « 88 » épaissi tient jusqu'à 41 pt dans la plus petite bulle,
    #    5 px de marge au trait. NE PAS MONTER.
    POLICE, _CAP, _T_NUM = "LGOTH", 0.75, 41.0
except Exception:
    pass
_EPAIS = 0.6

# maquette MARIO du 18/11 : 1054 x 1492 px (feuille entière)
_IMG_W, _IMG_H = 1054.0, 1492.0
MARGE_SURE = 6 * 72 / 25.4      # 6 mm : la Konica n'imprime pas les 4,2 mm du bord
ECHELLE = min((PAGE_W - 2 * MARGE_SURE) / PAGE_W, (PAGE_H - 2 * MARGE_SURE) / PAGE_H)
DECAL_X = (PAGE_W - PAGE_W * ECHELLE) / 2.0
DECAL_Y = (PAGE_H - PAGE_H * ECHELLE) / 2.0
_IMG_FOND = _os.path.join(_ICI, "nuku_hiva_fond_v2.png")

# centres (x, y) px des 6 bulles de chaque carton (ordre de lecture) et
# (x centre, ligne de base) du n° de série
CARTONS = [
    {'B': (84.3, 102.5), 'I': (83.4, 196.1), 'N': (83.1, 290.4), 'G': (449.9, 103.0), 'O': [(451.2, 196.6), (451.1, 290.7)], 'serie': (247.0, 286.0)},
    {'B': (601.9, 102.6), 'I': (601.9, 196.4), 'N': (601.7, 290.5), 'G': (967.5, 103.1), 'O': [(968.9, 196.9), (969.1, 290.9)], 'serie': (766.6, 286.1)},
    {'B': (84.3, 476.0), 'I': (83.4, 569.4), 'N': (83.2, 663.4), 'G': (449.8, 476.5), 'O': [(451.1, 569.9), (451.1, 663.8)], 'serie': (247.0, 659.5)},
    {'B': (602.3, 476.1), 'I': (601.8, 569.6), 'N': (601.6, 663.5), 'G': (967.9, 476.5), 'O': [(969.1, 570.1), (969.1, 663.9)], 'serie': (766.0, 659.6)},
    {'B': (84.5, 848.3), 'I': (83.6, 941.5), 'N': (83.4, 1035.6), 'G': (449.9, 848.5), 'O': [(451.2, 942.0), (451.1, 1036.0)], 'serie': (247.2, 1031.8)},
    {'B': (602.4, 848.4), 'I': (602.0, 941.8), 'N': (601.7, 1035.8), 'G': (967.6, 848.7), 'O': [(969.1, 942.3), (969.2, 1036.2)], 'serie': (765.1, 1031.9)},
    {'B': (84.6, 1218.8), 'I': (83.9, 1310.6), 'N': (83.5, 1402.7), 'G': (450.2, 1219.5), 'O': [(451.6, 1311.5), (451.3, 1403.6)], 'serie': (247.3, 1400.3)},
    {'B': (602.5, 1219.4), 'I': (602.1, 1311.3), 'N': (601.8, 1403.4), 'G': (968.1, 1219.5), 'O': [(969.1, 1311.7), (969.1, 1403.8)], 'serie': (765.2, 1400.9)},
]


def _px(x):
    return x / _IMG_W * PAGE_W


def _py(y):
    return PAGE_H * (1 - y / _IMG_H)


def _chiffre(c, x, y, txt, taille):
    txt = str(txt)
    x0 = x - c.stringWidth(txt, POLICE, taille) / 2.0
    c.saveState()
    try:
        c.setStrokeColor(c._fillColorObj)
        c.setLineWidth(_EPAIS)
        c.setLineJoin(1)
        t = c.beginText()
        t.setTextRenderMode(2)
        t.setFont(POLICE, taille)
        t.setTextOrigin(x0, y)
        t.textOut(txt)
        c.drawText(t)
    finally:
        c.restoreState()


def _numeros(rng):
    b = rng.randint(1, 15)
    i = rng.randint(16, 30)
    n = rng.randint(31, 45)
    g = rng.randint(46, 60)
    o = sorted(rng.sample(range(61, 76), 2))
    return b, i, n, g, o


def generer_pdf(nb_cartes=None, nb_tickets=None, serie_start=1, theme="", couleur=True,
                nom_evenement="", titre_jeu="", couleur_perso="", date_lieu="",
                telephone="", page_start=1, evenement_id="", style="", motif="",
                _deja=None, **_ig):
    deja = _deja if _deja is not None else set()
    n_ = nb_cartes if nb_cartes is not None else nb_tickets
    n_ = max(1, int(n_ if n_ else CARTES_PAGE))
    buf = io.BytesIO()
    c = canvas.Canvas(buf, pagesize=(PAGE_W, PAGE_H), pageCompression=1)
    rng = random.Random(int(serie_start) * 100003 + 8181)
    serie = int(serie_start)
    faits = 0
    try:
        no_page = max(1, int(page_start))
    except Exception:
        no_page = 1
    col_imposee = None
    if couleur and couleur_perso:
        try:
            col_imposee = colors.HexColor(couleur_perso)
        except Exception:
            col_imposee = None

    while faits < n_:
        c.saveState()
        c.translate(DECAL_X, DECAL_Y)
        c.scale(ECHELLE, ECHELLE)
        try:
            c.drawImage(_IMG_FOND, 0, 0, PAGE_W, PAGE_H, preserveAspectRatio=False, mask="auto")
        except Exception:
            pass
        entete = "  ·  ".join(t for t in ((nom_evenement or "").strip(),
                                          (date_lieu or "").strip(),
                                          (telephone or "").strip()) if t)
        if entete:
            c.setFillColor(GRIS)
            c.setFont("Helvetica-Bold", 6.5)
            c.drawCentredString(PAGE_W / 2.0, PAGE_H - 4.5, entete)
        c.setFillColor(colors.Color(0.6, 0.6, 0.6))
        c.setFont("Helvetica", 5)
        c.drawRightString(PAGE_W - 10, PAGE_H - 4.5, "%03d" % no_page)

        for idx in range(CARTES_PAGE):
            if faits >= n_:
                break
            ct = CARTONS[idx]
            col = (col_imposee or colors.HexColor(RAINBOW[serie % len(RAINBOW)])) if couleur else GRIS
            while True:   # jamais deux cartons identiques (même entre rames : _deja)
                b, i, n, g, o = _numeros(rng)
                cle = (b, i, n, g, tuple(o))
                if cle not in deja:
                    deja.add(cle)
                    break
            c.setFillColor(col)
            dy = _T_NUM * _CAP / 2.0
            for (x, y), v in ((ct["B"], b), (ct["I"], i), (ct["N"], n), (ct["G"], g),
                              (ct["O"][0], o[0]), (ct["O"][1], o[1])):
                _chiffre(c, _px(x), _py(y) - dy, v, _T_NUM)
            sx, sy = ct["serie"]
            c.setFillColor(GRIS_TRAIT)
            c.setFont("Helvetica-Bold", 5)
            c.drawCentredString(_px(sx), _py(sy), "N° %06d" % serie)
            serie += 1
            faits += 1
        c.restoreState()
        c.showPage()
        no_page += 1
    c.save()
    buf.seek(0)
    return buf
