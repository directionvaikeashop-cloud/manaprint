# -*- coding: utf-8 -*-
"""MANAPRINT — TRIPLE X (nouveau jeu, maquette de Maeva du 19/11/2026).
10 cartons / feuille A4 PORTRAIT (5 x 2). La maquette est reprise TELLE QUELLE
comme fond (n° imprimés gommés ; trait gris uni, sans aplat gris taché).
Comme TRIPLE ACTION 75 : TROIS numéros par bulle, triés (deux en haut, un dessous),
dans la plage écrite sur la bulle — avec moins de bulles que l'original :
   places 1 et 5  : bulle B 1-15  + bulle O 61-75
   places 2 et 4  : bulle I 16-30 + bulle G 46-60
   place 3        : bulle N 31-45 seule
   -> crieur 1 à 75.
Chiffres Latin Modern GRAS, noirs, le plus gros que la bulle permet."""
import io, os as _os, random
from reportlab.pdfgen import canvas
from reportlab.lib.pagesizes import A4
from reportlab.lib import colors
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont

PAGE_W, PAGE_H = A4
CARTES_PAGE = 10
PLAGES = {"B": (1, 15), "I": (16, 30), "N": (31, 45), "G": (46, 60), "O": (61, 75)}
NOIR = colors.Color(0.05, 0.05, 0.05)
GRIS_TRAIT = colors.Color(0.40, 0.40, 0.40)
RAINBOW = ["#E53935", "#FB8C00", "#F9A825", "#43A047", "#00ACC1",
           "#1E88E5", "#3949AB", "#8E24AA", "#D81B60", "#6D4C41"]
_ICI = _os.path.dirname(_os.path.abspath(__file__))
POLICE, _CAP = "Helvetica-Bold", 0.717
try:
    pdfmetrics.registerFont(TTFont("LMROMANB", _os.path.join(_ICI, "LatinModern-Bold.ttf")))
    POLICE, _CAP = "LMROMANB", 0.66
except Exception:
    pass
_IMG_W, _IMG_H = 1080.0, 1527.0
_IMG_FOND = _os.path.join(_ICI, "triplex_fond.png")
MARGE_SURE = 6 * 72 / 25.4
ECHELLE = min((PAGE_W - 2 * MARGE_SURE) / PAGE_W, (PAGE_H - 2 * MARGE_SURE) / PAGE_H)
DECAL_X = (PAGE_W - PAGE_W * ECHELLE) / 2.0
DECAL_Y = (PAGE_H - PAGE_H * ECHELLE) / 2.0

# bulles : (lettre, zone blanche sous le bandeau (x0, y0, x1, y1) px) ; serie = place du n°
CARTONS = [
    {'bulles': [('B', (23, 288, 222, 426)), ('O', (23, 543, 223, 687))], 'serie': (88, 57, 183, 83)},
    {'bulles': [('I', (249, 288, 435, 426)), ('G', (249, 543, 436, 686))], 'serie': (313, 57, 407, 83)},
    {'bulles': [('N', (458, 400, 646, 535))], 'serie': (522, 56, 617, 83)},
    {'bulles': [('I', (670, 288, 855, 426)), ('G', (670, 543, 855, 686))], 'serie': (733, 57, 828, 83)},
    {'bulles': [('B', (880, 288, 1065, 426)), ('O', (880, 543, 1065, 686))], 'serie': (943, 57, 1038, 83)},
    {'bulles': [('B', (23, 1003, 222, 1141)), ('O', (23, 1255, 221, 1394))], 'serie': (88, 774, 185, 800)},
    {'bulles': [('I', (250, 1004, 435, 1141)), ('G', (250, 1255, 435, 1393))], 'serie': (311, 774, 406, 800)},
    {'bulles': [('N', (458, 1116, 647, 1254))], 'serie': (521, 774, 615, 800)},
    {'bulles': [('I', (670, 1004, 855, 1141)), ('G', (670, 1255, 855, 1393))], 'serie': (731, 774, 827, 800)},
    {'bulles': [('B', (880, 1004, 1065, 1141)), ('O', (880, 1255, 1065, 1393))], 'serie': (942, 774, 1038, 801)},
]
ECART = 0.22          # blanc entre les 2 lignes, en hauteur de chiffre


def _px(x):
    return x / _IMG_W * PAGE_W


def _py(y):
    return PAGE_H * (1 - y / _IMG_H)


def _taille_max():
    t_best = 99.0
    for ct in CARTONS:
        for _L, (x0, y0, x1, y1) in ct["bulles"]:
            w = _px(x1) - _px(x0)
            h = _px(y1) - _px(y0)
            t = 10.0
            while True:
                t2 = t + 0.5
                larg = pdfmetrics.stringWidth("88 88", POLICE, t2)
                haut = (2 + ECART) * _CAP * t2
                if larg > 0.86 * w or haut > 0.80 * h:
                    break
                t = t2
            t_best = min(t_best, t)
    return t_best


TAILLE = _taille_max()


def _numeros(rng, lettres, deja=None):
    vus = deja if deja is not None else set()
    for _ in range(500):
        d = {L: sorted(rng.sample(range(PLAGES[L][0], PLAGES[L][1] + 1), 3)) for L in lettres}
        cle = (lettres,) + tuple(tuple(d[L]) for L in lettres)
        if cle not in vus:
            vus.add(cle)
            return d
    return d


def _num(c, txt, x, y):
    o = c.beginText()
    o.setTextRenderMode(2)
    o.setFont(POLICE, TAILLE)
    o.setTextOrigin(x - c.stringWidth(txt, POLICE, TAILLE) / 2.0, y)
    o.textOut(txt)
    c.drawText(o)


def generer_pdf(nb_cartes=None, nb_tickets=None, serie_start=1, theme="", couleur=True,
                nom_evenement="", titre_jeu="", couleur_perso="", date_lieu="",
                telephone="", page_start=1, evenement_id="", style="", motif="",
                _deja=None, **_ig):
    n_ = nb_cartes if nb_cartes is not None else nb_tickets
    n_ = max(1, int(n_ if n_ else CARTES_PAGE))
    buf = io.BytesIO()
    c = canvas.Canvas(buf, pagesize=(PAGE_W, PAGE_H), pageCompression=1)
    c.setTitle("TRIPLE X")
    rng = random.Random(int(serie_start) * 100003 + 3333)
    deja = _deja if _deja is not None else set()
    serie = int(serie_start)
    faits = 0
    try:
        no_page = max(1, int(page_start))
    except Exception:
        no_page = 1
    col_imposee = None
    if couleur and couleur_perso:
        try:
            col_imposee = colors.HexColor(couleur_perso)
        except Exception:
            col_imposee = None
    while faits < n_:
        c.saveState()
        c.translate(DECAL_X, DECAL_Y)
        c.scale(ECHELLE, ECHELLE)
        try:
            c.drawImage(_IMG_FOND, 0, 0, PAGE_W, PAGE_H, preserveAspectRatio=False, mask="auto")
        except Exception:
            pass
        for idx in range(CARTES_PAGE):
            if faits >= n_:
                break
            ct = CARTONS[idx]
            col = (col_imposee or colors.HexColor(RAINBOW[serie % len(RAINBOW)])) if couleur else NOIR
            lettres = "".join(L for L, _z in ct["bulles"])
            nums = _numeros(rng, lettres, deja)
            c.saveState()
            c.setFillColor(col)
            c.setStrokeColor(col)
            c.setLineWidth(0.4)
            c.setLineJoin(1)
            for L, (x0, y0, x1, y1) in ct["bulles"]:
                v1, v2, v3 = nums[L]
                cx = _px((x0 + x1) / 2.0)
                cy = _py((y0 + y1) / 2.0) + 0.04 * (_px(y1) - _px(y0))
                hc = _CAP * TAILLE
                y_haut = cy + ECART * hc / 2.0
                y_bas = cy - ECART * hc / 2.0 - hc
                ecart_x = pdfmetrics.stringWidth("88", POLICE, TAILLE) * 0.62
                _num(c, str(v1), cx - ecart_x, y_haut)
                _num(c, str(v2), cx + ecart_x, y_haut)
                _num(c, str(v3), cx, y_bas)
            c.restoreState()
            sx0, sy0, sx1, sy1 = ct["serie"]
            ts = (_px(sy1) - _px(sy0)) / 0.72
            c.setFillColor(NOIR)
            c.setFont("Helvetica-Bold", ts)
            c.drawString(_px(sx0), _py(sy1), "%06d" % serie)
            serie += 1
            faits += 1
        c.restoreState()
        c.setFillColor(GRIS_TRAIT)
        c.setFont("Helvetica", 6)
        c.drawRightString(PAGE_W - 17, PAGE_H - 19, "%d" % no_page)
        no_page += 1
        c.showPage()
    c.save()
    buf.seek(0)
    return buf
