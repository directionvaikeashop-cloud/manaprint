# -*- coding: utf-8 -*-
"""
MANAPRINT — Générateur TALON (format A4)

⚽ NÉ LE 15/08 (sceau Maeva) — LE CINQUIÈME JEU DE RANIHEI, rien qu'à elle.
Un ballon de football, six panneaux, un numéro dans chacun.

RÈGLE (sceau Maeva 15/08, relevée sur sa maquette 7·23·34·52·75·83) :
six numéros, un par panneau —
  1 · panneau de GAUCHE      : 1-15
  2 · panneau du HAUT        : 16-30
  3 · panneau de DROITE      : 31-45
  4 · panneau BAS-DROITE     : 46-60
  5 · panneau BAS-GAUCHE     : 61-75
  6 · le PENTAGONE du CENTRE : 76-90
⚠️ Les six plages ne se chevauchent pas : les numéros sont donc
toujours différents.
⚠️ Le sac du crieur va de 1 à 90.

⭐ DESSIN REFAIT PAR MAEVA LE 28/08 — tout en contours : titre TALON en
   lettres creuses penchées, étoile « 6 BOULES » en haut à droite, traits de
   vitesse de part et d'autre, hibiscus + RANIHEI SISTERS & SHOP + téléphone
   au pied. La géométrie du ballon n'a pas bougé d'un cheveu : les six
   panneaux tombent aux mêmes fractions qu'avant.

⚠️ Le dessin est presque CARRÉ (ratio 0,9909) — 12 cartes par feuille A4 (3×4).
"""
import io
from reportlab.pdfbase.pdfmetrics import stringWidth as _lgn
import random
from reportlab.pdfgen import canvas
from reportlab.lib.pagesizes import A4
from reportlab.lib import colors
from reportlab.lib.units import mm
from reportlab.pdfbase.pdfmetrics import stringWidth as _lgv
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont

# SÉCURITÉ ANTI-PHOTOCOPIE (microtexte) — anti-panne : si le module securite
# est absent, les cartons sortent normalement, simplement sans microtexte.
try:
    from generators import securite as _sec
except Exception:
    try:
        import securite as _sec
    except Exception:
        _sec = None


try:
    pdfmetrics.registerFont(TTFont("DJL", "/usr/share/fonts/truetype/dejavu/DejaVuSans-ExtraLight.ttf"))
    POLICE = "DJL"
except Exception:
    POLICE = "Helvetica"

RAINBOW = [
    "#E53935", "#FB8C00", "#F9A825", "#43A047", "#00ACC1",
    "#1E88E5", "#3949AB", "#8E24AA", "#D81B60", "#6D4C41",
]
GRIS = colors.Color(0.42, 0.42, 0.42)
GRIS_CLAIR = colors.Color(0.80, 0.80, 0.80)


# ══ DEUX GAMMES COMMERCIALES (vision Maeva) ══════════════════════════
# ÉCO      : écriture fine DejaVu ExtraLight, gris 0,50 — économie de toner
# PREMIUM  : écriture grasse Helvetica-Bold, gris 0,55 — style P15
from reportlab.pdfbase import pdfmetrics as _pm
from reportlab.pdfbase.ttfonts import TTFont as _TF
try:
    _pm.registerFont(_TF("DJLECO", "/usr/share/fonts/truetype/dejavu/DejaVuSans-ExtraLight.ttf"))
    _POLICE_ECO = "DJLECO"
except Exception:
    _POLICE_ECO = "Helvetica"
_GRIS_ECO = colors.Color(0.50, 0.50, 0.50)
_POLICE_P15 = "Helvetica-Bold"
_GRIS_P15 = colors.Color(0.55, 0.55, 0.55)

def _style_chiffres(style):
    """Retourne (police, gris) des chiffres selon la gamme choisie."""
    if str(style).lower() in ("p15", "premium"):
        return _POLICE_P15, _GRIS_P15
    return _POLICE_ECO, _GRIS_ECO
# ═════════════════════════════════════════════════════════════════════

PAGE_W, PAGE_H = A4
LETTRES = "ING"
# (min, max, nombre) par lettre — le N saute sa case centrale
COLONNES = [(16, 30, 3), (31, 45, 2), (46, 60, 3)]

# ═══ ⚽ LES SIX PANNEAUX DU BALLON ═══
_RATIO_TALON = 0.9909
# ⚠️⚠️ LEÇON DU 28/08 : un panneau de ballon est un TRAPÈZE INCLINÉ. Son
# centre de MASSE n'est PAS le milieu de la place libre à la hauteur du
# chiffre — en le prenant, les nombres à deux chiffres mordaient la couture.
# Chaque X ci-dessous est le MILIEU DU GOULOT : on balaie la bande de hauteur
# qu'occupera le chiffre et on retient le passage le plus étroit.
ZONES = [[0.2881, 0.5951],   # panneau de GAUCHE
         [0.5038, 0.7564],   # panneau du HAUT
         [0.7215, 0.5977],   # panneau de DROITE
         [0.6485, 0.2975],   # panneau BAS-DROITE
         [0.3677, 0.2978],   # panneau BAS-GAUCHE
         [0.5050, 0.4956]]   # le PENTAGONE du CENTRE
LARG_ZONE = 0.2038   # le goulot du PENTAGONE, le plus étroit des six
HAUT_ZONE = 0.2400

# ⚽ les six panneaux et leur plage, dans l'ordre de la maquette
PLAGES = [
    ("gauche", (1, 15)),
    ("haut", (16, 30)),
    ("droite", (31, 45)),
    ("bas-droite", (46, 60)),
    ("bas-gauche", (61, 75)),
    ("centre", (76, 90)),
]

import os as _os2
from reportlab.pdfbase.pdfmetrics import stringWidth as _lg_ta


def _choisir_image(motif_img, ratio_attendu):
    """Retrouve le dessin, quel que soit son nom de fichier."""
    dossier = _os2.path.dirname(_os2.path.abspath(__file__))
    exact = _os2.path.join(dossier, motif_img + ".png")
    candidats = []
    try:
        for f in _os2.listdir(dossier):
            if motif_img in f and f.lower().endswith(".png"):
                candidats.append(_os2.path.join(dossier, f))
    except Exception:
        return exact
    if not candidats:
        return exact
    meilleur, ecart = candidats[0], 9e9
    for chemin in candidats:
        try:
            from PIL import Image as _Im
            with _Im.open(chemin) as im:
                e = abs(im.width / float(im.height) - ratio_attendu)
        except Exception:
            continue
        if e < ecart:
            meilleur, ecart = chemin, e
    return meilleur


_IMAGE_TALON = _choisir_image("talon_ballon", _RATIO_TALON)

PAGE_W, PAGE_H = A4
MARGIN_X = 8 * mm
MARGIN_TOP = 10 * mm
MARGIN_BOT = 8 * mm
GUTTER_X = 4 * mm
GUTTER_Y = 3 * mm
# ⚠️⚠️ LE DESSIN EST CARRÉ : la hauteur commande ici, sinon 4 rangées de
# 95 mm ne tiendraient jamais sur la feuille. La largeur suit, on centre.
# ⭐ 15/08 : DOUZE grilles par feuille (3 colonnes x 4 rangées) — le carré
# passe de 67,5 à 62 mm, à peine plus petit, et Maeva en tire 50 % de plus.
COLS_PAGE = 3
ROWS_PAGE = 4
# ⚠️⚠️ LE BALLON EST CARRÉ : la carte doit l'être aussi, sinon il devient
# un œuf. On prend donc le PLUS PETIT des deux côtés disponibles, et on
# centre le bloc dans les deux sens.
_DISPO_W = (PAGE_W - 2 * MARGIN_X - (COLS_PAGE - 1) * GUTTER_X) / COLS_PAGE
_DISPO_H = (PAGE_H - MARGIN_TOP - MARGIN_BOT - (ROWS_PAGE - 1) * GUTTER_Y) / ROWS_PAGE
CARD_W = min(_DISPO_W, _DISPO_H * _RATIO_TALON)
CARD_H = CARD_W / _RATIO_TALON
_TOTAL_W = COLS_PAGE * CARD_W + (COLS_PAGE - 1) * GUTTER_X
_TOTAL_H = ROWS_PAGE * CARD_H + (ROWS_PAGE - 1) * GUTTER_Y
MARGE_G = (PAGE_W - _TOTAL_W) / 2
MARGE_B = MARGIN_BOT + max(0, (PAGE_H - MARGIN_TOP - MARGIN_BOT - _TOTAL_H) / 2)
GRIS_CLAIR = colors.Color(0.62, 0.62, 0.62)


def _gen_carte(rng):
    """⚽ Six numéros, un par panneau, dans sa plage. Ils sont forcément
    tous différents : les six plages ne se chevauchent pas."""
    return [rng.randint(lo, hi) for _nom, (lo, hi) in PLAGES]


def _dessiner_carte(c, x0, y0, nums, couleur_hex, serie, telephone="",
                    style="eco", evenement_id=""):
    police_ch, gris_ch = _style_chiffres(style)

    # ═══ LA PLAQUE AU BALLON ═══
    _pw = CARD_W - 0.6 * mm
    _ph = CARD_H - 0.6 * mm
    _px = x0 + (CARD_W - _pw) / 2
    _py = y0 + 0.3 * mm
    if _os2.path.exists(_IMAGE_TALON):
        try:
            c.drawImage(_IMAGE_TALON, _px, _py, _pw, _ph, mask="auto")
        except Exception:
            pass

    # LA POLICE DES CHIFFRES : « Helvetica-Bold » — le gras plutôt que la
    # taille, les chiffres se voient de loin.
    _POLICE_NUM = "Helvetica-Bold"
    _lg_z = _pw * LARG_ZONE
    _ht_z = _ph * HAUT_ZONE
    _t_num = 48.0
    # LARG_ZONE est désormais la VRAIE place libre au goulot : 0,86 suffit.
    while _t_num > 6 and (_lg_ta("88", _POLICE_NUM, _t_num) > _lg_z * 0.86
                          or _t_num * 0.72 > _ht_z * 0.86):
        _t_num -= 0.5

    for _k, _n in enumerate(nums[:6]):
        _bx, _by = ZONES[_k]
        _nx = _px + _bx * _pw
        _ny = _py + _by * _ph - _t_num * 0.34
        c.setFillColor(gris_ch)
        c.setFont(_POLICE_NUM, _t_num)
        c.drawCentredString(_nx, _ny, str(_n))

    # ═══ LA SÉRIE, discrète en haut à droite ═══
    c.setFillColor(gris_ch)
    _tb = 8.0
    _bl = "N\u00b0 %05d" % serie
    while _tb > 3.2 and _lg_ta(_bl, "Helvetica-Bold", _tb) > _pw * 0.16:
        _tb -= 0.25
    c.setFont("Helvetica-Bold", _tb)
    c.drawCentredString(_px + _pw * 0.1369, _py + _ph * 0.0389 - _tb * 0.34, _bl)


def generer_pdf(nb_cartes=8, serie_start=1, theme="", couleur=True,
                nom_evenement="", titre_jeu="", couleur_perso="", date_lieu="",
                telephone="", style="eco", evenement_id="", page_start=1):
    buf = io.BytesIO()
    c = canvas.Canvas(buf, pagesize=A4, pageCompression=1)
    rng = random.Random()
    nb_cartes = max(1, min(int(nb_cartes), 10000))
    par_page = COLS_PAGE * ROWS_PAGE
    nb_pages = (nb_cartes + par_page - 1) // par_page
    serie = int(serie_start)
    no_page = max(1, int(page_start))
    faites = 0
    for _ in range(nb_pages):
        if nom_evenement:
            c.setFillColor(colors.black); c.setFont("Helvetica-Bold", 9)
            c.drawCentredString(PAGE_W / 2, PAGE_H - 5 * mm, nom_evenement)
        c.setFillColor(GRIS_CLAIR); c.setFont("Helvetica", 5)
        c.drawRightString(PAGE_W - 6 * mm, PAGE_H - 9 * mm, "Page %d" % no_page)
        for row in range(ROWS_PAGE):
            for col_i in range(COLS_PAGE):
                if faites >= nb_cartes:
                    break
                x0 = MARGE_G + col_i * (CARD_W + GUTTER_X)
                y0 = MARGE_B + (ROWS_PAGE - 1 - row) * (CARD_H + GUTTER_Y)
                coul = (couleur_perso or "#000000") if couleur else "#000000"
                _dessiner_carte(c, x0, y0, _gen_carte(rng), coul, serie,
                                telephone, style, evenement_id)
                serie += 1
                faites += 1
        c.showPage()
        no_page += 1
    c.save()
    buf.seek(0)
    return buf
